# Building the APK with GitHub Actions

Workflow: `.github/workflows/android-build.yml` (the project folder must be the repository root).

## Run it
- Every push to `main`/`master` and every pull request builds a **debug** APK.
- Manual run: GitHub -> Actions -> "Build Android APK" -> Run workflow -> choose `debug` or `release`
  (optionally tick "Run unit tests").
- Download the APK from the finished run, section **Artifacts** (`CloudMemo-debug-apk` / `CloudMemo-release-apk`).

## Optional repository secrets (Settings -> Secrets and variables -> Actions)
| Secret | Content |
|---|---|
| `GOOGLE_SERVICES_JSON` | the full text of `google-services.json` (enables push notifications) |
| `RELEASE_KEYSTORE_BASE64` | your release keystore as Base64: `base64 -w0 release.jks` (macOS: `base64 -i release.jks`) |
| `RELEASE_KEYSTORE_PASSWORD` | keystore password |
| `RELEASE_KEY_ALIAS` | key alias (for example `cloudmemo`) |
| `RELEASE_KEY_PASSWORD` | key password |

Without the keystore secrets a `release` run is signed with the debug key (fine for testing, not for publishing).
Without `GOOGLE_SERVICES_JSON` the app builds normally and push stays off.

## Notes
- No Gradle wrapper is included, so the workflow installs the latest stable Gradle. To pin a version, add
  `gradle wrapper` output to the repository and replace the Gradle step with `./gradlew`.
- Java 17 and Android SDK platform 35 are installed by the workflow.
