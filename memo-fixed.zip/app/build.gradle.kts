import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

// Release signing: keystore.properties (git-ignored) or CLOUDMEMO_* environment variables. See docs/RELEASE_SIGNING.md.
val keystoreProps = Properties().apply {
    val file = rootProject.file("keystore.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun signingValue(key: String, env: String): String? = keystoreProps.getProperty(key) ?: System.getenv(env)

val releaseStorePath: String? = signingValue("storeFile", "CLOUDMEMO_KEYSTORE_FILE")
val hasReleaseKeystore: Boolean = releaseStorePath != null && rootProject.file(releaseStorePath).exists()

android {
    namespace = "com.example"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nabil.cloudmemo"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "10.1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("release") {
            if (hasReleaseKeystore) {
                storeFile = rootProject.file(releaseStorePath!!)
                storePassword = signingValue("storePassword", "CLOUDMEMO_KEYSTORE_PASSWORD")
                keyAlias = signingValue("keyAlias", "CLOUDMEMO_KEY_ALIAS")
                keyPassword = signingValue("keyPassword", "CLOUDMEMO_KEY_PASSWORD")
            }
        }
        // Optional project debug keystore; without it Android's default debug key is used (so CI builds need no extra file).
        if (rootProject.file("debug.keystore").exists()) {
            create("debugConfig") {
                storeFile = rootProject.file("debug.keystore")
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Without your own keystore the release build is signed with the debug key so it still installs for testing.
            // Never publish such a build: add keystore.properties first.
            signingConfig = if (hasReleaseKeystore) {
                signingConfigs.getByName("release")
            } else {
                logger.warn("WARNING: keystore.properties not found - release build is signed with the DEBUG key.")
                signingConfigs.findByName("debugConfig") ?: signingConfigs.getByName("debug")
            }
        }
        debug {
            signingConfig = signingConfigs.findByName("debugConfig") ?: signingConfigs.getByName("debug")
        }
    }

    lint {
        // Release builds must not fail on lint findings; run `gradle lint` separately when you want the report.
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.security.crypto)
    implementation(libs.okhttp)
    implementation(libs.kotlinx.coroutines.android)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.biometric)

    // Firebase Cloud Messaging. Push stays inactive until google-services.json is added (see docs/FCM_SETUP.md).
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.messaging)

    testImplementation("junit:junit:4.13.2")
}
