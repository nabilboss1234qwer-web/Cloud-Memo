package com.example.push

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * FCM helpers. Everything is a no-op until google-services.json is added to the app module
 * (FirebaseApp is then initialised automatically), so the app also runs without Firebase configured.
 */
object PushRegistrar {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * Initialises Firebase from `assets/google-services.json` (no Gradle plugin needed). Does nothing when the file is
     * missing, does not contain this app's package, or Firebase was already initialised by the Google services plugin.
     */
    @Synchronized
    fun ensureInitialized(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) return
            val text = context.assets.open("google-services.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val info = root.getJSONObject("project_info")
            val clients = root.getJSONArray("client")
            var chosen: JSONObject? = null
            for (i in 0 until clients.length()) {
                val client = clients.getJSONObject(i)
                val pkg = client.getJSONObject("client_info").getJSONObject("android_client_info").getString("package_name")
                if (pkg == context.packageName) {
                    chosen = client
                    break
                }
            }
            val client = chosen ?: return
            val options = FirebaseOptions.Builder()
                .setApplicationId(client.getJSONObject("client_info").getString("mobilesdk_app_id"))
                .setApiKey(client.getJSONArray("api_key").getJSONObject(0).getString("current_key"))
                .setProjectId(info.getString("project_id"))
                .setGcmSenderId(info.getString("project_number"))
                .build()
            FirebaseApp.initializeApp(context.applicationContext, options)
        } catch (_: Throwable) {
            // No (valid) config file: push simply stays off.
        }
    }

    fun isAvailable(context: Context): Boolean {
        ensureInitialized(context)
        return try { FirebaseApp.getApps(context).isNotEmpty() } catch (_: Throwable) { false }
    }

    /** Subscribes to the broadcast topic and uploads this device's FCM token. Call after sign-in. */
    fun register(context: Context, upload: suspend (token: String) -> Unit) {
        if (!isAvailable(context)) return
        try {
            val fm = FirebaseMessaging.getInstance()
            fm.subscribeToTopic("all")
            fm.token.addOnSuccessListener { token ->
                scope.launch { runCatching { upload(token) } }
            }
        } catch (_: Throwable) {
        }
    }

    /** Call on logout / account deletion so this phone stops receiving the previous user's pushes. */
    fun unregister(context: Context) {
        if (!isAvailable(context)) return
        try {
            val fm = FirebaseMessaging.getInstance()
            fm.unsubscribeFromTopic("all")
            fm.deleteToken()
        } catch (_: Throwable) {
        }
    }
}
