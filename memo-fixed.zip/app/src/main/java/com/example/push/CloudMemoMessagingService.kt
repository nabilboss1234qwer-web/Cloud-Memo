package com.example.push

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.network.AccessEvents
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

object NotificationChannels {
    const val ANNOUNCEMENTS = "announcements"

    fun create(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(ANNOUNCEMENTS, "Announcements", NotificationManager.IMPORTANCE_HIGH)
            try {
                context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            } catch (_: Throwable) {
            }
        }
    }
}

class CloudMemoMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        // The token is uploaded again on the next app start / sign-in (PushRegistrar.register).
        AccessEvents.statusCheck.tryEmit(Unit)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        when (message.data["type"]) {
            "account_status" -> AccessEvents.statusCheck.tryEmit(Unit)
            "admin_notification" -> {
                AccessEvents.inboxRefresh.tryEmit(Unit)
                showLocal(
                    message.notification?.title ?: "CloudMemo",
                    message.notification?.body ?: "",
                    message.data["severity"]
                )
            }
        }
    }

    private fun showLocal(title: String, body: String, severity: String?) {
        NotificationChannels.create(this)
        val intent = Intent(this, MainActivity::class.java)
            .putExtra("push_type", "admin_notification")
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, NotificationChannels.ANNOUNCEMENTS)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(if (severity == "critical") NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        val allowed = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (allowed) {
            try {
                NotificationManagerCompat.from(this).notify(System.currentTimeMillis().toInt(), notification)
            } catch (_: Throwable) {
            }
        }
    }
}
