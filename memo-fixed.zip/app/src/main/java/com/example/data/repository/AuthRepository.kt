package com.example.data.repository

import com.example.data.crypto.KeystoreHelper
import com.example.data.model.AccountExportDto
import com.example.data.model.AuthResponseDto
import com.example.data.model.DeviceDto
import com.example.data.model.RegisterResponseDto
import com.example.data.model.UserProfileDto
import com.example.data.network.CloudMemoApiService
import com.example.data.network.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AuthRepository(
    private val sessionManager: SessionManager,
    private val apiService: CloudMemoApiService,
    private val keystoreHelper: KeystoreHelper
) {
    val isLoggedIn: Boolean
        get() = sessionManager.isLoggedIn

    val currentUserEmail: String?
        get() = sessionManager.userEmail

    val currentUserDisplayName: String?
        get() = sessionManager.userDisplayName

    suspend fun register(
        email: String,
        password: String,
        displayName: String
    ): Result<RegisterResponseDto> {
        return apiService.register(email, password, displayName)
    }

    suspend fun verifyEmail(
        email: String,
        code: String
    ): Result<AuthResponseDto> = withContext(Dispatchers.IO) {
        val result = apiService.verifyEmail(email, code)
        result.onSuccess {
            registerCurrentDevice()
        }
        result
    }

    suspend fun resendCode(email: String): Result<RegisterResponseDto> {
        return apiService.resendCode(email)
    }

    suspend fun login(
        email: String,
        password: String,
        deviceName: String
    ): Result<AuthResponseDto> = withContext(Dispatchers.IO) {
        val result = apiService.login(email, password, deviceName)
        result.onSuccess {
            registerCurrentDevice()
        }
        result
    }

    suspend fun getCurrentUser(): Result<UserProfileDto> {
        return apiService.getCurrentUser()
    }

    suspend fun registerCurrentDevice(): Result<String> {
        val deviceId = keystoreHelper.deviceId
        val deviceName = "Android Device (${android.os.Build.MODEL})"
        val publicKey = keystoreHelper.getDevicePublicKeyBase64()
        return apiService.registerDevice(deviceId, deviceName, publicKey)
    }

    suspend fun listDevices(): Result<List<DeviceDto>> {
        return apiService.listDevices(keystoreHelper.deviceId)
    }

    suspend fun revokeDevice(deviceId: String): Result<Boolean> {
        return apiService.revokeDevice(deviceId)
    }

    suspend fun exportAccount(): Result<AccountExportDto> {
        return apiService.exportAccount()
    }

    suspend fun deleteAccount(password: String): Result<Boolean> {
        return apiService.deleteAccount(password)
    }

    suspend fun logout() = withContext(Dispatchers.IO) {
        // Best effort: ends this device's session on the server, then forgets it locally in any case.
        runCatching { apiService.revokeRefreshToken() }
        sessionManager.clearSession()
    }
}
