package com.example.data.network

import com.example.data.crypto.KeyBundle
import com.example.data.model.AccountExportDto
import com.example.data.model.AccountStatusDto
import com.example.data.model.NotificationDto
import com.example.data.model.NotificationListDto
import com.example.data.model.PasswordChangeResultDto
import com.example.data.model.PublicShareDto
import com.example.data.model.ApiErrorDetail
import com.example.data.model.AuthResponseDto
import com.example.data.model.DeviceDto
import com.example.data.model.NoteServerItemDto
import com.example.data.model.RegisterResponseDto
import com.example.data.model.SyncChangesResponseDto
import com.example.data.model.TrashServerItemDto
import com.example.data.model.UserProfileDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Authenticator
import okhttp3.Response
import okhttp3.Route
import java.io.IOException
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class CloudMemoApiService(private val sessionManager: SessionManager) {

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    private val refreshLock = Any()

    /** Client without the authenticator: used only for the token refresh and logout calls. */
    private val plainClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    /** On HTTP 401 the access token is renewed with the refresh token and the request is repeated once. */
    private val tokenAuthenticator = object : Authenticator {
        @Throws(IOException::class)
        override fun authenticate(route: Route?, response: Response): Request? = refreshAccessToken(response)
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .authenticator(tokenAuthenticator)
        .build()

    @Throws(IOException::class)
    private fun refreshAccessToken(response: Response): Request? {
        val request = response.request
        // Only authenticated calls, and never a second time for the same request.
        if (request.header("Authorization") == null || request.header("X-Token-Refreshed") != null) return null
        if (sessionManager.refreshToken.isNullOrBlank()) return null
        return synchronized(refreshLock) {
            val failedToken = request.header("Authorization")?.removePrefix("Bearer ")?.trim()
            val current = sessionManager.authToken
            if (!current.isNullOrBlank() && current != failedToken) {
                // Another call already renewed the token while this one waited for the lock.
                return@synchronized request.newBuilder()
                    .header("Authorization", "Bearer $current")
                    .header("X-Token-Refreshed", "1")
                    .build()
            }
            val refreshToken = sessionManager.refreshToken ?: return@synchronized null
            val refreshRequest = Request.Builder()
                .url("${baseUrl()}/v1/auth/refresh")
                .post(JSONObject().put("refresh_token", refreshToken).toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()
            plainClient.newCall(refreshRequest).execute().use { r ->
                val text = r.body?.string().orEmpty()
                when {
                    r.isSuccessful -> {
                        try {
                            val o = JSONObject(text)
                            val newAccess = o.getString("access_token")
                            sessionManager.updateTokens(
                                newAccess,
                                o.optLong("expires_in", 3600L),
                                o.optString("refresh_token", "").ifBlank { null }
                            )
                            request.newBuilder()
                                .header("Authorization", "Bearer $newAccess")
                                .header("X-Token-Refreshed", "1")
                                .build()
                        } catch (e: org.json.JSONException) {
                            throw IOException("Malformed refresh response", e)
                        }
                    }
                    // The server refused the refresh token (revoked, expired, password changed, signed out everywhere).
                    r.code == 401 -> {
                        sessionManager.sessionEndedByServer = true
                        null
                    }
                    r.code == 403 -> null
                    // Network trouble or a server error is NOT a reason to log the user out.
                    else -> throw IOException("Could not renew the session (HTTP ${r.code})")
                }
            }
        }
    }

    /** Tells the server to end this device's session (best effort, used by logout). */
    suspend fun revokeRefreshToken(): Result<Boolean> = withContext(Dispatchers.IO) {
        val token = sessionManager.refreshToken ?: return@withContext Result.success(true)
        try {
            val request = Request.Builder()
                .url("${baseUrl()}/v1/auth/logout")
                .post(JSONObject().put("refresh_token", token).toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()
            // Short timeout: logging out must never hang when the phone is offline.
            plainClient.newBuilder().callTimeout(4, TimeUnit.SECONDS).build()
                .newCall(request).execute().use { Result.success(it.isSuccessful) }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun baseUrl(): String {
        return sessionManager.serverUrl.trimEnd('/')
    }

    private fun parseError(response: Response): ApiErrorDetail {
        val code = response.code
        val bodyStr = try { response.body?.string().orEmpty() } catch (_: Exception) { "" }
        var message = "Request failed with status $code"
        var isConflict = false
        var serverVer: Long? = null
        var clientVer: Long? = null
        var errCode: String? = null
        var errStatus: String? = null
        var errUserMessage: String? = null

        if (bodyStr.isNotBlank()) {
            try {
                val root = JSONObject(bodyStr)
                errCode = root.optString("code", "").ifBlank { null }
                errStatus = root.optString("account_status", "").ifBlank { null }
                errUserMessage = if (root.isNull("user_message")) null else root.optString("user_message", "").ifBlank { null }
                when (val detailOpt = root.opt("detail")) {
                    is String -> {
                        message = detailOpt
                    }
                    is JSONArray -> {
                        val messages = mutableListOf<String>()
                        for (i in 0 until detailOpt.length()) {
                            val item = detailOpt.optJSONObject(i)
                            val msg = item?.optString("msg")
                            if (!msg.isNullOrBlank()) messages.add(msg)
                        }
                        if (messages.isNotEmpty()) {
                            message = messages.joinToString("; ")
                        }
                    }
                    is JSONObject -> {
                        message = detailOpt.optString("message", "Conflict or validation error")
                        if (detailOpt.has("server_version")) {
                            isConflict = true
                            serverVer = detailOpt.optLong("server_version")
                            clientVer = detailOpt.optLong("client_version")
                        }
                    }
                }
            } catch (_: Exception) {
                if (bodyStr.length < 200) {
                    message = bodyStr
                }
            }
        }

        if (code == 401 && (message.contains("status 401") || message.contains("Unauthorized"))) {
            message = "Invalid email/password or session expired."
        } else if (code == 403 && message.contains("status 403")) {
            message = "Email verification required or account restricted."
        } else if (code == 409 && message.contains("status 409")) {
            message = "Duplicate resource or version conflict."
            isConflict = true
        } else if (code == 429) {
            if (message.contains("status 429")) {
                message = "Too many requests. Please wait a moment before trying again."
            }
        }

        val ec = errCode
        val blockCodes = setOf("ACCOUNT_LOCKED", "ACCOUNT_SUSPENDED", "ACCOUNT_BANNED", "ACCOUNT_DELETED")
        when {
            code == 401 && !sessionManager.authToken.isNullOrBlank() && sessionManager.shouldEndSessionOn401 -> {
                sessionManager.clearSession()
                AccessEvents.flow.tryEmit(AccessEvent.SessionExpired)
            }
            ec != null && ec in blockCodes -> AccessEvents.flow.tryEmit(AccessEvent.Blocked(ec, message, errUserMessage))
            ec == "PASSWORD_CHANGE_REQUIRED" -> AccessEvents.flow.tryEmit(AccessEvent.PasswordChangeRequired)
            ec == "EMAIL_NOT_VERIFIED" -> AccessEvents.flow.tryEmit(AccessEvent.EmailNotVerified)
        }

        return ApiErrorDetail(
            statusCode = code,
            message = message,
            isConflict = isConflict,
            serverVersion = serverVer,
            clientVersion = clientVer,
            code = ec,
            accountStatus = errStatus,
            userMessage = errUserMessage
        )
    }

    suspend fun register(
        email: String,
        password: String,
        displayName: String
    ): Result<RegisterResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/register"
            val json = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
                put("display_name", displayName.trim())
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 202 || response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = if (body.isNotBlank()) JSONObject(body) else JSONObject()
                    val msg = obj.optString("message", "Verification code sent")
                    val expires = obj.optLong("expires_in_seconds", 600L)
                    Result.success(RegisterResponseDto(msg, expires))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verifyEmail(
        email: String,
        code: String
    ): Result<AuthResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/verify-email"
            val json = JSONObject().apply {
                put("email", email.trim())
                put("code", code.trim())
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val token = obj.getString("access_token")
                    val tokenType = obj.optString("token_type", "bearer")
                    val expiresIn = obj.optLong("expires_in", 3600L)
                    val userObj = obj.getJSONObject("user")
                    val user = UserProfileDto(
                        id = userObj.getString("id"),
                        email = userObj.getString("email"),
                        displayName = userObj.optString("display_name", ""),
                        role = userObj.optString("role", "user"),
                        emailVerified = true,
                        mustChangePassword = userObj.optBoolean("must_change_password", false)
                    )
                    sessionManager.saveAuth(token, user.email, user.displayName, user.id, user.role, expiresIn)
                    sessionManager.refreshToken = obj.optString("refresh_token", "").ifBlank { null }
                    Result.success(AuthResponseDto(token, tokenType, expiresIn, user))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resendCode(email: String): Result<RegisterResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/resend-code"
            val json = JSONObject().apply {
                put("email", email.trim())
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 202 || response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = if (body.isNotBlank()) JSONObject(body) else JSONObject()
                    val msg = obj.optString("message", "Verification code resent")
                    val expires = obj.optLong("expires_in_seconds", 600L)
                    Result.success(RegisterResponseDto(msg, expires))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun login(
        email: String,
        password: String,
        deviceName: String
    ): Result<AuthResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/login"
            val json = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
                put("device_name", deviceName.ifBlank { "Android Device" })
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val token = obj.getString("access_token")
                    val tokenType = obj.optString("token_type", "bearer")
                    val expiresIn = obj.optLong("expires_in", 3600L)
                    val userObj = obj.getJSONObject("user")
                    val user = UserProfileDto(
                        id = userObj.getString("id"),
                        email = userObj.getString("email"),
                        displayName = userObj.optString("display_name", ""),
                        role = userObj.optString("role", "user"),
                        emailVerified = true,
                        mustChangePassword = userObj.optBoolean("must_change_password", false)
                    )
                    sessionManager.saveAuth(token, user.email, user.displayName, user.id, user.role, expiresIn)
                    sessionManager.refreshToken = obj.optString("refresh_token", "").ifBlank { null }
                    Result.success(AuthResponseDto(token, tokenType, expiresIn, user))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCurrentUser(): Result<UserProfileDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/me"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val user = UserProfileDto(
                        id = obj.getString("id"),
                        email = obj.getString("email"),
                        displayName = obj.optString("display_name", ""),
                        role = obj.optString("role", "user"),
                        status = obj.optString("status", "active"),
                        emailVerified = obj.optBoolean("email_verified", true),
                        createdAt = obj.optLong("created_at", 0L),
                        mustChangePassword = obj.optBoolean("must_change_password", false)
                    )
                    sessionManager.userEmail = user.email
                    sessionManager.userDisplayName = user.displayName
                    sessionManager.userId = user.id
                    sessionManager.userRole = user.role
                    Result.success(user)
                } else {
                    // parseError ends the session only when the refresh token was really refused by the server.
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createNote(
        noteId: String,
        encryptedPayload: String,
        nonce: String,
        keyVersion: Int = 1,
        clientVersion: Long = 1L
    ): Result<NoteServerItemDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes"
            val json = JSONObject().apply {
                put("note_id", noteId)
                put("encrypted_payload", encryptedPayload)
                put("nonce", nonce)
                put("key_version", keyVersion)
                put("client_version", clientVersion)
                put("title_hint", JSONObject.NULL)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 201 || response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    Result.success(
                        NoteServerItemDto(
                            noteId = obj.getString("note_id"),
                            encryptedPayload = encryptedPayload,
                            nonce = nonce,
                            keyVersion = keyVersion,
                            clientVersion = clientVersion,
                            serverVersion = obj.optLong("server_version", 1L),
                            updatedAt = obj.optLong("updated_at", System.currentTimeMillis() / 1000L)
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun listNotes(limit: Int = 50, cursor: String? = null): Result<Pair<List<NoteServerItemDto>, String?>> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            var url = "${baseUrl()}/v1/notes?limit=$limit"
            if (!cursor.isNullOrBlank()) {
                url += "&cursor=$cursor"
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val items = mutableListOf<NoteServerItemDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        items.add(
                            NoteServerItemDto(
                                noteId = item.getString("note_id"),
                                encryptedPayload = item.getString("encrypted_payload"),
                                nonce = item.getString("nonce"),
                                keyVersion = item.optInt("key_version", 1),
                                clientVersion = item.optLong("client_version", 1L),
                                serverVersion = item.optLong("server_version", 1L),
                                titleHint = if (item.isNull("title_hint")) null else item.optString("title_hint"),
                                createdAt = item.optLong("created_at", 0L),
                                updatedAt = item.optLong("updated_at", 0L)
                            )
                        )
                    }
                    val nextCursor = if (obj.isNull("next_cursor")) null else obj.optString("next_cursor")
                    Result.success(Pair(items, nextCursor))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getNote(noteId: String): Result<NoteServerItemDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes/$noteId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val item = JSONObject(body)
                    Result.success(
                        NoteServerItemDto(
                            noteId = item.getString("note_id"),
                            encryptedPayload = item.getString("encrypted_payload"),
                            nonce = item.getString("nonce"),
                            keyVersion = item.optInt("key_version", 1),
                            clientVersion = item.optLong("client_version", 1L),
                            serverVersion = item.optLong("server_version", 1L),
                            titleHint = if (item.isNull("title_hint")) null else item.optString("title_hint"),
                            createdAt = item.optLong("created_at", 0L),
                            updatedAt = item.optLong("updated_at", 0L)
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateNote(
        noteId: String,
        encryptedPayload: String,
        nonce: String,
        keyVersion: Int = 1,
        clientVersion: Long
    ): Result<NoteServerItemDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes/$noteId"
            val json = JSONObject().apply {
                put("encrypted_payload", encryptedPayload)
                put("nonce", nonce)
                put("key_version", keyVersion)
                put("client_version", clientVersion)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .put(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    Result.success(
                        NoteServerItemDto(
                            noteId = obj.getString("note_id"),
                            encryptedPayload = encryptedPayload,
                            nonce = nonce,
                            keyVersion = keyVersion,
                            clientVersion = clientVersion,
                            serverVersion = obj.optLong("server_version", clientVersion),
                            updatedAt = obj.optLong("updated_at", System.currentTimeMillis() / 1000L)
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun trashNote(noteId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes/$noteId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun listTrash(): Result<List<TrashServerItemDto>> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/trash"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val list = mutableListOf<TrashServerItemDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        list.add(
                            TrashServerItemDto(
                                noteId = item.getString("note_id"),
                                deletedAt = item.optLong("deleted_at", 0L),
                                updatedAt = item.optLong("updated_at", 0L)
                            )
                        )
                    }
                    Result.success(list)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreTrashNote(noteId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/trash/$noteId/restore"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post("{}".toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun permanentDeleteTrashNote(noteId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/trash/$noteId/permanent"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSyncChanges(since: Long = 0L, limit: Int = 100): Result<SyncChangesResponseDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/sync/changes?since=$since&limit=$limit"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val items = mutableListOf<NoteServerItemDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        items.add(
                            NoteServerItemDto(
                                noteId = item.getString("note_id"),
                                encryptedPayload = item.optString("encrypted_payload", ""),
                                nonce = item.optString("nonce", ""),
                                keyVersion = item.optInt("key_version", 1),
                                clientVersion = item.optLong("client_version", 1L),
                                serverVersion = item.optLong("server_version", 1L),
                                titleHint = if (item.isNull("title_hint")) null else item.optString("title_hint"),
                                createdAt = item.optLong("created_at", 0L),
                                updatedAt = item.optLong("updated_at", 0L),
                                deleted = item.optBoolean("deleted", false),
                                deletedAt = if (item.isNull("deleted_at")) null else item.optLong("deleted_at")
                            )
                        )
                    }
                    val serverTime = obj.optLong("server_time", System.currentTimeMillis() / 1000L)
                    Result.success(SyncChangesResponseDto(items, serverTime, obj.optBoolean("has_more", false)))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerDevice(
        deviceId: String,
        deviceName: String,
        publicKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/devices"
            val json = JSONObject().apply {
                put("device_id", deviceId)
                put("device_name", deviceName)
                put("public_key", publicKey)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    Result.success(obj.optString("device_record_id", deviceId))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun listDevices(currentDeviceId: String? = null): Result<List<DeviceDto>> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/devices"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val list = mutableListOf<DeviceDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        val devId = item.getString("device_id")
                        val devName = item.optString("device_name", "Device")
                        val created = item.optLong("created_at", 0L)
                        val lastSeen = item.optLong("last_seen_at", 0L)
                        val revoked = item.optBoolean("revoked", false)
                        list.add(
                            DeviceDto(
                                deviceId = devId,
                                deviceName = devName,
                                deviceType = if (devName.contains("Android", true)) "Mobile" else "Client",
                                lastSeenAt = if (lastSeen > 0) "Last seen ${java.text.SimpleDateFormat("MMM dd, HH:mm", java.util.Locale.US).format(java.util.Date(lastSeen * 1000L))}" else "Active",
                                isCurrent = currentDeviceId != null && devId == currentDeviceId,
                                revoked = revoked
                            )
                        )
                    }
                    Result.success(list)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun revokeDevice(deviceId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/devices/$deviceId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportAccount(): Result<AccountExportDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/account/export"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val userObj = obj.optJSONObject("user")
                    Result.success(
                        AccountExportDto(
                            format = obj.optString("format", "cloudmemo-export-v1"),
                            exportedAt = obj.optLong("exported_at", System.currentTimeMillis() / 1000L),
                            userEmail = userObj?.optString("email", sessionManager.userEmail.orEmpty()).orEmpty(),
                            userDisplayName = userObj?.optString("display_name", sessionManager.userDisplayName.orEmpty()).orEmpty(),
                            rawJson = body
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAccount(password: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/account"
            val json = JSONObject().apply {
                put("password", password)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    sessionManager.clearSession()
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ------------------------------------------------------------------
    // Generic helper + newer endpoints (account status, passwords, shares, notifications, push)
    // ------------------------------------------------------------------

    private suspend fun <T> call(
        method: String,
        path: String,
        json: JSONObject? = null,
        auth: Boolean = true,
        parse: (String) -> T
    ): Result<T> = withContext(Dispatchers.IO) {
        try {
            val builder = Request.Builder().url("${baseUrl()}$path")
            if (auth) {
                val token = sessionManager.authToken
                    ?: return@withContext Result.failure<T>(Exception("Not authenticated"))
                builder.addHeader("Authorization", "Bearer $token")
            }
            val body = (json ?: JSONObject()).toString().toRequestBody(JSON_MEDIA_TYPE)
            when (method) {
                "GET" -> builder.get()
                "POST" -> builder.post(body)
                "PUT" -> builder.put(body)
                else -> builder.delete()
            }
            client.newCall(builder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(parse(response.body?.string().orEmpty()))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAccountStatus(): Result<AccountStatusDto> = call("GET", "/v1/account/status") { body ->
        val o = JSONObject(body)
        AccountStatusDto(
            status = o.optString("status", "active"),
            code = o.optString("code", "OK"),
            message = o.optString("message", ""),
            userMessage = if (o.isNull("user_message")) null else o.optString("user_message"),
            mustChangePassword = o.optBoolean("must_change_password", false)
        )
    }

    suspend fun changePassword(currentPassword: String, newPassword: String): Result<PasswordChangeResultDto> =
        call(
            "POST", "/v1/auth/password/change",
            JSONObject().put("current_password", currentPassword).put("new_password", newPassword)
        ) { body ->
            val o = JSONObject(body)
            val token = o.getString("access_token")
            val expiresIn = o.optLong("expires_in", 3600L)
            // The server invalidates older tokens after a password change, so store the fresh one.
            sessionManager.saveAuth(
                token,
                sessionManager.userEmail.orEmpty(),
                sessionManager.userDisplayName.orEmpty(),
                sessionManager.userId.orEmpty(),
                sessionManager.userRole ?: "user",
                expiresIn
            )
            o.optString("refresh_token", "").ifBlank { null }?.let { sessionManager.refreshToken = it }
            PasswordChangeResultDto(token, expiresIn)
        }

    suspend fun forgotPassword(email: String): Result<Boolean> =
        call("POST", "/v1/auth/password/forgot", JSONObject().put("email", email.trim()), auth = false) { _ -> true }

    suspend fun resetPassword(email: String, code: String, newPassword: String): Result<Boolean> =
        call(
            "POST", "/v1/auth/password/reset",
            JSONObject().put("email", email.trim()).put("code", code.trim()).put("new_password", newPassword),
            auth = false
        ) { _ -> true }

    suspend fun logoutAll(): Result<Boolean> = call("POST", "/v1/auth/logout-all") { _ -> true }

    // ---- public shares ----

    private fun parseShare(o: JSONObject): PublicShareDto = PublicShareDto(
        shareId = o.getString("share_id"),
        noteId = o.optString("note_id", ""),
        url = o.optString("url", ""),
        createdAt = o.optLong("created_at", 0L),
        updatedAt = o.optLong("updated_at", 0L),
        expiresAt = if (o.isNull("expires_at")) null else o.optLong("expires_at"),
        maxViews = if (o.isNull("max_views")) null else o.optInt("max_views"),
        viewCount = o.optInt("view_count", 0),
        active = o.optBoolean("active", true)
    )

    suspend fun createShare(
        noteId: String,
        encryptedPayload: String,
        nonce: String,
        expiresInHours: Int?,
        maxViews: Int?
    ): Result<PublicShareDto> {
        val json = JSONObject()
            .put("note_id", noteId)
            .put("encrypted_payload", encryptedPayload)
            .put("nonce", nonce)
        if (expiresInHours != null) json.put("expires_in_hours", expiresInHours)
        if (maxViews != null) json.put("max_views", maxViews)
        return call("POST", "/v1/shares", json) { body ->
            val o = JSONObject(body)
            PublicShareDto(
                shareId = o.getString("share_id"),
                noteId = noteId,
                url = o.getString("url"),
                expiresAt = if (o.isNull("expires_at")) null else o.optLong("expires_at"),
                maxViews = maxViews
            )
        }
    }

    suspend fun listShares(noteId: String): Result<List<PublicShareDto>> =
        call("GET", "/v1/shares?note_id=" + java.net.URLEncoder.encode(noteId, "UTF-8")) { body ->
            val arr = JSONObject(body).optJSONArray("items") ?: JSONArray()
            (0 until arr.length()).map { parseShare(arr.getJSONObject(it)) }
        }

    suspend fun updateShare(shareId: String, encryptedPayload: String, nonce: String): Result<Boolean> =
        call(
            "PUT", "/v1/shares/$shareId",
            JSONObject().put("encrypted_payload", encryptedPayload).put("nonce", nonce)
        ) { _ -> true }

    suspend fun deleteShare(shareId: String): Result<Boolean> =
        call("DELETE", "/v1/shares/$shareId") { _ -> true }

    // ---- notifications & push ----

    suspend fun listNotifications(since: Long = 0L, limit: Int = 50): Result<NotificationListDto> =
        call("GET", "/v1/notifications?since=$since&limit=$limit") { body ->
            val o = JSONObject(body)
            val arr = o.optJSONArray("items") ?: JSONArray()
            val items = (0 until arr.length()).map { i ->
                val n = arr.getJSONObject(i)
                NotificationDto(
                    id = n.getString("id"),
                    title = n.optString("title", ""),
                    message = n.optString("message", ""),
                    severity = n.optString("severity", "info"),
                    createdAt = n.optLong("created_at", 0L),
                    expiresAt = if (n.isNull("expires_at")) null else n.optLong("expires_at"),
                    read = n.optBoolean("read", false)
                )
            }
            NotificationListDto(items, o.optInt("unread_count", 0))
        }

    suspend fun markNotificationsRead(): Result<Boolean> =
        call("POST", "/v1/notifications/mark-read") { _ -> true }

    suspend fun registerPushToken(deviceId: String, token: String, deviceName: String): Result<Boolean> =
        call(
            "POST", "/v1/devices/push-token",
            JSONObject().put("device_id", deviceId).put("fcm_token", token).put("device_name", deviceName)
        ) { _ -> true }

    // ---- vault key bundle (wrapped master key) ----

    /** Null when the account has no vault yet (HTTP 404). */
    suspend fun getKeyBundle(): Result<KeyBundle?> {
        val res = call<KeyBundle?>("GET", "/v1/account/key-bundle") { body ->
            val o = JSONObject(body)
            KeyBundle(
                version = o.getInt("version"),
                wrappedKey = o.getString("wrapped_key"),
                nonce = o.getString("nonce"),
                salt = o.getString("salt"),
                iterations = o.getInt("iterations")
            )
        }
        val err = res.exceptionOrNull()
        return if (err is ApiErrorDetail && err.statusCode == 404) Result.success(null) else res
    }

    /** First upload must use version 1; a rotation must use the current version + 1 (409 otherwise). */
    suspend fun putKeyBundle(bundle: KeyBundle): Result<Boolean> =
        call(
            "PUT", "/v1/account/key-bundle",
            JSONObject()
                .put("version", bundle.version)
                .put("wrapped_key", bundle.wrappedKey)
                .put("nonce", bundle.nonce)
                .put("salt", bundle.salt)
                .put("kdf", "pbkdf2-sha256")
                .put("iterations", bundle.iterations)
                .put("algorithm", "AES-256-GCM")
        ) { _ -> true }
}
