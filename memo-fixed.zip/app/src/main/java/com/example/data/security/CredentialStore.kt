package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * "Remember me": e-mail and password are kept only while the user keeps the option switched on, encrypted with an
 * Android Keystore backed key. They survive logout (that is the point) and are erased when the option is turned off.
 */
class CredentialStore(private val context: Context) {

    companion object {
        private const val FILE = "cloudmemo_saved_login"
        private const val KEY_ENABLED = "remember_me"
        private const val KEY_EMAIL = "email"
        private const val KEY_PASSWORD = "password"
    }

    private val prefs: SharedPreferences = create()

    private fun create(): SharedPreferences {
        fun build(): SharedPreferences {
            val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            build()
        } catch (e: Exception) {
            context.deleteSharedPreferences(FILE)
            build()
        }
    }

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false)

    fun savedEmail(): String? = if (isEnabled()) prefs.getString(KEY_EMAIL, null) else null

    /** @return Pair(email, password) or null when Remember me is off or nothing is stored. */
    fun load(): Pair<String, String>? {
        if (!isEnabled()) return null
        val email = prefs.getString(KEY_EMAIL, null) ?: return null
        val password = prefs.getString(KEY_PASSWORD, null) ?: return null
        return email to password
    }

    fun save(email: String, password: String) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, true)
            .putString(KEY_EMAIL, email)
            .putString(KEY_PASSWORD, password)
            .apply()
    }

    /** Turns Remember me on without a password yet (the first successful sign-in stores it). */
    fun enable() {
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
