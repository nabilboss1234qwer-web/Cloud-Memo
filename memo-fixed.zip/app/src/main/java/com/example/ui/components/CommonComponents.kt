package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.SyncState
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSpecularReflection
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextWhitePrimary

enum class BottomNavTab {
    HOME, SEARCH, FOLDERS, TRASH, SETTINGS
}

@Composable
fun CloudSyncProofBadge(
    syncState: SyncState,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val (icon, label, color) = when (syncState) {
        is SyncState.Syncing -> Triple(Icons.Default.CloudSync, "Syncing...", NeonCyan)
        is SyncState.Pending -> Triple(
            Icons.Default.CloudUpload,
            if (syncState.pendingCount > 0) "Pending (${syncState.pendingCount})" else "Saved Locally",
            Color(0xFFF59E0B)
        )
        is SyncState.Error -> Triple(Icons.Default.CloudQueue, "Saved Locally", Color(0xFFF59E0B))
        is SyncState.Synced -> Triple(Icons.Default.CloudDone, "Synced to Cloud", EmeraldOnline)
        is SyncState.Idle -> Triple(Icons.Default.CloudDone, "Synced to Cloud", EmeraldOnline)
    }

    val infiniteTransition = rememberInfiniteTransition(label = "sync_spin")
    val rotationAngle by if (syncState is SyncState.Syncing) {
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "spin_angle"
        )
    } else {
        remember { mutableStateOf(0f) }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.15f))
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(listOf(color.copy(alpha = 0.6f), GlassBorder)),
                shape = RoundedCornerShape(20.dp)
            )
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier
                    .size(15.dp)
                    .rotate(rotationAngle)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
fun CloudMemoTopAppBar(
    title: String,
    onNavigateBack: (() -> Unit)? = null,
    onMenuClick: (() -> Unit)? = null,
    syncState: SyncState = SyncState.Idle,
    onTriggerSync: (() -> Unit)? = null,
    menuItems: List<Pair<String, () -> Unit>> = emptyList()
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ObsidianVoid,
                        ObsidianSurface.copy(alpha = 0.95f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(GlassSpecularReflection, GlassBorder, GlassSpecularReflection)
                ),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                if (onNavigateBack != null) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhitePrimary
                        )
                    }
                } else {
                    AnimatedAestheticLogo(size = 32.dp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    Text(
                        text = title,
                        color = TextWhitePrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Sub-screens (notifications, devices, passphrase ...) have no sync action: no badge, more room for the title.
                if (onTriggerSync != null || syncState !is SyncState.Idle) {
                    CloudSyncProofBadge(
                        syncState = syncState,
                        onClick = onTriggerSync
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }

                if (menuItems.isNotEmpty() || onMenuClick != null) Box {
                    IconButton(onClick = {
                        if (menuItems.isNotEmpty()) {
                            menuExpanded = true
                        } else {
                            onMenuClick?.invoke()
                        }
                    }) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu Options",
                            tint = NeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    if (menuItems.isNotEmpty()) {
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                            modifier = Modifier
                                .background(ObsidianElevated)
                                .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                        ) {
                            menuItems.forEach { (label, action) ->
                                DropdownMenuItem(
                                    text = { Text(label, color = TextWhitePrimary, fontSize = 14.sp) },
                                    onClick = {
                                        menuExpanded = false
                                        action()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CloudMemoBottomNavBar(
    currentTab: BottomNavTab,
    onTabSelected: (BottomNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ObsidianSurface.copy(alpha = 0.96f),
                        ObsidianVoid
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(GlassSpecularReflection, GlassBorder, GlassSpecularReflection)
                ),
                shape = RoundedCornerShape(0.dp)
            )
            .navigationBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavButton(
                icon = Icons.Default.Home,
                label = "Notes",
                isSelected = currentTab == BottomNavTab.HOME,
                onClick = { onTabSelected(BottomNavTab.HOME) }
            )
            NavButton(
                icon = Icons.Default.Search,
                label = "Search",
                isSelected = currentTab == BottomNavTab.SEARCH,
                onClick = { onTabSelected(BottomNavTab.SEARCH) }
            )
            NavButton(
                icon = Icons.Default.Folder,
                label = "Folders",
                isSelected = currentTab == BottomNavTab.FOLDERS,
                onClick = { onTabSelected(BottomNavTab.FOLDERS) }
            )
            NavButton(
                icon = Icons.Default.Delete,
                label = "Trash",
                isSelected = currentTab == BottomNavTab.TRASH,
                onClick = { onTabSelected(BottomNavTab.TRASH) }
            )
            NavButton(
                icon = Icons.Default.Settings,
                label = "Settings",
                isSelected = currentTab == BottomNavTab.SETTINGS,
                onClick = { onTabSelected(BottomNavTab.SETTINGS) }
            )
        }
    }
}

@Composable
private fun NavButton(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeColor = NeonCyan
    val inactiveColor = TextMutedSecondary

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) activeColor else inactiveColor,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = if (isSelected) activeColor else inactiveColor,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}
