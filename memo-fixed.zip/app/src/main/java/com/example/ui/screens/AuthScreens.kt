package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnimatedAestheticLogo
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary
import kotlinx.coroutines.delay

@Composable
fun LoginScreen(
    emailInput: String,
    onEmailChange: (String) -> Unit,
    passwordInput: String,
    onPasswordChange: (String) -> Unit,
    displayNameInput: String,
    onDisplayNameChange: (String) -> Unit,
    isRegisterMode: Boolean,
    onToggleRegisterMode: (Boolean) -> Unit,
    isLoading: Boolean,
    onSubmit: () -> Unit,
    onOpenTermsOfService: (() -> Unit)? = null,
    onOpenPrivacyPolicy: (() -> Unit)? = null,
    onForgotPassword: (() -> Unit)? = null,
    rememberMe: Boolean = false,
    onRememberMeChange: ((Boolean) -> Unit)? = null
) {
    val focusManager = LocalFocusManager.current
    var passwordVisible by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedAestheticLogo(size = 72.dp)

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "CloudMemo",
                color = TextWhitePrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Zero-Knowledge End-to-End Encrypted Cloud Vault",
                color = TextMutedSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Auth Mode Toggle Tabs (Sign In vs Register)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ObsidianElevated)
                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!isRegisterMode) NeonCyan.copy(alpha = 0.2f) else Color.Transparent)
                        .clickable { onToggleRegisterMode(false) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Sign In",
                        color = if (!isRegisterMode) NeonCyan else TextMutedSecondary,
                        fontSize = 14.sp,
                        fontWeight = if (!isRegisterMode) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isRegisterMode) NeonCyan.copy(alpha = 0.2f) else Color.Transparent)
                        .clickable { onToggleRegisterMode(true) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Register",
                        color = if (isRegisterMode) NeonCyan else TextMutedSecondary,
                        fontSize = 14.sp,
                        fontWeight = if (isRegisterMode) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Main Auth Form Card
            CrystalGlassCard(
                modifier = Modifier.fillMaxWidth(),
                accentColor = NeonCyan
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isRegisterMode) "Create Encrypted Account" else "Sign In to Cloud Vault",
                        color = TextWhitePrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isRegisterMode)
                            "Create an account. Password must be at least 12 characters."
                        else
                            "Enter your email and password to sync your notes.",
                        color = TextTertiary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Display Name (only in register mode)
                    AnimatedVisibility(visible = isRegisterMode) {
                        Column {
                            OutlinedTextField(
                                value = displayNameInput,
                                onValueChange = onDisplayNameChange,
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Display Name (e.g. Alex)", color = TextTertiary) },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = NeonCyan)
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonCyan,
                                    unfocusedBorderColor = GlassBorder,
                                    focusedTextColor = TextWhitePrimary,
                                    unfocusedTextColor = TextWhitePrimary,
                                    cursorColor = NeonCyan,
                                    focusedContainerColor = ObsidianElevated,
                                    unfocusedContainerColor = ObsidianElevated
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                        }
                    }

                    // Email Field
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = onEmailChange,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("user@example.com", color = TextTertiary) },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = NeonCyan)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = TextWhitePrimary,
                            unfocusedTextColor = TextWhitePrimary,
                            cursorColor = NeonCyan,
                            focusedContainerColor = ObsidianElevated,
                            unfocusedContainerColor = ObsidianElevated
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Password Field
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = onPasswordChange,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(if (isRegisterMode) "Password (min 12 chars)" else "Password", color = TextTertiary) },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = NeonCyan)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility",
                                    tint = TextTertiary
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                onSubmit()
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = TextWhitePrimary,
                            unfocusedTextColor = TextWhitePrimary,
                            cursorColor = NeonCyan,
                            focusedContainerColor = ObsidianElevated,
                            unfocusedContainerColor = ObsidianElevated
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (isRegisterMode && passwordInput.isNotEmpty() && passwordInput.length < 12) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Password needs ${12 - passwordInput.length} more character(s)",
                            color = Color(0xFFF59E0B),
                            fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.Start)
                        )
                    }

                    if (!isRegisterMode && (onForgotPassword != null || onRememberMeChange != null)) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (onRememberMeChange != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { onRememberMeChange(!rememberMe) }
                                ) {
                                    Checkbox(
                                        checked = rememberMe,
                                        onCheckedChange = { onRememberMeChange(it) },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = NeonCyan,
                                            uncheckedColor = TextMutedSecondary,
                                            checkmarkColor = ObsidianVoid
                                        )
                                    )
                                    Text(
                                        text = "Remember me",
                                        color = TextMutedSecondary,
                                        fontSize = 13.sp
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.width(1.dp))
                            }
                            if (onForgotPassword != null) {
                                Text(
                                    text = "Forgot password?",
                                    color = NeonCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier
                                        .clickable { onForgotPassword() }
                                        .padding(vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (isLoading) {
                        CircularProgressIndicator(
                            color = NeonCyan,
                            modifier = Modifier.size(36.dp)
                        )
                    } else {
                        CrystalGlassButton(
                            onClick = onSubmit,
                            modifier = Modifier.fillMaxWidth(),
                            accentColor = NeonCyan
                        ) {
                            Text(
                                text = if (isRegisterMode) "Send Verification Code" else "Sign In to CloudMemo",
                                color = NeonCyan,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Terms of Service and Privacy Policy footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onOpenTermsOfService != null) {
                    Text(
                        text = "Terms of Service",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { onOpenTermsOfService() }
                    )
                }
                if (onOpenTermsOfService != null && onOpenPrivacyPolicy != null) {
                    Text(
                        text = " • ",
                        color = TextTertiary,
                        fontSize = 12.sp
                    )
                }
                if (onOpenPrivacyPolicy != null) {
                    Text(
                        text = "Privacy Policy",
                        color = ElectricViolet,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { onOpenPrivacyPolicy() }
                    )
                }
            }
        }
    }
}

@Composable
fun VerifyEmailScreen(
    email: String,
    codeInput: String,
    onCodeChange: (String) -> Unit,
    isLoading: Boolean,
    isResending: Boolean,
    onVerify: () -> Unit,
    onResendCode: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var cooldownSeconds by remember { mutableIntStateOf(60) }

    LaunchedEffect(key1 = email) {
        while (cooldownSeconds > 0) {
            delay(1000L)
            cooldownSeconds -= 1
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = TextWhitePrimary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Verify Your Email",
                color = TextWhitePrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "A 25-digit verification code was sent to:\n$email",
                color = TextMutedSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            CrystalGlassCard(
                modifier = Modifier.fillMaxWidth(),
                accentColor = NeonCyan
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Enter 25-Digit Code",
                        color = TextWhitePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { input ->
                            // Allow only digits, max 25 chars
                            val digitsOnly = input.filter { it.isDigit() }.take(25)
                            onCodeChange(digitsOnly)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("1234567890123456789012345", color = TextTertiary) },
                        leadingIcon = {
                            Icon(Icons.Default.Key, contentDescription = null, tint = NeonCyan)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = TextWhitePrimary,
                            unfocusedTextColor = TextWhitePrimary,
                            cursorColor = NeonCyan,
                            focusedContainerColor = ObsidianElevated,
                            unfocusedContainerColor = ObsidianElevated
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Length: ${codeInput.length}/25 digits",
                        color = if (codeInput.length == 25) EmeraldOnline else TextTertiary,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    if (isLoading) {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(32.dp))
                        }
                    } else {
                        CrystalGlassButton(
                            onClick = onVerify,
                            modifier = Modifier.fillMaxWidth(),
                            accentColor = NeonCyan,
                            enabled = codeInput.length == 25
                        ) {
                            Text(
                                text = "Verify & Access Cloud Notes",
                                color = if (codeInput.length == 25) NeonCyan else TextMutedSecondary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Resend Code with cooldown timer
                    if (isResending) {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = ElectricViolet, modifier = Modifier.size(24.dp))
                        }
                    } else {
                        val canResend = cooldownSeconds <= 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(enabled = canResend) {
                                    if (canResend) {
                                        cooldownSeconds = 60
                                        onResendCode()
                                    }
                                }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = if (canResend) ElectricViolet else TextTertiary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (canResend) "Resend Verification Code" else "Resend code in ${cooldownSeconds}s",
                                color = if (canResend) ElectricViolet else TextTertiary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}
