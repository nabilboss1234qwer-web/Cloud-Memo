package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.ViewHeadline
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NoteEntity
import com.example.data.repository.SyncState
import com.example.ui.components.AnimatedAestheticLogo
import com.example.ui.components.CloudMemoTopAppBar
import com.example.ui.components.CrystalGlassCard
import com.example.ui.components.CrystalGlassChip
import com.example.ui.model.NoteDisplayLayout
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSpecularReflection
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    notes: List<NoteEntity>,
    selectedFilter: String,
    onFilterSelect: (String) -> Unit,
    noteDisplayLayout: NoteDisplayLayout = NoteDisplayLayout.GRID_VIEW,
    onSelectLayout: (NoteDisplayLayout) -> Unit = {},
    onNoteClick: (NoteEntity) -> Unit,
    onTogglePin: (String, Boolean) -> Unit,
    onToggleFavorite: (String, Boolean) -> Unit,
    onNewNoteClick: () -> Unit,
    onSearchClick: () -> Unit,
    onOpenDrawer: () -> Unit,
    syncState: SyncState,
    onTriggerSync: () -> Unit
) {
    val filters = listOf("All", "Pinned", "Favorites", "Personal", "Work", "Ideas")

    val filteredNotes = notes.filter { note ->
        when (selectedFilter) {
            "Pinned" -> note.isPinned
            "Favorites" -> note.isFavorite
            "All" -> true
            else -> note.folder.equals(selectedFilter, ignoreCase = true)
        }
    }

    val noteCountText = when {
        notes.isEmpty() -> "0 Notes"
        notes.size == 1 -> "1 Note"
        notes.size > 999 -> "999+ Notes"
        else -> "${notes.size} Notes"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top App Bar
            CloudMemoTopAppBar(
                title = "CloudMemo",
                onMenuClick = onOpenDrawer,
                syncState = syncState,
                onTriggerSync = onTriggerSync
            )

            // 2.1 Fixed Home Screen Synchronization Banner (Responsive, wrapping safe, note count attached)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                EmeraldOnline.copy(alpha = 0.12f),
                                NeonCyan.copy(alpha = 0.08f)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(EmeraldOnline.copy(alpha = 0.4f), GlassBorder)
                        ),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "E2E Encrypted Active",
                            tint = EmeraldOnline,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "E2E Encrypted Notes",
                            color = TextWhitePrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonCyan.copy(alpha = 0.15f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = noteCountText,
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            // Controls Row: 2.2 Category Chips (Fixed padding/clip) & 3. Note Display Layout Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chips with clipToPadding = false so left/right are never cut off
                LazyRow(
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 2.dp),
                    contentPadding = PaddingValues(start = 14.dp, end = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filters) { filter ->
                        CrystalGlassChip(
                            text = filter,
                            isSelected = selectedFilter == filter,
                            onClick = { onFilterSelect(filter) }
                        )
                    }
                }

                // Layout Selector Bar
                NoteLayoutSelector(
                    selectedLayout = noteDisplayLayout,
                    onSelectLayout = onSelectLayout,
                    modifier = Modifier.padding(end = 14.dp)
                )
            }

            // Notes Content according to chosen Layout mode
            if (filteredNotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        AnimatedAestheticLogo(size = 64.dp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (selectedFilter == "All") "No notes found" else "No $selectedFilter notes",
                            color = TextWhitePrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap the + button to create a client-side encrypted note",
                            color = TextMutedSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                when (noteDisplayLayout) {
                    NoteDisplayLayout.GRID_VIEW -> {
                        // 1. Grid View: 2-column cards where screen width permits
                        LazyVerticalStaggeredGrid(
                            columns = StaggeredGridCells.Fixed(2),
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f),
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 120.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalItemSpacing = 10.dp
                        ) {
                            items(filteredNotes, key = { it.id }) { note ->
                                NoteCardItem(
                                    note = note,
                                    onClick = { onNoteClick(note) },
                                    onTogglePin = { onTogglePin(note.id, !note.isPinned) },
                                    onToggleFavorite = { onToggleFavorite(note.id, !note.isFavorite) }
                                )
                            }
                        }
                    }
                    NoteDisplayLayout.COMPACT_LIST -> {
                        // 2. Compact List: Compact rows for browsing many notes efficiently
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f),
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(filteredNotes, key = { it.id }) { note ->
                                NoteCompactListItem(
                                    note = note,
                                    onClick = { onNoteClick(note) },
                                    onTogglePin = { onTogglePin(note.id, !note.isPinned) },
                                    onToggleFavorite = { onToggleFavorite(note.id, !note.isFavorite) }
                                )
                            }
                        }
                    }
                    NoteDisplayLayout.COMFORTABLE_LIST -> {
                        // 3. Comfortable List: Larger rows with more preview text
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f),
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredNotes, key = { it.id }) { note ->
                                NoteComfortableListItem(
                                    note = note,
                                    onClick = { onNoteClick(note) },
                                    onTogglePin = { onTogglePin(note.id, !note.isPinned) },
                                    onToggleFavorite = { onToggleFavorite(note.id, !note.isFavorite) }
                                )
                            }
                        }
                    }
                    NoteDisplayLayout.LARGE_CARDS -> {
                        // 4. Large Cards: Expanded cards with large previews
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f),
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(filteredNotes, key = { it.id }) { note ->
                                NoteLargeCardItem(
                                    note = note,
                                    onClick = { onNoteClick(note) },
                                    onTogglePin = { onTogglePin(note.id, !note.isPinned) },
                                    onToggleFavorite = { onToggleFavorite(note.id, !note.isFavorite) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = onNewNoteClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 96.dp)
                .shadow(12.dp, CircleShape, spotColor = NeonCyan),
            containerColor = NeonCyan,
            contentColor = ObsidianVoid,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "New Note",
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun NoteLayoutSelector(
    selectedLayout: NoteDisplayLayout,
    onSelectLayout: (NoteDisplayLayout) -> Unit,
    modifier: Modifier = Modifier
) {
    // One compact button + menu instead of four icons: the category chips keep the width they need.
    var expanded by remember { mutableStateOf(false) }
    val options = listOf(
        Triple(NoteDisplayLayout.GRID_VIEW, Icons.Default.GridView, "Grid"),
        Triple(NoteDisplayLayout.COMPACT_LIST, Icons.Default.ViewHeadline, "Compact list"),
        Triple(NoteDisplayLayout.COMFORTABLE_LIST, Icons.Default.ViewList, "Comfortable list"),
        Triple(NoteDisplayLayout.LARGE_CARDS, Icons.Default.Dashboard, "Large cards")
    )
    val current = options.firstOrNull { it.first == selectedLayout } ?: options.first()
    Box(modifier = modifier) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(ObsidianElevated)
                .border(1.dp, GlassBorder, RoundedCornerShape(10.dp))
                .clickable { expanded = true },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = current.second,
                contentDescription = "Change layout",
                tint = NeonCyan,
                modifier = Modifier.size(20.dp)
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (layout, icon, label) ->
                DropdownMenuItem(
                    text = { Text(label, color = if (layout == selectedLayout) NeonCyan else TextWhitePrimary) },
                    leadingIcon = {
                        Icon(icon, contentDescription = null, tint = if (layout == selectedLayout) NeonCyan else TextTertiary)
                    },
                    onClick = {
                        onSelectLayout(layout)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun LayoutButton(
    icon: ImageVector,
    description: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) NeonCyan.copy(alpha = 0.25f) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = if (isSelected) NeonCyan else TextTertiary,
            modifier = Modifier.size(17.dp)
        )
    }
}

// 1. Grid Card Item
@Composable
fun NoteCardItem(
    note: NoteEntity,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val accentColor = try {
        Color(android.graphics.Color.parseColor(note.colorHex))
    } catch (_: Exception) {
        NeonCyan
    }

    CrystalGlassCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = accentColor,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = note.folder.ifBlank { "Personal" },
                        color = accentColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.isPinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = NeonCyan,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable(onClick = onTogglePin)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Icon(
                        imageVector = if (note.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (note.isFavorite) Color(0xFFF72585) else TextTertiary,
                        modifier = Modifier
                            .size(14.dp)
                            .clickable(onClick = onToggleFavorite)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = note.decryptedTitleCache.ifBlank { "Untitled Note" },
                color = TextWhitePrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (note.decryptedContentCache.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = note.decryptedContentCache,
                    color = TextMutedSecondary,
                    fontSize = 12.sp,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Encrypted",
                        tint = EmeraldOnline,
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "AES-256",
                        color = EmeraldOnline,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (note.updatedAt.length >= 10) note.updatedAt.take(10) else "Synced",
                    color = TextTertiary,
                    fontSize = 9.sp
                )
            }
        }
    }
}

// 2. Compact List Item
@Composable
fun NoteCompactListItem(
    note: NoteEntity,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val accentColor = try {
        Color(android.graphics.Color.parseColor(note.colorHex))
    } catch (_: Exception) {
        NeonCyan
    }

    CrystalGlassCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = accentColor,
        shape = RoundedCornerShape(12.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Folder tag pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = note.folder.ifBlank { "Personal" },
                        color = accentColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = note.decryptedTitleCache.ifBlank { "Untitled Note" },
                    color = TextWhitePrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (note.isPinned) {
                    Icon(
                        imageVector = Icons.Default.PushPin,
                        contentDescription = "Pinned",
                        tint = NeonCyan,
                        modifier = Modifier
                            .size(13.dp)
                            .clickable(onClick = onTogglePin)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }

                Icon(
                    imageVector = if (note.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (note.isFavorite) Color(0xFFF72585) else TextTertiary,
                    modifier = Modifier
                        .size(14.dp)
                        .clickable(onClick = onToggleFavorite)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = if (note.updatedAt.length >= 10) note.updatedAt.take(10) else "Synced",
                    color = TextTertiary,
                    fontSize = 9.sp
                )
            }
        }
    }
}

// 3. Comfortable List Item
@Composable
fun NoteComfortableListItem(
    note: NoteEntity,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val accentColor = try {
        Color(android.graphics.Color.parseColor(note.colorHex))
    } catch (_: Exception) {
        NeonCyan
    }

    CrystalGlassCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = accentColor,
        shape = RoundedCornerShape(14.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(accentColor.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = note.folder.ifBlank { "Personal" },
                            color = accentColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = note.decryptedTitleCache.ifBlank { "Untitled Note" },
                        color = TextWhitePrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.isPinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = NeonCyan,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable(onClick = onTogglePin)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Icon(
                        imageVector = if (note.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (note.isFavorite) Color(0xFFF72585) else TextTertiary,
                        modifier = Modifier
                            .size(15.dp)
                            .clickable(onClick = onToggleFavorite)
                    )
                }
            }

            if (note.decryptedContentCache.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = note.decryptedContentCache,
                    color = TextMutedSecondary,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "AES-256",
                        tint = EmeraldOnline,
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "AES-256-GCM",
                        color = EmeraldOnline,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (note.updatedAt.length >= 10) note.updatedAt.take(10) else "Synced",
                    color = TextTertiary,
                    fontSize = 10.sp
                )
            }
        }
    }
}

// 4. Large Card Item
@Composable
fun NoteLargeCardItem(
    note: NoteEntity,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val accentColor = try {
        Color(android.graphics.Color.parseColor(note.colorHex))
    } catch (_: Exception) {
        NeonCyan
    }

    CrystalGlassCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = accentColor,
        shape = RoundedCornerShape(16.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(accentColor.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "📁 ${note.folder.ifBlank { "Personal" }}",
                            color = accentColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (note.decryptedTagsCache.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = note.decryptedTagsCache,
                            color = NeonCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.isPinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = NeonCyan,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable(onClick = onTogglePin)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                    }
                    Icon(
                        imageVector = if (note.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (note.isFavorite) Color(0xFFF72585) else TextTertiary,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable(onClick = onToggleFavorite)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = note.decryptedTitleCache.ifBlank { "Untitled Note" },
                color = TextWhitePrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (note.decryptedContentCache.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = note.decryptedContentCache,
                    color = TextMutedSecondary,
                    fontSize = 13.sp,
                    maxLines = 5,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Encrypted",
                        tint = EmeraldOnline,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Client-Side AES-256-GCM Encrypted",
                        color = EmeraldOnline,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (note.updatedAt.length >= 10) note.updatedAt.take(10) else "Synced",
                    color = TextTertiary,
                    fontSize = 10.sp
                )
            }
        }
    }
}
