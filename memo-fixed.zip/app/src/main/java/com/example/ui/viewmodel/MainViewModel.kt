package com.example.ui.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.crypto.KeystoreHelper
import com.example.data.local.AppDatabase
import com.example.data.model.AccountExportDto
import com.example.data.model.DeviceDto
import com.example.data.model.NoteEntity
import com.example.data.model.ApiErrorDetail
import com.example.data.model.NotificationDto
import com.example.data.model.PublicShareDto
import com.example.data.model.UserProfileDto
import com.example.data.network.AccessEvent
import com.example.data.network.AccessEvents
import com.example.data.network.CloudMemoApiService
import com.example.data.network.SessionManager
import com.example.data.repository.AuthRepository
import com.example.data.repository.NoteRepository
import com.example.data.repository.SyncState
import com.example.data.security.CredentialStore
import com.example.data.security.ShareKeyStore
import com.example.data.security.VaultLockManager
import com.example.push.PushRegistrar
import com.example.data.crypto.VaultCrypto
import com.example.data.crypto.WrongPassphraseException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Stack

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val sessionManager = SessionManager(application)
    private val keystoreHelper = KeystoreHelper(application)
    private val apiService = CloudMemoApiService(sessionManager)
    private val database = AppDatabase.getInstance(application)
    val vaultLockManager = VaultLockManager(application)

    val authRepository = AuthRepository(sessionManager, apiService, keystoreHelper)
    private val shareKeyStore = ShareKeyStore(application)
    private val credentialStore = CredentialStore(application)
    private val savedLogin: Pair<String, String>? = credentialStore.load()
    val noteRepository = NoteRepository(database, keystoreHelper, apiService, sessionManager, shareKeyStore)

    // Note display layout preference
    private val _noteDisplayLayout = MutableStateFlow(
        com.example.ui.model.NoteDisplayLayout.fromId(sessionManager.noteDisplayLayout)
    )
    val noteDisplayLayout: StateFlow<com.example.ui.model.NoteDisplayLayout> = _noteDisplayLayout.asStateFlow()

    // Navigation Stack
    private val screenStack = Stack<AppScreen>()
    private val _currentScreen = MutableStateFlow<AppScreen>(
        when {
            !sessionManager.isTosAccepted -> AppScreen.TERMS_OF_SERVICE
            !sessionManager.isLoggedIn -> AppScreen.LOGIN
            vaultLockManager.isVaultLockEnabled -> AppScreen.PIN_LOCK
            else -> AppScreen.HOME
        }
    )
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Notes & Data flows
    val notes: StateFlow<List<NoteEntity>> = noteRepository.notes.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val trashedNotes: StateFlow<List<NoteEntity>> = noteRepository.trashedNotes.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val pendingSyncCount: StateFlow<Int> = noteRepository.pendingSyncCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    // Sync State
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Synced("Synced to Cloud"))
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private var autoSaveJob: Job? = null

    init {
        viewModelScope.launch {
            try {
                pendingSyncCount.collect { count ->
                    if (count > 0 && _syncState.value !is SyncState.Syncing) {
                        _syncState.value = SyncState.Pending(count, "Saved Locally")
                    } else if (count == 0 && _syncState.value is SyncState.Pending) {
                        _syncState.value = SyncState.Synced("Synced to Cloud")
                    }
                }
            } catch (e: Exception) {
                // Ignore or log
            }
        }
        if (sessionManager.isLoggedIn) {
            try {
                loadUserProfile()
                triggerManualSync()
            } catch (e: Exception) {
                // Graceful offline fallback
            }
        }
    }

    init {
        viewModelScope.launch {
            AccessEvents.flow.collect { handleAccessEvent(it) }
        }
        viewModelScope.launch {
            AccessEvents.statusCheck.collect { checkAccountStatus() }
        }
        viewModelScope.launch {
            AccessEvents.inboxRefresh.collect { loadNotifications() }
        }
        if (sessionManager.isLoggedIn) {
            checkAccountStatus()
            registerPush()
            loadNotifications()
            if (!keystoreHelper.vault.hasMasterKey()) startVaultFlow()
        }
    }

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1500L)
            saveCurrentNote(isManual = false)
        }
    }

    // Auth State
    val isLoggedIn: Boolean get() = sessionManager.isLoggedIn
    val userEmail: String? get() = sessionManager.userEmail
    val userDisplayName: String? get() = sessionManager.userDisplayName
    val userId: String? get() = sessionManager.userId
    val userRole: String? get() = sessionManager.userRole

    // Note Editor State (SAFE NON-NULL INITIALIZATION TO PREVENT CRASHES)
    private val _editorState = MutableStateFlow(NoteEditorState())
    val editorState: StateFlow<NoteEditorState> = _editorState.asStateFlow()

    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<NoteEntity>>(emptyList())
    val searchResults: StateFlow<List<NoteEntity>> = _searchResults.asStateFlow()

    private val _selectedFilter = MutableStateFlow("All")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    // Auth Inputs (FastAPI Integration)
    private val _authEmailInput = MutableStateFlow(savedLogin?.first ?: "")
    val authEmailInput: StateFlow<String> = _authEmailInput.asStateFlow()

    private val _authPasswordInput = MutableStateFlow(savedLogin?.second ?: "")
    val authPasswordInput: StateFlow<String> = _authPasswordInput.asStateFlow()

    private val _authDisplayNameInput = MutableStateFlow("")
    val authDisplayNameInput: StateFlow<String> = _authDisplayNameInput.asStateFlow()

    private val _isRegisterMode = MutableStateFlow(false)
    val isRegisterMode: StateFlow<Boolean> = _isRegisterMode.asStateFlow()

    private val _verificationCodeInput = MutableStateFlow("")
    val verificationCodeInput: StateFlow<String> = _verificationCodeInput.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authResending = MutableStateFlow(false)
    val authResending: StateFlow<Boolean> = _authResending.asStateFlow()

    private val _authMessage = MutableStateFlow<String?>(null)
    val authMessage: StateFlow<String?> = _authMessage.asStateFlow()

    // Profile & Export
    private val _userProfile = MutableStateFlow<UserProfileDto?>(null)
    val userProfile: StateFlow<UserProfileDto?> = _userProfile.asStateFlow()

    private val _accountExportData = MutableStateFlow<AccountExportDto?>(null)
    val accountExportData: StateFlow<AccountExportDto?> = _accountExportData.asStateFlow()

    // Devices & Shares
    private val _devicesList = MutableStateFlow<List<DeviceDto>>(emptyList())
    val devicesList: StateFlow<List<DeviceDto>> = _devicesList.asStateFlow()

    private val _activeShares = MutableStateFlow<List<PublicShareDto>>(emptyList())
    val activeShares: StateFlow<List<PublicShareDto>> = _activeShares.asStateFlow()

    // Settings State
    private val _rememberMe = MutableStateFlow(credentialStore.isEnabled())
    val rememberMe: StateFlow<Boolean> = _rememberMe.asStateFlow()

    fun setRememberMe(enabled: Boolean) {
        _rememberMe.value = enabled
        if (enabled) credentialStore.enable() else credentialStore.clear()
    }

    // Account access (locked / banned / password change required)
    private val _accessBlock = MutableStateFlow<AccessBlockState?>(null)
    val accessBlock: StateFlow<AccessBlockState?> = _accessBlock.asStateFlow()

    private val _forcePasswordChange = MutableStateFlow(false)
    val forcePasswordChange: StateFlow<Boolean> = _forcePasswordChange.asStateFlow()

    // Vault (multi-device master key)
    private val _vaultGate = MutableStateFlow<VaultGate?>(null)
    val vaultGate: StateFlow<VaultGate?> = _vaultGate.asStateFlow()

    private val _vaultBusy = MutableStateFlow(false)
    val vaultBusy: StateFlow<Boolean> = _vaultBusy.asStateFlow()

    private val _recoveryKey = MutableStateFlow<String?>(null)
    val recoveryKey: StateFlow<String?> = _recoveryKey.asStateFlow()

    private var vaultFailures = 0
    private var vaultLockedUntil = 0L

    private val _passwordBusy = MutableStateFlow(false)
    val passwordBusy: StateFlow<Boolean> = _passwordBusy.asStateFlow()

    private val _resetCodeSent = MutableStateFlow(false)
    val resetCodeSent: StateFlow<Boolean> = _resetCodeSent.asStateFlow()

    private val _logoutWarning = MutableStateFlow<Int?>(null)
    val logoutWarning: StateFlow<Int?> = _logoutWarning.asStateFlow()

    private val _secureScreen = MutableStateFlow(sessionManager.secureScreenEnabled)
    val secureScreen: StateFlow<Boolean> = _secureScreen.asStateFlow()

    fun setSecureScreen(enabled: Boolean) {
        sessionManager.secureScreenEnabled = enabled
        _secureScreen.value = enabled
    }

    fun openNotificationsFromPush() {
        if (sessionManager.isLoggedIn) {
            loadNotifications()
            navigateTo(AppScreen.NOTIFICATIONS)
        }
    }

    // Notification inbox
    private val _notifications = MutableStateFlow<List<NotificationDto>>(emptyList())
    val notifications: StateFlow<List<NotificationDto>> = _notifications.asStateFlow()

    private val _unreadNotifications = MutableStateFlow(0)
    val unreadNotifications: StateFlow<Int> = _unreadNotifications.asStateFlow()

    val undecryptableNotes: StateFlow<Int> get() = noteRepository.undecryptableNotes

    private val _themeMode = MutableStateFlow(sessionManager.themeMode)
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _autoSync = MutableStateFlow(sessionManager.isAutoSyncEnabled)
    val autoSync: StateFlow<Boolean> = _autoSync.asStateFlow()

    // Snackbar notifications
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val isTosAccepted: Boolean get() = sessionManager.isTosAccepted
    val acceptedTosVersion: String? get() = sessionManager.acceptedTosVersion

    fun acceptTermsOfService() {
        sessionManager.acceptTos()
        // Fresh install flow: Terms of Service -> Accept -> Backend Login
        navigateTo(AppScreen.LOGIN, clearStack = true)
    }

    fun setNoteDisplayLayout(layout: com.example.ui.model.NoteDisplayLayout) {
        sessionManager.noteDisplayLayout = layout.id
        _noteDisplayLayout.value = layout
    }

    fun navigateTo(screen: AppScreen, clearStack: Boolean = false) {
        // Enforce access control: Do not allow protected screens if ToS not accepted
        if (!sessionManager.isTosAccepted && screen != AppScreen.TERMS_OF_SERVICE && screen != AppScreen.PRIVACY_POLICY) {
            _currentScreen.value = AppScreen.TERMS_OF_SERVICE
            return
        }
        // Enforce authentication: Do not allow protected screens if not logged in
        val protectedScreens = setOf(
            AppScreen.HOME, AppScreen.NOTE_EDITOR, AppScreen.SEARCH,
            AppScreen.FOLDERS_TAGS, AppScreen.TRASH, AppScreen.SYNC_STATUS,
            AppScreen.DEVICES, AppScreen.SETTINGS, AppScreen.ACCOUNT,
            AppScreen.SHARE_NOTE, AppScreen.PIN_SETUP, AppScreen.NOTIFICATIONS,
            AppScreen.CHANGE_PASSWORD, AppScreen.FORCE_PASSWORD_CHANGE
        )
        if (screen in protectedScreens && !sessionManager.isLoggedIn) {
            _currentScreen.value = AppScreen.LOGIN
            return
        }
        // A locked/banned account or a required password change keeps the user on its own screen.
        val neutral = setOf(AppScreen.LOGIN, AppScreen.TERMS_OF_SERVICE, AppScreen.PRIVACY_POLICY, AppScreen.SPLASH, AppScreen.FORGOT_PASSWORD)
        if (_accessBlock.value != null && screen != AppScreen.ACCOUNT_BLOCKED && screen !in neutral) {
            _currentScreen.value = AppScreen.ACCOUNT_BLOCKED
            return
        }
        if (_forcePasswordChange.value && screen != AppScreen.FORCE_PASSWORD_CHANGE && screen !in neutral) {
            _currentScreen.value = AppScreen.FORCE_PASSWORD_CHANGE
            return
        }
        val gate = _vaultGate.value
        if (gate != null && screen != AppScreen.VAULT_SETUP && screen != AppScreen.VAULT_UNLOCK && screen !in neutral) {
            _currentScreen.value = if (gate == VaultGate.NEEDS_SETUP) AppScreen.VAULT_SETUP else AppScreen.VAULT_UNLOCK
            return
        }

        if (clearStack) {
            screenStack.clear()
        } else {
            screenStack.push(_currentScreen.value)
        }
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (!screenStack.isEmpty()) {
            _currentScreen.value = screenStack.pop()
            return true
        }
        return false
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun setAuthEmail(email: String) {
        _authEmailInput.value = email
    }

    fun setAuthPassword(password: String) {
        _authPasswordInput.value = password
    }

    fun setAuthDisplayName(name: String) {
        _authDisplayNameInput.value = name
    }

    fun toggleRegisterMode(isRegister: Boolean) {
        _isRegisterMode.value = isRegister
    }

    fun setVerificationCode(code: String) {
        _verificationCodeInput.value = code
    }

    fun submitAuth() {
        val email = _authEmailInput.value.trim()
        val password = _authPasswordInput.value
        val displayName = _authDisplayNameInput.value.trim().ifBlank { "CloudMemo User" }

        if (email.isBlank() || !email.contains("@")) {
            showSnackbar("Please enter a valid email address.")
            return
        }

        if (_isRegisterMode.value) {
            // Register flow (FastAPI Backend: password min 12 chars)
            if (password.length < 12) {
                showSnackbar("Password must be at least 12 characters long.")
                return
            }
            _authLoading.value = true
            viewModelScope.launch {
                val res = authRepository.register(email, password, displayName)
                _authLoading.value = false
                res.onSuccess { regResponse ->
                    showSnackbar(regResponse.message)
                    _verificationCodeInput.value = ""
                    navigateTo(AppScreen.VERIFY_EMAIL)
                }.onFailure { err ->
                    showSnackbar(err.message ?: "Registration failed.")
                }
            }
        } else {
            // Login flow
            if (password.isBlank()) {
                showSnackbar("Please enter your password.")
                return
            }
            _authLoading.value = true
            viewModelScope.launch {
                val deviceName = "Android Phone (${android.os.Build.MODEL})"
                val res = authRepository.login(email, password, deviceName)
                _authLoading.value = false
                res.onSuccess { auth ->
                    if (_rememberMe.value) credentialStore.save(email, password) else credentialStore.clear()
                    if (!_rememberMe.value) _authPasswordInput.value = ""   // never keep a typed password in memory
                    onSignedIn(auth.user, "Successfully signed in!")
                }.onFailure { err ->
                    val msg = err.message ?: "Authentication failed."
                    val apiErr = err as? ApiErrorDetail
                    if (apiErr?.code != null && apiErr.code.startsWith("ACCOUNT_")) {
                        // The blocked-account screen is shown by the access-event handler.
                    } else if (msg.contains("verify", ignoreCase = true) || msg.contains("verification", ignoreCase = true)) {
                        showSnackbar("Email verification required. Sending code...")
                        resendVerificationCode()
                        navigateTo(AppScreen.VERIFY_EMAIL)
                    } else {
                        showSnackbar(msg)
                    }
                }
            }
        }
    }

    fun verifyEmailCode() {
        val email = _authEmailInput.value.trim()
        val code = _verificationCodeInput.value.trim()

        if (code.length != 25) {
            showSnackbar("Verification code must be exactly 25 digits.")
            return
        }

        _authLoading.value = true
        viewModelScope.launch {
            val res = authRepository.verifyEmail(email, code)
            _authLoading.value = false
            res.onSuccess { auth ->
                onSignedIn(auth.user, "Email verified successfully!")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Verification failed. Please check the 25-digit code.")
            }
        }
    }

    fun resendVerificationCode() {
        val email = _authEmailInput.value.trim()
        if (email.isBlank() || !email.contains("@")) {
            showSnackbar("Please enter a valid email address.")
            return
        }

        _authResending.value = true
        viewModelScope.launch {
            val res = authRepository.resendCode(email)
            _authResending.value = false
            res.onSuccess { regResponse ->
                showSnackbar("A new 25-digit verification code has been dispatched to $email")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Failed to resend code.")
            }
        }
    }

    fun loadUserProfile() {
        if (!sessionManager.isLoggedIn) return
        viewModelScope.launch {
            val res = authRepository.getCurrentUser()
            res.onSuccess { profile ->
                _userProfile.value = profile
            }
        }
    }

    fun exportAccount() {
        viewModelScope.launch {
            val res = authRepository.exportAccount()
            res.onSuccess { exportDto ->
                _accountExportData.value = exportDto
                showSnackbar("Export successful for ${exportDto.userEmail}! Encrypted backup ready.")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Failed to export account data.")
            }
        }
    }

    fun deleteAccount(password: String, onSuccess: () -> Unit) {
        if (password.isBlank()) {
            showSnackbar("Password is required to delete account.")
            return
        }
        viewModelScope.launch {
            val res = authRepository.deleteAccount(password)
            res.onSuccess {
                PushRegistrar.unregister(getApplication())
                noteRepository.wipeLocalData()
                sessionManager.clearSession()
                _accessBlock.value = null
                _forcePasswordChange.value = false
                showSnackbar("Account and all encrypted data permanently deleted.")
                onSuccess()
                navigateTo(AppScreen.LOGIN, clearStack = true)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Account deletion failed. Check password.")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            val pending = if (sessionManager.isLoggedIn) noteRepository.pendingOperationCount() else 0
            if (pending > 0) {
                _logoutWarning.value = pending   // the UI asks before unsynced notes are discarded
            } else {
                performLogout()
            }
        }
    }

    // SAFE NOTE CREATION (FIXES CRASH: ALWAYS NON-NULL FIELDS)
    fun startNewNote() {
        _editorState.value = NoteEditorState(
            id = null,
            title = "",
            content = "",
            tags = "",
            folder = "Personal",
            colorHex = "#00F5D4",
            isPinned = false,
            isFavorite = false,
            isMarkdownPreview = false,
            lastSavedText = "Draft created"
        )
        navigateTo(AppScreen.NOTE_EDITOR)
    }

    fun openNoteForEdit(note: NoteEntity) {
        _editorState.value = NoteEditorState(
            id = note.id,
            title = note.decryptedTitleCache,
            content = note.decryptedContentCache,
            tags = note.decryptedTagsCache,
            folder = note.folder.ifBlank { "Personal" },
            colorHex = note.colorHex.ifBlank { "#00F5D4" },
            isPinned = note.isPinned,
            isFavorite = note.isFavorite,
            isMarkdownPreview = false,
            revision = note.revision,
            lastSavedText = "Synced to Cloud"
        )
        navigateTo(AppScreen.NOTE_EDITOR)
        loadSharesForNote(note.id)
    }

    fun updateEditorTitle(title: String) {
        _editorState.value = _editorState.value.copy(
            title = title,
            lastSavedText = "Saving to Room..."
        )
        scheduleAutoSave()
    }

    fun updateEditorContent(content: String) {
        _editorState.value = _editorState.value.copy(
            content = content,
            lastSavedText = "Saving to Room..."
        )
        scheduleAutoSave()
    }

    fun updateEditorTags(tags: String) {
        _editorState.value = _editorState.value.copy(tags = tags)
        scheduleAutoSave()
    }

    fun updateEditorFolder(folder: String) {
        _editorState.value = _editorState.value.copy(folder = folder)
        scheduleAutoSave()
    }

    fun updateEditorColor(colorHex: String) {
        _editorState.value = _editorState.value.copy(colorHex = colorHex)
        scheduleAutoSave()
    }

    fun toggleMarkdownPreview() {
        _editorState.value = _editorState.value.copy(
            isMarkdownPreview = !_editorState.value.isMarkdownPreview
        )
    }

    fun saveCurrentNote(isManual: Boolean = true, onSuccess: (() -> Unit)? = null) {
        val state = _editorState.value
        if (state.title.isBlank() && state.content.isBlank()) {
            if (isManual) showSnackbar("Note cannot be empty.")
            return
        }

        viewModelScope.launch {
            _syncState.value = SyncState.Syncing
            val noteId = noteRepository.saveNote(
                id = state.id,
                title = state.title.ifBlank { "Untitled" },
                content = state.content,
                tags = state.tags,
                folder = state.folder,
                colorHex = state.colorHex,
                isPinned = state.isPinned,
                isFavorite = state.isFavorite
            )
            val pCount = try {
                noteRepository.pendingSyncDao.getAllPending().size
            } catch (e: Exception) { 0 }

            if (pCount == 0) {
                _syncState.value = SyncState.Synced("Synced to Cloud")
                _editorState.value = _editorState.value.copy(
                    id = noteId,
                    lastSavedText = "Saved to Room & Synced to Cloud"
                )
            } else {
                _syncState.value = SyncState.Pending(pCount, "Saved Locally")
                _editorState.value = _editorState.value.copy(
                    id = noteId,
                    lastSavedText = "Auto-saved to Room Database"
                )
            }
            when (noteRepository.getNoteById(noteId)?.syncStatus) {
                NoteRepository.STATUS_ENCRYPTION_ERROR ->
                    showSnackbar("The vault is locked, so this note could not be encrypted. It stays on this device and syncs after you unlock the vault.")
                NoteRepository.STATUS_TOO_LARGE ->
                    showSnackbar("This note is too large to sync (limit about 900 KB). It is saved on this device only.")
                else -> if (isManual) showSnackbar("Note encrypted & saved.")
            }
            onSuccess?.invoke()
        }
    }

    fun deleteCurrentNote() {
        val noteId = _editorState.value.id ?: return
        viewModelScope.launch {
            noteRepository.softDeleteNote(noteId)
            showSnackbar("Note moved to Trash.")
            navigateBack()
        }
    }

    fun togglePin(noteId: String, isPinned: Boolean) {
        viewModelScope.launch {
            noteRepository.togglePin(noteId, isPinned)
        }
    }

    fun toggleFavorite(noteId: String, isFavorite: Boolean) {
        viewModelScope.launch {
            noteRepository.toggleFavorite(noteId, isFavorite)
        }
    }

    fun restoreNote(noteId: String) {
        viewModelScope.launch {
            noteRepository.restoreNote(noteId)
            showSnackbar("Note restored from Trash.")
        }
    }

    fun permanentlyDeleteNote(noteId: String) {
        viewModelScope.launch {
            noteRepository.permanentDeleteNote(noteId)
            showSnackbar("Note permanently deleted.")
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            _searchResults.value = noteRepository.searchLocalNotes(query)
        }
    }

    fun setFilter(filter: String) {
        _selectedFilter.value = filter
    }

    private val _shareBusy = MutableStateFlow(false)
    val shareBusy: StateFlow<Boolean> = _shareBusy.asStateFlow()

    private val _createdShareLink = MutableStateFlow<String?>(null)
    val createdShareLink: StateFlow<String?> = _createdShareLink.asStateFlow()

    fun loadSharesForNote(noteId: String) {
        viewModelScope.launch {
            val res = noteRepository.listPublicShares(noteId)
            res.onSuccess { list ->
                _activeShares.value = list
            }.onFailure { err ->
                showSnackbar(err.message ?: "Could not load share links.")
            }
        }
    }

    fun createPublicShare(expiresInHours: Int?, maxViews: Int?) {
        val noteId = _editorState.value.id
        if (noteId == null) {
            showSnackbar("Save the note first, then share it.")
            return
        }
        _shareBusy.value = true
        viewModelScope.launch {
            val res = noteRepository.createPublicShare(noteId, expiresInHours, maxViews)
            _shareBusy.value = false
            res.onSuccess { link ->
                _createdShareLink.value = link
                showSnackbar("Public link created.")
                loadSharesForNote(noteId)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Failed to create the share link.")
            }
        }
    }

    fun shareLinkFor(share: PublicShareDto): String? = noteRepository.shareLink(share)

    fun clearCreatedShareLink() {
        _createdShareLink.value = null
    }

    fun refreshShare(share: PublicShareDto) {
        val noteId = _editorState.value.id ?: return
        _shareBusy.value = true
        viewModelScope.launch {
            val res = noteRepository.refreshPublicShare(noteId, share)
            _shareBusy.value = false
            res.onSuccess {
                showSnackbar("Shared copy updated.")
                loadSharesForNote(noteId)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Could not update the shared copy.")
            }
        }
    }

    fun revokeShare(shareId: String) {
        viewModelScope.launch {
            val res = noteRepository.revokePublicShare(shareId)
            res.onSuccess {
                _activeShares.value = _activeShares.value.filter { it.shareId != shareId }
                showSnackbar("Link revoked. It no longer opens.")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Could not revoke the link.")
            }
        }
    }

    fun triggerManualSync() {
        if (!sessionManager.isLoggedIn) {
            showSnackbar("Authentication required to synchronize notes.")
            return
        }
        if (_vaultGate.value != null) return   // nothing can be encrypted or opened until the vault is ready
        viewModelScope.launch {
            _syncState.value = SyncState.Syncing
            val res = noteRepository.syncNow()
            val remainingPending = try {
                noteRepository.pendingSyncDao.getAllPending().size
            } catch (e: Exception) { 0 }

            res.onSuccess { report ->
                if (remainingPending == 0) {
                    _syncState.value = SyncState.Synced("Synced to Cloud")
                    val notable = report.contains("cannot be opened") || report.contains("conflict") || report.contains("could not be uploaded")
                    showSnackbar(if (notable) report else "Cloud sync completed successfully.")
                } else {
                    _syncState.value = SyncState.Pending(remainingPending, "Saved Locally")
                    showSnackbar("$remainingPending note(s) pending sync to cloud.")
                }
            }.onFailure { err ->
                val count = if (remainingPending > 0) remainingPending else 1
                _syncState.value = SyncState.Pending(count, "Saved Locally")
                val blocked = (err as? ApiErrorDetail)?.let { it.statusCode == 401 || it.code != null } == true
                if (!blocked) showSnackbar("Sync failed: ${err.message ?: "network error"}. Notes are saved on this device.")
            }
        }
    }

    fun loadDevices() {
        viewModelScope.launch {
            val res = authRepository.listDevices()
            res.onSuccess { list ->
                _devicesList.value = list
            }
        }
    }

    fun revokeDevice(deviceId: String) {
        viewModelScope.launch {
            authRepository.revokeDevice(deviceId)
            _devicesList.value = _devicesList.value.filter { it.deviceId != deviceId }
            showSnackbar("Device access revoked.")
        }
    }

    fun updateThemeMode(mode: String) {
        sessionManager.themeMode = mode
        _themeMode.value = mode
    }

    fun toggleAutoSync(enabled: Boolean) {
        sessionManager.isAutoSyncEnabled = enabled
        _autoSync.value = enabled
    }

    fun getDevicePublicKeyFingerprint(): String {
        return keystoreHelper.getDevicePublicKeyFingerprint()
    }

    fun getDeviceId(): String {
        return keystoreHelper.deviceId
    }

    fun setVaultPin(pin: String, enableBiometrics: Boolean) {
        vaultLockManager.savePin(pin)
        vaultLockManager.isBiometricEnabled = enableBiometrics
        showSnackbar("Vault Lock & 4-Digit PIN Enabled!")
        navigateTo(AppScreen.SETTINGS, clearStack = true)
    }

    fun disableVaultPinLock() {
        vaultLockManager.disableVaultLock()
        showSnackbar("Vault Lock disabled.")
    }

    fun verifyVaultPin(pin: String): Boolean {
        return vaultLockManager.verifyPin(pin)
    }

    fun onVaultUnlocked() {
        showSnackbar("Vault Unlocked!")
        navigateTo(if (sessionManager.isLoggedIn) AppScreen.HOME else AppScreen.SPLASH, clearStack = true)
    }

    // ------------------------------------------------------------------
    // Sign-in follow-up, access events, passwords, notifications, push
    // ------------------------------------------------------------------

    private fun onSignedIn(user: UserProfileDto, message: String) {
        viewModelScope.launch {
            // Notes on this device belong to one account only; never mix them with another account.
            val owner = sessionManager.dataOwnerId
            if (owner != null && owner != user.id) noteRepository.wipeLocalData()
            sessionManager.dataOwnerId = user.id

            _accessBlock.value = null
            _forcePasswordChange.value = user.mustChangePassword
            showSnackbar(message)
            loadUserProfile()
            registerPush()
            loadNotifications()
            if (user.mustChangePassword) {
                navigateTo(AppScreen.FORCE_PASSWORD_CHANGE, clearStack = true)
            } else {
                startVaultFlow()
            }
        }
    }

    private fun blockStateFor(event: AccessEvent.Blocked): AccessBlockState {
        val title = when (event.code) {
            "ACCOUNT_LOCKED" -> "Account locked"
            "ACCOUNT_SUSPENDED" -> "Account suspended"
            "ACCOUNT_BANNED" -> "Account banned"
            "ACCOUNT_DELETED" -> "Account deleted"
            else -> "Account unavailable"
        }
        return AccessBlockState(event.code, title, event.message ?: title, event.userMessage)
    }

    private fun handleAccessEvent(event: AccessEvent) {
        when (event) {
            is AccessEvent.Blocked -> {
                autoSaveJob?.cancel()
                _accessBlock.value = blockStateFor(event)
                screenStack.clear()
                _currentScreen.value = AppScreen.ACCOUNT_BLOCKED
            }
            AccessEvent.PasswordChangeRequired -> {
                _forcePasswordChange.value = true
                if (_currentScreen.value != AppScreen.FORCE_PASSWORD_CHANGE) {
                    screenStack.clear()
                    _currentScreen.value = AppScreen.FORCE_PASSWORD_CHANGE
                }
            }
            AccessEvent.EmailNotVerified -> {
                showSnackbar("Please verify your email address first.")
                navigateTo(AppScreen.VERIFY_EMAIL, clearStack = true)
            }
            AccessEvent.SessionExpired -> {
                if (_currentScreen.value != AppScreen.LOGIN && _currentScreen.value != AppScreen.SPLASH) {
                    showSnackbar("Your session ended. Please sign in again.")
                    screenStack.clear()
                    _currentScreen.value = AppScreen.LOGIN
                }
            }
        }
    }

    /** Asks the server for the real account state (also used after a push says the status changed). */
    fun checkAccountStatus(userInitiated: Boolean = false) {
        if (!sessionManager.isLoggedIn) return
        viewModelScope.launch {
            apiService.getAccountStatus().onSuccess { st ->
                when {
                    st.mustChangePassword && st.status == "active" -> handleAccessEvent(AccessEvent.PasswordChangeRequired)
                    st.status == "active" -> {
                        if (_accessBlock.value != null) {
                            _accessBlock.value = null
                            showSnackbar("Your account is active again.")
                            navigateTo(AppScreen.HOME, clearStack = true)
                            triggerManualSync()
                        } else if (userInitiated) {
                            showSnackbar("Your account is active.")
                        }
                    }
                    else -> handleAccessEvent(
                        AccessEvent.Blocked(st.code, st.message, st.userMessage)
                    )
                }
            }
        }
    }

    /** "Check again" on the blocked screen. */
    fun recheckBlockedAccount() {
        if (sessionManager.isLoggedIn) {
            checkAccountStatus(userInitiated = true)
        } else {
            // The block was reported at sign-in (no session): try signing in again.
            _accessBlock.value = null
            navigateTo(AppScreen.LOGIN, clearStack = true)
        }
    }

    fun submitPasswordChange(current: String, new: String, confirm: String) {
        when {
            current.isBlank() -> { showSnackbar("Enter your current password."); return }
            new.length < 12 -> { showSnackbar("New password must be at least 12 characters long."); return }
            new != confirm -> { showSnackbar("The new passwords do not match."); return }
            new == current -> { showSnackbar("The new password must be different."); return }
        }
        _passwordBusy.value = true
        viewModelScope.launch {
            val res = apiService.changePassword(current, new)
            _passwordBusy.value = false
            res.onSuccess {
                val savedEmail = credentialStore.savedEmail()
                if (savedEmail != null && savedEmail.equals(sessionManager.userEmail, ignoreCase = true)) {
                    credentialStore.save(savedEmail, new)
                    _authPasswordInput.value = new
                }
                val wasForced = _forcePasswordChange.value
                _forcePasswordChange.value = false
                showSnackbar("Password changed. Other devices were signed out.")
                if (wasForced) {
                    startVaultFlow()
                } else {
                    navigateBack()
                }
            }.onFailure { err ->
                showSnackbar(err.message ?: "Password change failed.")
            }
        }
    }

    fun requestPasswordReset(email: String) {
        if (email.isBlank() || !email.contains("@")) {
            showSnackbar("Please enter a valid email address.")
            return
        }
        _passwordBusy.value = true
        viewModelScope.launch {
            val res = apiService.forgotPassword(email)
            _passwordBusy.value = false
            res.onSuccess {
                _resetCodeSent.value = true
                showSnackbar("If an account exists for this email, a 25-digit reset code was sent.")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Could not request a reset code.")
            }
        }
    }

    fun submitPasswordReset(email: String, code: String, newPassword: String, confirm: String) {
        when {
            code.trim().length != 25 -> { showSnackbar("The reset code must be exactly 25 digits."); return }
            newPassword.length < 12 -> { showSnackbar("New password must be at least 12 characters long."); return }
            newPassword != confirm -> { showSnackbar("The new passwords do not match."); return }
        }
        _passwordBusy.value = true
        viewModelScope.launch {
            val res = apiService.resetPassword(email, code, newPassword)
            _passwordBusy.value = false
            res.onSuccess {
                _resetCodeSent.value = false
                showSnackbar("Password updated. Sign in with your new password.")
                navigateTo(AppScreen.LOGIN, clearStack = true)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Password reset failed.")
            }
        }
    }

    fun leaveForgotPassword() {
        _resetCodeSent.value = false
        navigateBack()
    }

    fun signOutEverywhere() {
        viewModelScope.launch {
            val res = apiService.logoutAll()
            res.onSuccess {
                performLogout("Signed out of all devices.")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Could not sign out of all devices.")
            }
        }
    }

    fun confirmLogoutDiscardingChanges() {
        _logoutWarning.value = null
        viewModelScope.launch { performLogout() }
    }

    fun dismissLogoutWarning() {
        _logoutWarning.value = null
    }

    private suspend fun performLogout(message: String = "Logged out successfully.") {
        PushRegistrar.unregister(getApplication())
        // Notes and the unsynced queue belong to the signed-in account and must not stay behind.
        noteRepository.wipeLocalData()
        authRepository.logout()
        _accessBlock.value = null
        _forcePasswordChange.value = false
        _vaultGate.value = null
        _recoveryKey.value = null
        val remembered = credentialStore.load()
        _authEmailInput.value = remembered?.first ?: ""
        _authPasswordInput.value = remembered?.second ?: ""
        _userProfile.value = null
        _notifications.value = emptyList()
        _unreadNotifications.value = 0
        showSnackbar(message)
        navigateTo(AppScreen.LOGIN, clearStack = true)
    }

    /** Used by the blocked screen: signing out must always work, even with unsynced changes. */
    fun signOutFromBlockedScreen() {
        viewModelScope.launch { performLogout() }
    }

    fun loadNotifications() {
        if (!sessionManager.isLoggedIn) return
        viewModelScope.launch {
            apiService.listNotifications().onSuccess { list ->
                _notifications.value = list.items
                _unreadNotifications.value = list.unreadCount
            }
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch {
            apiService.markNotificationsRead().onSuccess {
                _unreadNotifications.value = 0
                _notifications.value = _notifications.value.map { it.copy(read = true) }
            }
        }
    }

    private fun registerPush() {
        if (!sessionManager.isLoggedIn) return
        PushRegistrar.register(getApplication()) { token ->
            apiService.registerPushToken(
                keystoreHelper.deviceId, token, "Android Device (${android.os.Build.MODEL})"
            )
        }
    }

    // ------------------------------------------------------------------
    // Vault: master key shared by all devices of the account
    // ------------------------------------------------------------------

    private fun setVaultGate(gate: VaultGate) {
        _vaultGate.value = gate
        screenStack.clear()
        _currentScreen.value = if (gate == VaultGate.NEEDS_SETUP) AppScreen.VAULT_SETUP else AppScreen.VAULT_UNLOCK
    }

    private fun completeSignIn() {
        _vaultGate.value = null
        triggerManualSync()
        navigateTo(AppScreen.HOME, clearStack = true)
    }

    /** Decides after sign-in (or at start) whether the vault must be created, unlocked, or is ready. */
    fun startVaultFlow() {
        viewModelScope.launch {
            if (keystoreHelper.vault.hasMasterKey()) {
                completeSignIn()
                return@launch
            }
            val res = apiService.getKeyBundle()
            res.onSuccess { bundle ->
                setVaultGate(if (bundle == null) VaultGate.NEEDS_SETUP else VaultGate.NEEDS_UNLOCK)
            }.onFailure { err ->
                // Offline: let the user read their notes; saving stays blocked until the vault is available.
                val blocked = (err as? ApiErrorDetail)?.let { it.statusCode == 401 || it.code != null } == true
                if (!blocked) {
                    showSnackbar("Could not check your vault (${err.message ?: "network error"}). Notes can be read, but not saved, until it is unlocked.")
                    _vaultGate.value = null
                    navigateTo(AppScreen.HOME, clearStack = true)
                }
            }
        }
    }

    private fun passphraseProblem(passphrase: String, confirm: String): String? = when {
        passphrase.length < VaultCrypto.MIN_PASSPHRASE_LENGTH ->
            "The vault passphrase must be at least ${VaultCrypto.MIN_PASSPHRASE_LENGTH} characters long."
        passphrase != confirm -> "The passphrases do not match."
        else -> null
    }

    fun createVault(passphrase: String, confirm: String) {
        passphraseProblem(passphrase, confirm)?.let { showSnackbar(it); return }
        _vaultBusy.value = true
        viewModelScope.launch {
            try {
                val master = VaultCrypto.newMasterKey()
                val bundle = withContext(Dispatchers.Default) { VaultCrypto.wrap(master, passphrase.toCharArray(), 1) }
                val res = apiService.putKeyBundle(bundle)
                res.onSuccess {
                    keystoreHelper.vault.set(master)
                    _recoveryKey.value = VaultCrypto.toRecoveryKey(master)
                }.onFailure { err ->
                    if ((err as? ApiErrorDetail)?.statusCode == 409) {
                        showSnackbar("A vault already exists for this account. Enter its passphrase instead.")
                        setVaultGate(VaultGate.NEEDS_UNLOCK)
                    } else {
                        showSnackbar(err.message ?: "Could not create the vault.")
                    }
                }
            } finally {
                _vaultBusy.value = false
            }
        }
    }

    /** Called once the user confirmed that the recovery key is stored safely. */
    fun finishVaultSetup() {
        viewModelScope.launch {
            _recoveryKey.value = null
            val migrated = noteRepository.reencryptAllWithMasterKey()
            if (migrated > 0) showSnackbar("$migrated existing note(s) were re-encrypted with your vault key.")
            completeSignIn()
        }
    }

    private fun vaultLockMessage(): String? {
        val remaining = vaultLockedUntil - SystemClock.elapsedRealtime()
        return if (remaining > 0) "Too many wrong attempts. Try again in ${(remaining + 999) / 1000}s." else null
    }

    fun unlockVault(passphrase: String) {
        if (passphrase.isBlank()) {
            showSnackbar("Enter your vault passphrase.")
            return
        }
        vaultLockMessage()?.let { showSnackbar(it); return }
        _vaultBusy.value = true
        viewModelScope.launch {
            try {
                val bundle = apiService.getKeyBundle().getOrElse { err ->
                    showSnackbar(err.message ?: "Could not reach the server.")
                    return@launch
                }
                if (bundle == null) {
                    setVaultGate(VaultGate.NEEDS_SETUP)
                    return@launch
                }
                val master = try {
                    withContext(Dispatchers.Default) { VaultCrypto.unwrap(bundle, passphrase.toCharArray()) }
                } catch (_: WrongPassphraseException) {
                    vaultFailures++
                    if (vaultFailures >= 5) {
                        vaultLockedUntil = SystemClock.elapsedRealtime() + 30_000L
                        vaultFailures = 0
                    }
                    showSnackbar("Wrong vault passphrase.")
                    return@launch
                }
                vaultFailures = 0
                keystoreHelper.vault.set(master)
                val migrated = noteRepository.reencryptAllWithMasterKey()
                showSnackbar(if (migrated > 0) "Vault unlocked. $migrated local note(s) were re-encrypted." else "Vault unlocked.")
                completeSignIn()
            } catch (e: Exception) {
                showSnackbar(e.message ?: "Could not unlock the vault.")
            } finally {
                _vaultBusy.value = false
            }
        }
    }

    /** Forgot the passphrase: the recovery key restores access and sets a new passphrase (verified against a stored note first). */
    fun unlockWithRecoveryKey(recoveryKeyText: String, newPassphrase: String, confirm: String) {
        passphraseProblem(newPassphrase, confirm)?.let { showSnackbar(it); return }
        val candidate = VaultCrypto.fromRecoveryKey(recoveryKeyText)
        if (candidate == null) {
            showSnackbar("That is not a valid recovery key.")
            return
        }
        _vaultBusy.value = true
        viewModelScope.launch {
            try {
                when (noteRepository.verifyMasterKeyAgainstServer(candidate)) {
                    false -> {
                        showSnackbar("This recovery key does not match your encrypted notes.")
                        return@launch
                    }
                    null -> {
                        showSnackbar("The key cannot be verified right now (no synced encrypted notes or no connection). Use your passphrase, or try again online.")
                        return@launch
                    }
                    true -> Unit
                }
                val current = apiService.getKeyBundle().getOrElse { err ->
                    showSnackbar(err.message ?: "Could not reach the server.")
                    return@launch
                }
                val next = withContext(Dispatchers.Default) {
                    VaultCrypto.wrap(candidate, newPassphrase.toCharArray(), (current?.version ?: 0) + 1)
                }
                val put = apiService.putKeyBundle(next)
                if (put.isFailure) {
                    showSnackbar(put.exceptionOrNull()?.message ?: "Could not save the new passphrase.")
                    return@launch
                }
                keystoreHelper.vault.set(candidate)
                val migrated = noteRepository.reencryptAllWithMasterKey()
                showSnackbar(if (migrated > 0) "Passphrase reset. $migrated local note(s) were re-encrypted." else "Passphrase reset. Vault unlocked.")
                completeSignIn()
            } finally {
                _vaultBusy.value = false
            }
        }
    }

    /** Settings: change the vault passphrase while this device is unlocked. */
    fun changeVaultPassphrase(newPassphrase: String, confirm: String) {
        passphraseProblem(newPassphrase, confirm)?.let { showSnackbar(it); return }
        val master = keystoreHelper.vault.masterKey()
        if (master == null) {
            showSnackbar("Unlock the vault first.")
            return
        }
        _vaultBusy.value = true
        viewModelScope.launch {
            try {
                val current = apiService.getKeyBundle().getOrElse { err ->
                    showSnackbar(err.message ?: "Could not reach the server.")
                    return@launch
                }
                val next = withContext(Dispatchers.Default) {
                    VaultCrypto.wrap(master, newPassphrase.toCharArray(), (current?.version ?: 0) + 1)
                }
                apiService.putKeyBundle(next)
                    .onSuccess {
                        showSnackbar("Vault passphrase changed. Use the new passphrase on your other devices.")
                        navigateBack()
                    }
                    .onFailure { err ->
                        showSnackbar(
                            if ((err as? ApiErrorDetail)?.statusCode == 409) "Your vault was changed on another device. Try again."
                            else err.message ?: "Could not change the passphrase."
                        )
                    }
            } finally {
                _vaultBusy.value = false
            }
        }
    }
}

/** Which vault step blocks the app until it is done. */
enum class VaultGate { NEEDS_SETUP, NEEDS_UNLOCK }

/** What the full-screen locked / suspended / banned screen shows. */
data class AccessBlockState(
    val code: String,
    val title: String,
    val message: String,
    val userMessage: String?
)
