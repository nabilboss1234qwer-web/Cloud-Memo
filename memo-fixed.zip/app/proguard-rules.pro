# CloudMemo release (R8) rules

-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile

# Optional libraries referenced by dependencies (Tink, OkHttp, ...) must not fail the release build.
-ignorewarnings

# Encrypted storage (security-crypto uses Tink + protobuf-lite through reflection)
-keep class androidx.security.crypto.** { *; }
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.crypto.tink.**

# Networking
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Room entities / DAOs are kept by Room's own consumer rules. App classes referenced from the manifest are kept by AAPT.
-keep class com.example.push.CloudMemoMessagingService { *; }
-keep class com.example.CloudMemoApp { *; }

# Firebase Messaging ships its own consumer rules.
