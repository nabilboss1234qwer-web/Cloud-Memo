# CloudMemo

Secure cloud notepad for Android. Notes are encrypted on the device with a master key that only the user can unlock
(vault passphrase), synced through the CloudMemo backend, and can be shared as end-to-end encrypted public links.

## Build

Requirements: Android Studio, JDK 17, Android SDK platform 35.

```
./gradlew assembleDebug
./gradlew testDebugUnitTest
```

## Configuration

- Backend URL: set in the app settings (default is the production CloudMemo server).
- Push notifications: add `google-services.json` as described in `docs/FCM_SETUP.md`.
- Release signing and R8: see `docs/RELEASE_SIGNING.md`.

## Main parts

- `data/network`: REST client, session storage (encrypted), server error handling.
- `data/crypto`: master-key vault, note encryption, public-share encryption.
- `data/repository`: offline-first notes with a sync queue (push, pull, conflict copies).
- `ui`: Jetpack Compose screens (notes, trash, sharing, devices, vault, account, notifications).
- `push`: Firebase Cloud Messaging service and registration.

## Changelog

- 10.0.0: multi-device vault key, account lock/ban screens, password flows, public share links, push notifications,
  stricter encryption and PIN lockout, release signing and R8.
