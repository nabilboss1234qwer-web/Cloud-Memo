package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BottomNavTab
import com.example.ui.components.CloudMemoBottomNavBar
import com.example.push.NotificationChannels
import com.example.push.PushRegistrar
import com.example.ui.screens.AccountBlockedScreen
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.ForgotPasswordScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PasswordChangeScreen
import com.example.ui.screens.VaultChangePassphraseScreen
import com.example.ui.screens.VaultSetupScreen
import com.example.ui.screens.VaultUnlockScreen
import com.example.ui.screens.DevicesScreen
import com.example.ui.screens.FoldersTagsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NavigationDrawerContent
import com.example.ui.screens.NoteEditorScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PinLockScreen
import com.example.ui.screens.PinSetupScreen
import com.example.ui.screens.PrivacyPolicyScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShareNoteScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SyncStatusScreen
import com.example.ui.screens.TermsOfServiceScreen
import com.example.ui.screens.TrashScreen
import com.example.ui.screens.VerifyEmailScreen
import com.example.ui.theme.CloudMemoTheme
import com.example.ui.theme.ObsidianVoid
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationChannels.create(this)
        // A tapped push notification carries its type in the intent extras (FCM data payload).
        val startPushType = intent?.getStringExtra("push_type") ?: intent?.getStringExtra("type")
        setContent {
            CloudMemoTheme {
                val viewModel: MainViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val syncState by viewModel.syncState.collectAsStateWithLifecycle()
                val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
                val accessBlock by viewModel.accessBlock.collectAsStateWithLifecycle()
                val passwordBusy by viewModel.passwordBusy.collectAsStateWithLifecycle()
                val resetCodeSent by viewModel.resetCodeSent.collectAsStateWithLifecycle()
                val notifications by viewModel.notifications.collectAsStateWithLifecycle()
                val unreadNotifications by viewModel.unreadNotifications.collectAsStateWithLifecycle()
                val logoutWarning by viewModel.logoutWarning.collectAsStateWithLifecycle()
                val activeShares by viewModel.activeShares.collectAsStateWithLifecycle()
                val shareBusy by viewModel.shareBusy.collectAsStateWithLifecycle()
                val createdShareLink by viewModel.createdShareLink.collectAsStateWithLifecycle()
                val editorState by viewModel.editorState.collectAsStateWithLifecycle()
                val secureScreen by viewModel.secureScreen.collectAsStateWithLifecycle()
                val vaultBusy by viewModel.vaultBusy.collectAsStateWithLifecycle()
                val recoveryKey by viewModel.recoveryKey.collectAsStateWithLifecycle()

                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(snackbarMessage) {
                    snackbarMessage?.let {
                        snackbarHostState.showSnackbar(it)
                        viewModel.clearSnackbar()
                    }
                }

                LaunchedEffect(secureScreen) {
                    if (secureScreen) {
                        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                }

                LaunchedEffect(Unit) {
                    when (startPushType) {
                        "admin_notification" -> viewModel.openNotificationsFromPush()
                        "account_status" -> viewModel.checkAccountStatus(userInitiated = true)
                    }
                }

                // Android 13+: ask for the notification permission once, after the user reached the home screen.
                val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
                var askedNotificationPermission by rememberSaveable { mutableStateOf(false) }
                LaunchedEffect(currentScreen) {
                    if (currentScreen == AppScreen.HOME && !askedNotificationPermission &&
                        Build.VERSION.SDK_INT >= 33 && PushRegistrar.isAvailable(this@MainActivity) &&
                        ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        askedNotificationPermission = true
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                BackHandler(
                    enabled = currentScreen != AppScreen.HOME && currentScreen != AppScreen.SPLASH &&
                        currentScreen != AppScreen.PIN_LOCK && currentScreen != AppScreen.ACCOUNT_BLOCKED &&
                        currentScreen != AppScreen.FORCE_PASSWORD_CHANGE && currentScreen != AppScreen.VAULT_SETUP &&
                        currentScreen != AppScreen.VAULT_UNLOCK
                ) {
                    viewModel.navigateBack()
                }

                val showBottomNav = currentScreen in listOf(
                    AppScreen.HOME,
                    AppScreen.SEARCH,
                    AppScreen.FOLDERS_TAGS,
                    AppScreen.TRASH,
                    AppScreen.SETTINGS
                )

                val currentNavTab = when (currentScreen) {
                    AppScreen.HOME -> BottomNavTab.HOME
                    AppScreen.SEARCH -> BottomNavTab.SEARCH
                    AppScreen.FOLDERS_TAGS -> BottomNavTab.FOLDERS
                    AppScreen.TRASH -> BottomNavTab.TRASH
                    AppScreen.SETTINGS -> BottomNavTab.SETTINGS
                    else -> BottomNavTab.HOME
                }

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    gesturesEnabled = currentScreen == AppScreen.HOME,
                    drawerContent = {
                        NavigationDrawerContent(
                            currentScreen = currentScreen,
                            onNavigate = { screen ->
                                scope.launch { drawerState.close() }
                                viewModel.navigateTo(screen)
                            },
                            userEmail = viewModel.userEmail,
                            onClose = { scope.launch { drawerState.close() } },
                            unreadNotifications = unreadNotifications
                        )
                    }
                ) {
                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        bottomBar = {
                            if (showBottomNav) {
                                CloudMemoBottomNavBar(
                                    currentTab = currentNavTab,
                                    onTabSelected = { tab ->
                                        when (tab) {
                                            BottomNavTab.HOME -> viewModel.navigateTo(AppScreen.HOME)
                                            BottomNavTab.SEARCH -> viewModel.navigateTo(AppScreen.SEARCH)
                                            BottomNavTab.FOLDERS -> viewModel.navigateTo(AppScreen.FOLDERS_TAGS)
                                            BottomNavTab.TRASH -> viewModel.navigateTo(AppScreen.TRASH)
                                            BottomNavTab.SETTINGS -> viewModel.navigateTo(AppScreen.SETTINGS)
                                        }
                                    }
                                )
                            }
                        },
                        containerColor = ObsidianVoid
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(ObsidianVoid)
                        ) {
                            Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                                when (screen) {
                                    AppScreen.SPLASH -> SplashScreen(
                                        onGetStarted = { viewModel.navigateTo(AppScreen.LOGIN) }
                                    )
                                    AppScreen.TERMS_OF_SERVICE -> TermsOfServiceScreen(
                                        isReviewMode = viewModel.isTosAccepted,
                                        onAccept = { viewModel.acceptTermsOfService() },
                                        onDecline = {
                                            if (viewModel.isTosAccepted) {
                                                viewModel.navigateBack()
                                            }
                                        },
                                        onOpenPrivacyPolicy = { viewModel.navigateTo(AppScreen.PRIVACY_POLICY) },
                                        onNavigateBack = if (viewModel.isTosAccepted) { { viewModel.navigateBack() } } else null
                                    )
                                    AppScreen.PRIVACY_POLICY -> PrivacyPolicyScreen(
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.ONBOARDING -> OnboardingScreen(
                                        onFinish = { viewModel.navigateTo(AppScreen.HOME, clearStack = true) }
                                    )
                                    AppScreen.LOGIN -> LoginScreen(
                                        emailInput = viewModel.authEmailInput.collectAsStateWithLifecycle().value,
                                        onEmailChange = { viewModel.setAuthEmail(it) },
                                        passwordInput = viewModel.authPasswordInput.collectAsStateWithLifecycle().value,
                                        onPasswordChange = { viewModel.setAuthPassword(it) },
                                        displayNameInput = viewModel.authDisplayNameInput.collectAsStateWithLifecycle().value,
                                        onDisplayNameChange = { viewModel.setAuthDisplayName(it) },
                                        isRegisterMode = viewModel.isRegisterMode.collectAsStateWithLifecycle().value,
                                        onToggleRegisterMode = { viewModel.toggleRegisterMode(it) },
                                        isLoading = viewModel.authLoading.collectAsStateWithLifecycle().value,
                                        onSubmit = { viewModel.submitAuth() },
                                        onOpenTermsOfService = { viewModel.navigateTo(AppScreen.TERMS_OF_SERVICE) },
                                        onOpenPrivacyPolicy = { viewModel.navigateTo(AppScreen.PRIVACY_POLICY) },
                                        onForgotPassword = { viewModel.navigateTo(AppScreen.FORGOT_PASSWORD) }
                                    )
                                    AppScreen.VERIFY_EMAIL, AppScreen.VERIFY_MAGIC_LINK -> VerifyEmailScreen(
                                        email = viewModel.authEmailInput.collectAsStateWithLifecycle().value,
                                        codeInput = viewModel.verificationCodeInput.collectAsStateWithLifecycle().value,
                                        onCodeChange = { viewModel.setVerificationCode(it) },
                                        isLoading = viewModel.authLoading.collectAsStateWithLifecycle().value,
                                        isResending = viewModel.authResending.collectAsStateWithLifecycle().value,
                                        onVerify = { viewModel.verifyEmailCode() },
                                        onResendCode = { viewModel.resendVerificationCode() },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.HOME -> HomeScreen(
                                        notes = viewModel.notes.collectAsStateWithLifecycle().value,
                                        selectedFilter = viewModel.selectedFilter.collectAsStateWithLifecycle().value,
                                        onFilterSelect = { viewModel.setFilter(it) },
                                        noteDisplayLayout = viewModel.noteDisplayLayout.collectAsStateWithLifecycle().value,
                                        onSelectLayout = { viewModel.setNoteDisplayLayout(it) },
                                        onNoteClick = { viewModel.openNoteForEdit(it) },
                                        onTogglePin = { id, pinned -> viewModel.togglePin(id, pinned) },
                                        onToggleFavorite = { id, fav -> viewModel.toggleFavorite(id, fav) },
                                        onNewNoteClick = { viewModel.startNewNote() },
                                        onSearchClick = { viewModel.navigateTo(AppScreen.SEARCH) },
                                        onOpenDrawer = { scope.launch { drawerState.open() } },
                                        syncState = syncState,
                                        onTriggerSync = { viewModel.triggerManualSync() }
                                    )
                                    AppScreen.NOTE_EDITOR -> NoteEditorScreen(
                                        state = viewModel.editorState.collectAsStateWithLifecycle().value,
                                        syncState = syncState,
                                        onTitleChange = { viewModel.updateEditorTitle(it) },
                                        onContentChange = { viewModel.updateEditorContent(it) },
                                        onTagsChange = { viewModel.updateEditorTags(it) },
                                        onFolderChange = { viewModel.updateEditorFolder(it) },
                                        onColorChange = { viewModel.updateEditorColor(it) },
                                        onTogglePreview = { viewModel.toggleMarkdownPreview() },
                                        onSave = { viewModel.saveCurrentNote(true) },
                                        onDelete = { viewModel.deleteCurrentNote() },
                                        onShare = { viewModel.navigateTo(AppScreen.SHARE_NOTE) },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.SEARCH -> SearchScreen(
                                        query = viewModel.searchQuery.collectAsStateWithLifecycle().value,
                                        onQueryChange = { viewModel.onSearchQueryChanged(it) },
                                        results = viewModel.searchResults.collectAsStateWithLifecycle().value,
                                        onNoteClick = { viewModel.openNoteForEdit(it) },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.FOLDERS_TAGS -> FoldersTagsScreen(
                                        notes = viewModel.notes.collectAsStateWithLifecycle().value,
                                        onSelectFilter = { filter ->
                                            viewModel.setFilter(filter)
                                            viewModel.navigateTo(AppScreen.HOME)
                                        },
                                        syncState = syncState,
                                        onTriggerSync = { viewModel.triggerManualSync() },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.TRASH -> TrashScreen(
                                        trashedNotes = viewModel.trashedNotes.collectAsStateWithLifecycle().value,
                                        onRestoreNote = { viewModel.restoreNote(it) },
                                        onPermanentDeleteNote = { viewModel.permanentlyDeleteNote(it) },
                                        syncState = syncState,
                                        onTriggerSync = { viewModel.triggerManualSync() },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.SYNC_STATUS -> SyncStatusScreen(
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.DEVICES -> DevicesScreen(
                                        devices = viewModel.devicesList.collectAsStateWithLifecycle().value,
                                        onRevokeDevice = { viewModel.revokeDevice(it) },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.SETTINGS -> SettingsScreen(
                                        userEmail = viewModel.userEmail,
                                        isLoggedIn = viewModel.isLoggedIn,
                                        autoSyncEnabled = viewModel.autoSync.collectAsStateWithLifecycle().value,
                                        onToggleAutoSync = { viewModel.toggleAutoSync(it) },
                                        syncState = syncState,
                                        onTriggerSync = { viewModel.triggerManualSync() },
                                        onOpenDevices = {
                                            viewModel.loadDevices()
                                            viewModel.navigateTo(AppScreen.DEVICES)
                                        },
                                        onOpenAccount = { viewModel.navigateTo(AppScreen.ACCOUNT) },
                                        onLogout = { viewModel.logout() },
                                        deviceFingerprint = viewModel.getDevicePublicKeyFingerprint(),
                                        isVaultLockEnabled = viewModel.vaultLockManager.isVaultLockEnabled,
                                        onOpenPinSetup = { viewModel.navigateTo(AppScreen.PIN_SETUP) },
                                        onDisablePinLock = { viewModel.disableVaultPinLock() },
                                        onOpenTermsOfService = { viewModel.navigateTo(AppScreen.TERMS_OF_SERVICE) },
                                        onOpenPrivacyPolicy = { viewModel.navigateTo(AppScreen.PRIVACY_POLICY) },
                                        onNavigateBack = { viewModel.navigateBack() },
                                        onOpenNotifications = { viewModel.navigateTo(AppScreen.NOTIFICATIONS) },
                                        onOpenChangePassword = { viewModel.navigateTo(AppScreen.CHANGE_PASSWORD) },
                                        onOpenVaultPassphrase = { viewModel.navigateTo(AppScreen.VAULT_CHANGE) },
                                        secureScreenEnabled = secureScreen,
                                        onToggleSecureScreen = { viewModel.setSecureScreen(it) }
                                    )
                                    AppScreen.ACCOUNT -> AccountScreen(
                                        userEmail = viewModel.userEmail,
                                        displayName = viewModel.userDisplayName,
                                        userId = viewModel.userId,
                                        userRole = viewModel.userRole,
                                        onExportAccount = { viewModel.exportAccount() },
                                        onDeleteAccount = { pwd -> viewModel.deleteAccount(pwd) {} },
                                        onLogout = { viewModel.logout() },
                                        onNavigateBack = { viewModel.navigateBack() },
                                        onSignOutEverywhere = { viewModel.signOutEverywhere() }
                                    )
                                    AppScreen.SHARE_NOTE -> {
                                        LaunchedEffect(editorState.id) {
                                            editorState.id?.let { viewModel.loadSharesForNote(it) }
                                        }
                                        ShareNoteScreen(
                                            noteTitle = editorState.title,
                                            shares = activeShares,
                                            createdLink = createdShareLink,
                                            isBusy = shareBusy,
                                            linkFor = { viewModel.shareLinkFor(it) },
                                            onCreate = { hours, views -> viewModel.createPublicShare(hours, views) },
                                            onRefreshShare = { viewModel.refreshShare(it) },
                                            onRevokeShare = { viewModel.revokeShare(it) },
                                            onDismissCreated = { viewModel.clearCreatedShareLink() },
                                            onNavigateBack = { viewModel.navigateBack() }
                                        )
                                    }
                                    AppScreen.ACCOUNT_BLOCKED -> accessBlock?.let { block ->
                                        AccountBlockedScreen(
                                            state = block,
                                            onCheckAgain = { viewModel.recheckBlockedAccount() },
                                            onSignOut = { viewModel.signOutFromBlockedScreen() }
                                        )
                                    }
                                    AppScreen.FORCE_PASSWORD_CHANGE -> PasswordChangeScreen(
                                        isForced = true,
                                        isBusy = passwordBusy,
                                        onSubmit = { cur, new, conf -> viewModel.submitPasswordChange(cur, new, conf) },
                                        onNavigateBack = null,
                                        onSignOut = { viewModel.signOutFromBlockedScreen() }
                                    )
                                    AppScreen.CHANGE_PASSWORD -> PasswordChangeScreen(
                                        isForced = false,
                                        isBusy = passwordBusy,
                                        onSubmit = { cur, new, conf -> viewModel.submitPasswordChange(cur, new, conf) },
                                        onNavigateBack = { viewModel.navigateBack() },
                                        onSignOut = null
                                    )
                                    AppScreen.FORGOT_PASSWORD -> ForgotPasswordScreen(
                                        initialEmail = viewModel.authEmailInput.collectAsStateWithLifecycle().value,
                                        codeSent = resetCodeSent,
                                        isBusy = passwordBusy,
                                        onRequestCode = { viewModel.requestPasswordReset(it) },
                                        onSubmitReset = { email, code, pass, conf -> viewModel.submitPasswordReset(email, code, pass, conf) },
                                        onBack = { viewModel.leaveForgotPassword() }
                                    )
                                    AppScreen.VAULT_SETUP -> VaultSetupScreen(
                                        isBusy = vaultBusy,
                                        recoveryKey = recoveryKey,
                                        onCreate = { pass, conf -> viewModel.createVault(pass, conf) },
                                        onFinish = { viewModel.finishVaultSetup() },
                                        onSignOut = { viewModel.signOutFromBlockedScreen() }
                                    )
                                    AppScreen.VAULT_UNLOCK -> VaultUnlockScreen(
                                        isBusy = vaultBusy,
                                        onUnlock = { viewModel.unlockVault(it) },
                                        onRecover = { key, pass, conf -> viewModel.unlockWithRecoveryKey(key, pass, conf) },
                                        onSignOut = { viewModel.signOutFromBlockedScreen() }
                                    )
                                    AppScreen.VAULT_CHANGE -> VaultChangePassphraseScreen(
                                        isBusy = vaultBusy,
                                        onSubmit = { pass, conf -> viewModel.changeVaultPassphrase(pass, conf) },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.NOTIFICATIONS -> NotificationsScreen(
                                        items = notifications,
                                        unreadCount = unreadNotifications,
                                        onRefresh = { viewModel.loadNotifications() },
                                        onMarkAllRead = { viewModel.markNotificationsRead() },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.PIN_SETUP -> PinSetupScreen(
                                        isBiometricAvailable = viewModel.vaultLockManager.isBiometricAvailable(),
                                        onPinSetSuccess = { pin, enableBio ->
                                            viewModel.setVaultPin(pin, enableBio)
                                        },
                                        onNavigateBack = { viewModel.navigateBack() }
                                    )
                                    AppScreen.PIN_LOCK -> PinLockScreen(
                                        isBiometricAvailable = viewModel.vaultLockManager.isBiometricAvailable(),
                                        isBiometricEnabled = viewModel.vaultLockManager.isBiometricEnabled,
                                        onVerifyPin = { pin -> viewModel.verifyVaultPin(pin) },
                                        lockRemainingSeconds = { viewModel.vaultLockManager.lockRemainingSeconds() },
                                        onUnlockSuccess = { viewModel.onVaultUnlocked() },
                                        onTriggerBiometric = {
                                            viewModel.vaultLockManager.showBiometricPrompt(
                                                activity = this@MainActivity,
                                                onSuccess = { viewModel.onVaultUnlocked() },
                                                onError = { err -> viewModel.showSnackbar(err) }
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                logoutWarning?.let { count ->
                    AlertDialog(
                        onDismissRequest = { viewModel.dismissLogoutWarning() },
                        title = { Text("Unsynced changes") },
                        text = {
                            Text(
                                "$count change(s) have not reached the cloud yet. Signing out removes the notes from this device. " +
                                    "Stay signed in and sync first?"
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = { viewModel.confirmLogoutDiscardingChanges() }) { Text("Sign out anyway") }
                        },
                        dismissButton = {
                            TextButton(onClick = { viewModel.dismissLogoutWarning() }) { Text("Stay signed in") }
                        }
                    )
                }
            }
        }
    }
}
