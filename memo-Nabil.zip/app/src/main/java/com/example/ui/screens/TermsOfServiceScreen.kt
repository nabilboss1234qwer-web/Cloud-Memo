package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnimatedAestheticLogo
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSpecularReflection
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary

@Composable
fun TermsOfServiceScreen(
    isReviewMode: Boolean = false,
    acceptedVersion: String? = null,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onNavigateBack: (() -> Unit)? = null
) {
    val scrollState = rememberScrollState()
    var hasDeclined by remember { mutableStateOf(false) }

    // User must scroll near the end of the document to unlock "Accept & Continue"
    val hasReachedEnd by remember {
        derivedStateOf {
            if (isReviewMode) true
            else (scrollState.maxValue > 0 && scrollState.value >= (scrollState.maxValue - 80))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        if (hasDeclined) {
            // Declined Screen: Keep protected app features inaccessible and provide option to review terms
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                CrystalGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    accentColor = Color(0xFFEF4444)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Terms Required",
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "Terms of Service Required",
                            color = TextWhitePrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "You declined the Terms of Service. CloudMemo protected features (note creation, client-side encryption, and cloud synchronization) remain inaccessible until terms are accepted.",
                            color = TextMutedSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        CrystalGlassButton(
                            onClick = { hasDeclined = false },
                            modifier = Modifier.fillMaxWidth(),
                            accentColor = NeonCyan
                        ) {
                            Text(
                                text = "Review Terms of Service",
                                color = NeonCyan,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(ObsidianVoid, ObsidianSurface.copy(alpha = 0.95f))
                            )
                        )
                        .border(
                            1.dp,
                            Brush.horizontalGradient(
                                listOf(GlassSpecularReflection, GlassBorder, GlassSpecularReflection)
                            ),
                            RoundedCornerShape(0.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isReviewMode && onNavigateBack != null) {
                                IconButton(onClick = onNavigateBack) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowBack,
                                        contentDescription = "Back",
                                        tint = TextWhitePrimary
                                    )
                                }
                            } else {
                                AnimatedAestheticLogo(size = 32.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                            }
                            Column {
                                Text(
                                    text = "Terms of Service",
                                    color = TextWhitePrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Version: cloudmemo-tos-v1",
                                    color = NeonCyan,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        if (isReviewMode && acceptedVersion != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(EmeraldOnline.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "ACCEPTED",
                                    color = EmeraldOnline,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Scrollable Document Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(scrollState)
                        .padding(horizontal = 18.dp, vertical = 14.dp)
                ) {
                    // Document Header
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = NeonCyan
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Text(
                                text = "CloudMemo Terms of Service — Version 1",
                                color = TextWhitePrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Effective date: Release of V9 Application\nService: CloudMemo Android User App\nOperator: Official CloudMemo Service Operator",
                                color = TextMutedSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    TosSection(
                        number = "1",
                        title = "Acceptance of Terms",
                        content = "By selecting \"Accept & Continue\", you confirm that you have read and agree to these Terms of Service. You must accept the applicable terms before using the protected features of CloudMemo.\n\nIf you do not agree, select \"Decline\" and do not use the protected features."
                    )

                    TosSection(
                        number = "2",
                        title = "Account and Authentication",
                        content = "CloudMemo requires users to authenticate through its designated Backend before accessing account-based features.\n\nUsers are responsible for providing accurate account information and protecting their credentials and active sessions. Do not attempt to access another user's account or bypass authentication controls."
                    )

                    TosSection(
                        number = "3",
                        title = "Notes and Personal Data",
                        content = "CloudMemo provides functionality to create, edit, organize, synchronize, export, and delete notes where supported by the application and service.\n\nUsers remain responsible for the content they create and store. Do not use CloudMemo to store or distribute unlawful content or content that violates another person's rights."
                    )

                    TosSection(
                        number = "4",
                        title = "Encryption and Security",
                        content = "CloudMemo is designed to use client-side encryption for note contents.\n\nThe precise protection available depends on the implemented encryption, key management, recovery, and device-security mechanisms. Users should protect their recovery information and supported credentials.\n\nDo not claim that every piece of account metadata is encrypted end-to-end unless the implementation verifies that claim.\n\nLoss of encryption keys may make encrypted notes unrecoverable. CloudMemo must not promise recovery unless a supported recovery mechanism actually exists."
                    )

                    TosSection(
                        number = "5",
                        title = "Synchronization and Availability",
                        content = "CloudMemo synchronization depends on the network, application version, Backend availability, and successful completion of synchronization operations.\n\nUsers should not assume that an unsynchronized local change has been safely stored on the server. Important data should be verified as synchronized before uninstalling the app, clearing app data, or changing devices.\n\nCloudMemo does not guarantee uninterrupted or error-free service."
                    )

                    TosSection(
                        number = "6",
                        title = "Acceptable Use",
                        content = "Users must not:\n• Attempt unauthorized access to the service.\n• Abuse, disrupt, or overload the Backend.\n• Bypass security controls or authentication.\n• Use the service to violate applicable laws or another person's rights.\n• Attempt to interfere with other users' accounts or data."
                    )

                    TosSection(
                        number = "7",
                        title = "Account Restrictions",
                        content = "CloudMemo may restrict or suspend accounts where necessary to protect the service, investigate suspected abuse, or comply with applicable law.\n\nWhere reasonably possible, users should be informed of restrictions and available resolution procedures."
                    )

                    TosSection(
                        number = "8",
                        title = "Data Deletion and Export",
                        content = "Use the available in-app export and deletion features where supported.\n\nBefore permanently deleting an account or notes, review the confirmation shown in the app. Permanent deletion may be irreversible.\n\nThe app must not claim that data has been exported or deleted until the corresponding operation is confirmed by the actual implementation."
                    )

                    TosSection(
                        number = "9",
                        title = "Service Changes",
                        content = "CloudMemo features, limits, and service availability may change. Material changes to these Terms must be reflected in an updated ToS version where renewed acceptance is required."
                    )

                    TosSection(
                        number = "10",
                        title = "Disclaimer",
                        content = "To the extent permitted by applicable law, CloudMemo is provided without a guarantee of uninterrupted availability or absolute data recovery.\n\nNothing in these Terms removes rights that cannot legally be excluded under applicable law."
                    )

                    TosSection(
                        number = "11",
                        title = "Contact and Support",
                        content = "Use the official CloudMemo support contact published by the service operator for questions about these Terms, account access, or privacy.\n\nDo not invent a support email address or claim that an unverified contact is official."
                    )

                    TosSection(
                        number = "12",
                        title = "Agreement",
                        content = "By selecting \"Accept & Continue\", the user acknowledges that they have read and agree to the displayed CloudMemo Terms of Service.\n\nSelecting \"Decline\" prevents access to protected app functionality."
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Privacy Policy Link
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = ElectricViolet,
                        onClick = onOpenPrivacyPolicy
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PrivacyTip,
                                    contentDescription = null,
                                    tint = ElectricViolet,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Privacy Policy",
                                        color = TextWhitePrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Review how personal data and encrypted contents are handled",
                                        color = TextMutedSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Text(
                                text = "View →",
                                color = ElectricViolet,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (!hasReachedEnd && !isReviewMode) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF59E0B).copy(alpha = 0.12f))
                                .padding(10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "▼ Please scroll to the bottom of the document to accept",
                                color = Color(0xFFF59E0B),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Action Footer
                if (!isReviewMode) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ObsidianElevated)
                            .border(1.dp, GlassBorder, RoundedCornerShape(0.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Decline Button
                            CrystalGlassButton(
                                onClick = { hasDeclined = true },
                                modifier = Modifier.weight(1f),
                                accentColor = Color(0xFFEF4444)
                            ) {
                                Text(
                                    text = "Decline",
                                    color = Color(0xFFEF4444),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Accept & Continue Button (Disabled until scrolled to end)
                            CrystalGlassButton(
                                onClick = onAccept,
                                enabled = hasReachedEnd,
                                modifier = Modifier.weight(1.4f),
                                accentColor = if (hasReachedEnd) NeonCyan else Color.Gray
                            ) {
                                Text(
                                    text = "Accept & Continue",
                                    color = if (hasReachedEnd) NeonCyan else TextTertiary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TosSection(
    number: String,
    title: String,
    content: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = number,
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "$number. $title",
                color = TextWhitePrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = content,
            color = TextMutedSecondary,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(start = 32.dp)
        )
    }
}
