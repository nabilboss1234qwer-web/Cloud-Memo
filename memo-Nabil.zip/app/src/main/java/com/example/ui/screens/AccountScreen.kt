package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnimatedAestheticLogo
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary

@Composable
fun AccountScreen(
    userEmail: String?,
    displayName: String?,
    userId: String?,
    userRole: String?,
    onExportAccount: () -> Unit,
    onDeleteAccount: (String) -> Unit,
    onLogout: () -> Unit,
    onNavigateBack: () -> Unit,
    onSignOutEverywhere: () -> Unit = {}
) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    var deletePasswordInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(20.dp)
        ) {
            // Top App Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhitePrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Account Vault",
                    color = TextWhitePrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // User Info Card
            CrystalGlassCard(
                modifier = Modifier.fillMaxWidth(),
                accentColor = NeonCyan
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(ObsidianElevated)
                            .border(1.5.dp, NeonCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedAestheticLogo(size = 46.dp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = displayName?.ifBlank { null } ?: "CloudMemo User",
                        color = TextWhitePrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = userEmail ?: "Local Encrypted Account",
                        color = TextMutedSecondary,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(ObsidianElevated)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "ROLE", color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(text = userRole?.uppercase() ?: "USER", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column {
                            Text(text = "VAULT ID", color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(text = userId?.take(10) ?: "LOCAL-KEY", color = TextWhitePrimary, fontSize = 12.sp)
                        }
                        Column {
                            Text(text = "STATUS", color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(text = "ACTIVE", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Data Export Section
            Text(
                text = "DATA MANAGEMENT",
                color = TextTertiary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
            )

            CrystalGlassCard(
                modifier = Modifier.fillMaxWidth(),
                accentColor = ElectricViolet
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = ElectricViolet)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "Export Encrypted Vault Data", color = TextWhitePrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = "Download all your encrypted notes and device metadata (GET /v1/account/export)", color = TextMutedSecondary, fontSize = 11.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    CrystalGlassButton(
                        onClick = onExportAccount,
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = ElectricViolet
                    ) {
                        Text(text = "Export Account Backup", color = ElectricViolet, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Danger Zone
            Text(
                text = "DANGER ZONE",
                color = Color(0xFFEF4444),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
            )

            CrystalGlassCard(
                modifier = Modifier.fillMaxWidth(),
                accentColor = Color(0xFFEF4444)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFEF4444))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "Delete Account & Cloud Vault", color = Color(0xFFEF4444), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Permanently deletes all notes, cryptographic keys, and devices from the server.", color = TextMutedSecondary, fontSize = 11.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    CrystalGlassButton(
                        onClick = { showDeleteDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = Color(0xFFEF4444)
                    ) {
                        Text(text = "Permanently Delete Account", color = Color(0xFFEF4444), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sign Out Button
            CrystalGlassButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth(),
                accentColor = Color(0xFFF59E0B)
            ) {
                Text(
                    text = "Sign Out of Vault",
                    color = Color(0xFFF59E0B),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            CrystalGlassButton(
                onClick = onSignOutEverywhere,
                modifier = Modifier.fillMaxWidth(),
                accentColor = Color(0xFFEF4444)
            ) {
                Text(
                    text = "Sign Out of All Devices",
                    color = Color(0xFFEF4444),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(30.dp))
        }

        // Delete Account Confirmation Dialog
        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = {
                    showDeleteDialog = false
                    deletePasswordInput = ""
                },
                title = {
                    Text(
                        text = "Delete Account Permanently?",
                        color = Color(0xFFEF4444),
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text(
                            text = "This action is irreversible. All your encrypted notes, version history, and device keys will be permanently deleted from the backend server.",
                            color = TextWhitePrimary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Enter your password to confirm:",
                            color = TextMutedSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = deletePasswordInput,
                            onValueChange = { deletePasswordInput = it },
                            placeholder = { Text("Password", color = TextTertiary) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFEF4444),
                                unfocusedBorderColor = GlassBorder,
                                focusedTextColor = TextWhitePrimary,
                                unfocusedTextColor = TextWhitePrimary,
                                cursorColor = Color(0xFFEF4444),
                                focusedContainerColor = ObsidianElevated,
                                unfocusedContainerColor = ObsidianElevated
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val pwd = deletePasswordInput
                            showDeleteDialog = false
                            deletePasswordInput = ""
                            onDeleteAccount(pwd)
                        }
                    ) {
                        Text("Delete", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showDeleteDialog = false
                            deletePasswordInput = ""
                        }
                    ) {
                        Text("Cancel", color = TextMutedSecondary)
                    }
                },
                containerColor = ObsidianElevated
            )
        }
    }
}
