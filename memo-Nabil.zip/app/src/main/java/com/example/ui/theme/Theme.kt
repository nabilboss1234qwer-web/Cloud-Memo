package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = ObsidianVoid,
    primaryContainer = ObsidianElevated,
    onPrimaryContainer = NeonCyan,
    secondary = ElectricViolet,
    onSecondary = TextWhitePrimary,
    secondaryContainer = ObsidianSurface,
    onSecondaryContainer = ElectricViolet,
    tertiary = NeonCyanVariant,
    onTertiary = ObsidianVoid,
    background = ObsidianVoid,
    onBackground = TextWhitePrimary,
    surface = ObsidianSurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = ObsidianElevated,
    onSurfaceVariant = TextMutedSecondary,
    outline = GlassBorder,
    outlineVariant = GlassSpecularReflection
)

@Composable
fun CloudMemoTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = ObsidianVoid.toArgb()
            window.navigationBarColor = ObsidianVoid.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = false
            controller.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CloudMemoTypography,
        content = content
    )
}
