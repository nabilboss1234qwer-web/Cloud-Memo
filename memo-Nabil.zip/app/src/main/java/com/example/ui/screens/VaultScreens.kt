package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CloudMemoTopAppBar
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanVariant
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary

private const val MIN_LEN = 12

@Composable
private fun BusyOrText(isBusy: Boolean, text: String, color: androidx.compose.ui.graphics.Color) {
    if (isBusy) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = color, strokeWidth = 2.dp)
    } else {
        Text(text, color = color, fontWeight = FontWeight.Bold)
    }
}

/** First sign-in on a new account (or first launch after the update): create the vault, then store the recovery key. */
@Composable
fun VaultSetupScreen(
    isBusy: Boolean,
    recoveryKey: String?,
    onCreate: (passphrase: String, confirm: String) -> Unit,
    onFinish: () -> Unit,
    onSignOut: () -> Unit
) {
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(title = if (recoveryKey == null) "Create your vault" else "Save your recovery key", onNavigateBack = null)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            if (recoveryKey == null) {
                Text(
                    "Your notes are encrypted with a secret key that only you can open. Choose a vault passphrase so you can read " +
                        "them on every device. CloudMemo never sees this passphrase and cannot reset it.",
                    color = TextMutedSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(20.dp))
                AccessTextField(pass, { pass = it }, "Vault passphrase ($MIN_LEN+ characters)", isPassword = true)
                Spacer(modifier = Modifier.height(6.dp))
                Text("${pass.length}/$MIN_LEN characters", color = if (pass.length >= MIN_LEN) NeonCyan else TextTertiary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))
                AccessTextField(confirm, { confirm = it }, "Confirm passphrase", isPassword = true, imeAction = ImeAction.Done)
                Spacer(modifier = Modifier.height(14.dp))
                CrystalGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = AmberPending) {
                    Text(
                        "If you forget the passphrase and lose the recovery key, notes on other devices cannot be recovered.",
                        color = AmberPending,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(14.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                CrystalGlassButton(onClick = { onCreate(pass, confirm) }, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan, enabled = !isBusy) {
                    BusyOrText(isBusy, "Create vault", NeonCyan)
                }
                Spacer(modifier = Modifier.height(12.dp))
                CrystalGlassButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth(), accentColor = CrimsonAlert) {
                    Text("Sign out", color = CrimsonAlert, fontWeight = FontWeight.Bold)
                }
            } else {
                Text(
                    "This recovery key can restore access if you forget your passphrase. Keep it somewhere safe and private " +
                        "(for example a password manager). It is shown only now.",
                    color = TextMutedSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                CrystalGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(recoveryKey, color = TextWhitePrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(12.dp))
                        CrystalGlassButton(onClick = { clipboard.setText(AnnotatedString(recoveryKey)) }, accentColor = NeonCyanVariant) {
                            Text("Copy recovery key", color = NeonCyanVariant, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = saved,
                        onCheckedChange = { saved = it },
                        colors = CheckboxDefaults.colors(checkedColor = NeonCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("I stored my recovery key safely", color = TextWhitePrimary, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.height(16.dp))
                CrystalGlassButton(onClick = onFinish, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan, enabled = saved && !isBusy) {
                    Text("Continue", color = if (saved) NeonCyan else TextTertiary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Existing vault on the server but no key on this device: unlock with the passphrase (or reset it with the recovery key). */
@Composable
fun VaultUnlockScreen(
    isBusy: Boolean,
    onUnlock: (passphrase: String) -> Unit,
    onRecover: (recoveryKey: String, newPassphrase: String, confirm: String) -> Unit,
    onSignOut: () -> Unit
) {
    var useRecovery by remember { mutableStateOf(false) }
    var pass by remember { mutableStateOf("") }
    var recovery by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(title = "Unlock your vault", onNavigateBack = null)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            if (!useRecovery) {
                Text(
                    "Enter your vault passphrase to open your encrypted notes on this device.",
                    color = TextMutedSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(20.dp))
                AccessTextField(pass, { pass = it }, "Vault passphrase", isPassword = true, imeAction = ImeAction.Done)
                Spacer(modifier = Modifier.height(20.dp))
                CrystalGlassButton(onClick = { onUnlock(pass) }, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan, enabled = !isBusy) {
                    BusyOrText(isBusy, "Unlock", NeonCyan)
                }
                Spacer(modifier = Modifier.height(12.dp))
                CrystalGlassButton(onClick = { useRecovery = true }, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyanVariant) {
                    Text("Forgot passphrase? Use recovery key", color = NeonCyanVariant, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Text(
                    "Enter the recovery key you saved and choose a new vault passphrase. The key is checked against one of your " +
                        "encrypted notes before anything is changed.",
                    color = TextMutedSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(20.dp))
                AccessTextField(recovery, { recovery = it }, "Recovery key")
                Spacer(modifier = Modifier.height(12.dp))
                AccessTextField(newPass, { newPass = it }, "New passphrase ($MIN_LEN+ characters)", isPassword = true)
                Spacer(modifier = Modifier.height(12.dp))
                AccessTextField(confirm, { confirm = it }, "Confirm new passphrase", isPassword = true, imeAction = ImeAction.Done)
                Spacer(modifier = Modifier.height(20.dp))
                CrystalGlassButton(onClick = { onRecover(recovery, newPass, confirm) }, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan, enabled = !isBusy) {
                    BusyOrText(isBusy, "Reset passphrase and unlock", NeonCyan)
                }
                Spacer(modifier = Modifier.height(12.dp))
                CrystalGlassButton(onClick = { useRecovery = false }, modifier = Modifier.fillMaxWidth(), accentColor = TextTertiary) {
                    Text("Back to passphrase", color = TextMutedSecondary)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            CrystalGlassButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth(), accentColor = CrimsonAlert) {
                Text("Sign out", color = CrimsonAlert, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun VaultChangePassphraseScreen(
    isBusy: Boolean,
    onSubmit: (newPassphrase: String, confirm: String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var newPass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(title = "Change vault passphrase", onNavigateBack = onNavigateBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "Your notes are not re-encrypted. Only the passphrase that protects your vault key changes. Use the new " +
                    "passphrase when you sign in on another device.",
                color = TextMutedSecondary,
                fontSize = 14.sp
            )
            AccessTextField(newPass, { newPass = it }, "New passphrase ($MIN_LEN+ characters)", isPassword = true)
            AccessTextField(confirm, { confirm = it }, "Confirm new passphrase", isPassword = true, imeAction = ImeAction.Done)
            CrystalGlassButton(onClick = { onSubmit(newPass, confirm) }, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan, enabled = !isBusy) {
                BusyOrText(isBusy, "Save new passphrase", NeonCyan)
            }
        }
    }
}
