package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Crystal Glassmorphism Palette
val ObsidianVoid = Color(0xFF05070D)
val ObsidianSurface = Color(0xFF090D18)
val ObsidianElevated = Color(0xFF101728)

// Crystal Glass Surface Overlays
val GlassCardBackground = Color(0x66111827)
val GlassCardBackgroundHover = Color(0x881E293B)
val GlassBorder = Color(0x3338BDF8)
val GlassBorderHighlight = Color(0x6600F5D4)
val GlassSpecularReflection = Color(0x1AFFFFFF)

// Neon & Accents
val NeonCyan = Color(0xFF00F5D4)
val NeonCyanVariant = Color(0xFF00BBF9)
val ElectricViolet = Color(0xFF9D4EDD)
val ElectricVioletVariant = Color(0xFF7B2CBF)
val HotPinkAccent = Color(0xFFF72585)

// Status Colors
val EmeraldOnline = Color(0xFF10B981)
val EmeraldGlow = Color(0x3310B981)
val CrimsonAlert = Color(0xFFEF4444)
val AmberPending = Color(0xFFF59E0B)

// Typography & Content
val TextWhitePrimary = Color(0xFFF8FAFC)
val TextMutedSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Note Tag Palette
val TagCyan = Color(0xFF00F5D4)
val TagPurple = Color(0xFFB5179E)
val TagYellow = Color(0xFFFFBE0B)
val TagGreen = Color(0xFF06D6A0)
val TagBlue = Color(0xFF118AB2)
