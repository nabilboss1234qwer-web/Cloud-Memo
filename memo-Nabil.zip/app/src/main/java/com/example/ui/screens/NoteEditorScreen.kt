package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CrystalGlassButton
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSpecularReflection
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary
import com.example.data.repository.SyncState
import com.example.ui.components.CloudSyncProofBadge
import com.example.ui.viewmodel.NoteEditorState

@Composable
fun NoteEditorScreen(
    state: NoteEditorState,
    syncState: SyncState = SyncState.Idle,
    onTitleChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onTagsChange: (String) -> Unit,
    onFolderChange: (String) -> Unit,
    onColorChange: (String) -> Unit,
    onTogglePreview: () -> Unit,
    onSave: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    var folderMenuExpanded by remember { mutableStateOf(false) }
    val folders = listOf("Personal", "Work", "Ideas", "Finance", "Archive")
    val colorPalette = listOf("#00F5D4", "#7B2CBF", "#F72585", "#06D6A0", "#118AB2", "#FFBE0B")

    val verticalScroll = rememberScrollState()
    val toolbarScroll = rememberScrollState()

    // Safe formatting insertion helper
    fun applyFormat(prefix: String, suffix: String = "") {
        val current = state.content
        onContentChange(current + "\n" + prefix + suffix)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
        ) {
            // Header Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(
                        Brush.verticalGradient(
                            listOf(ObsidianVoid, ObsidianSurface.copy(alpha = 0.95f))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(GlassSpecularReflection, GlassBorder, GlassSpecularReflection)
                        ),
                        RoundedCornerShape(0.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Back button & Title status
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                tint = TextWhitePrimary
                            )
                        }

                        CloudSyncProofBadge(
                            syncState = syncState,
                            onClick = onSave
                        )
                    }

                    // Save Button & 3-Horizontal Lines Menu
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CrystalGlassButton(
                            onClick = onSave,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            accentColor = NeonCyan
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Save",
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Save",
                                color = NeonCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // 3 Horizontal lines menu icon with proper anchoring and outside-tap dismissal
                        Box {
                            IconButton(onClick = {
                                folderMenuExpanded = false
                                menuExpanded = !menuExpanded
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Options Menu",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = menuExpanded,
                                onDismissRequest = { menuExpanded = false },
                                properties = androidx.compose.ui.window.PopupProperties(
                                    focusable = true,
                                    dismissOnBackPress = true,
                                    dismissOnClickOutside = true
                                ),
                                modifier = Modifier
                                    .background(ObsidianElevated)
                                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Default.Preview, contentDescription = null, tint = NeonCyan)
                                    },
                                    text = { Text(if (state.isMarkdownPreview) "Edit Mode" else "Markdown Preview", color = TextWhitePrimary) },
                                    onClick = {
                                        menuExpanded = false
                                        onTogglePreview()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Default.Share, contentDescription = null, tint = NeonCyan)
                                    },
                                    text = { Text("Share Note...", color = TextWhitePrimary) },
                                    onClick = {
                                        menuExpanded = false
                                        onShare()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFEF4444))
                                    },
                                    text = { Text("Move to Trash", color = Color(0xFFEF4444)) },
                                    onClick = {
                                        menuExpanded = false
                                        onDelete()
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Note Properties Bar: Folder selector & Responsive Color Swatches
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Folder drop-down selector
                Box {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, GlassBorder, RoundedCornerShape(10.dp))
                            .clickable {
                                menuExpanded = false
                                folderMenuExpanded = !folderMenuExpanded
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "📁 ${state.folder.ifBlank { "Personal" }}",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    DropdownMenu(
                        expanded = folderMenuExpanded,
                        onDismissRequest = { folderMenuExpanded = false },
                        properties = androidx.compose.ui.window.PopupProperties(
                            focusable = true,
                            dismissOnBackPress = true,
                            dismissOnClickOutside = true
                        ),
                        modifier = Modifier
                            .background(ObsidianElevated)
                            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                    ) {
                        folders.forEach { f ->
                            DropdownMenuItem(
                                text = { Text(f, color = TextWhitePrimary) },
                                onClick = {
                                    folderMenuExpanded = false
                                    onFolderChange(f)
                                }
                            )
                        }
                    }
                }

                // Accent Color Swatches with horizontal scrolling to prevent edge clipping on narrow screens
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    colorPalette.forEach { hex ->
                        val color = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = state.colorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 2.dp else 0.dp,
                                    color = if (isSelected) Color.White else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { onColorChange(hex) }
                        )
                    }
                }
            }

            // Main Editor Body
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(verticalScroll)
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                // Safe Title BasicTextField (No crash guarantee)
                BasicTextField(
                    value = state.title,
                    onValueChange = onTitleChange,
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = TextWhitePrimary,
                        lineHeight = 28.sp
                    ),
                    cursorBrush = SolidColor(NeonCyan),
                    decorationBox = { innerTextField ->
                        if (state.title.isEmpty()) {
                            Text(
                                text = "Note Title...",
                                color = TextTertiary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif
                            )
                        }
                        innerTextField()
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Tags Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tags: ",
                        color = TextTertiary,
                        fontSize = 12.sp
                    )
                    BasicTextField(
                        value = state.tags,
                        onValueChange = onTagsChange,
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 13.sp,
                            color = NeonCyan
                        ),
                        cursorBrush = SolidColor(NeonCyan),
                        decorationBox = { innerTextField ->
                            if (state.tags.isEmpty()) {
                                Text(
                                    text = "e.g. #work, #ideas",
                                    color = TextTertiary.copy(alpha = 0.7f),
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.SansSerif
                                )
                            }
                            innerTextField()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content TextField or Markdown Preview
                if (state.isMarkdownPreview) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianElevated)
                            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = if (state.content.isNotBlank()) state.content else "No content to preview.",
                            color = TextWhitePrimary,
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                } else {
                    BasicTextField(
                        value = state.content,
                        onValueChange = onContentChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Normal,
                            fontSize = 15.sp,
                            color = TextWhitePrimary,
                            lineHeight = 22.sp
                        ),
                        cursorBrush = SolidColor(NeonCyan),
                        decorationBox = { innerTextField ->
                            if (state.content.isEmpty()) {
                                Text(
                                    text = "Type your thoughts here... All notes are end-to-end encrypted with AES-256.",
                                    color = TextTertiary,
                                    fontSize = 15.sp,
                                    fontFamily = FontFamily.SansSerif,
                                    lineHeight = 22.sp
                                )
                            }
                            innerTextField()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(80.dp))
            }

            // Formatting Toolbar Docked at the bottom (Requirement 2)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianElevated)
                    .border(1.dp, GlassBorder, RoundedCornerShape(0.dp))
                    .navigationBarsPadding()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(toolbarScroll)
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FormatToolbarButton(icon = Icons.Default.FormatBold, label = "Bold") {
                        applyFormat("**Bold Text**")
                    }
                    FormatToolbarButton(icon = Icons.Default.FormatItalic, label = "Italic") {
                        applyFormat("*Italic Text*")
                    }
                    FormatToolbarButton(icon = Icons.Default.Title, label = "Heading") {
                        applyFormat("# Heading")
                    }
                    FormatToolbarButton(icon = Icons.Default.FormatListBulleted, label = "Bullet") {
                        applyFormat("- List item")
                    }
                    FormatToolbarButton(icon = Icons.Default.Code, label = "Code") {
                        applyFormat("```\ncode block\n```")
                    }
                    FormatToolbarButton(icon = Icons.Default.FormatQuote, label = "Quote") {
                        applyFormat("> Quoted text")
                    }
                }
            }
        }
    }
}

@Composable
private fun FormatToolbarButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(38.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = NeonCyan,
            modifier = Modifier.size(20.dp)
        )
    }
}
