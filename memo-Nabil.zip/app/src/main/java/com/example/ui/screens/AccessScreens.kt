package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotificationDto
import com.example.ui.components.CloudMemoTopAppBar
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanVariant
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.AccessBlockState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun AccessTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    isPassword: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        placeholder = { Text(placeholder, color = TextTertiary) },
        singleLine = true,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (isPassword) KeyboardType.Password else keyboardType,
            imeAction = imeAction
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = GlassBorder,
            focusedTextColor = TextWhitePrimary,
            unfocusedTextColor = TextWhitePrimary,
            cursorColor = NeonCyan,
            focusedContainerColor = ObsidianElevated,
            unfocusedContainerColor = ObsidianElevated
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

/** Full-screen state for a locked / suspended / banned / deleted account. */
@Composable
fun AccountBlockedScreen(
    state: AccessBlockState,
    onCheckAgain: () -> Unit,
    onSignOut: () -> Unit
) {
    val severe = state.code == "ACCOUNT_BANNED" || state.code == "ACCOUNT_DELETED"
    val accent = if (severe) CrimsonAlert else AmberPending
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = accent, modifier = Modifier.size(72.dp))
            Spacer(modifier = Modifier.height(20.dp))
            Text(state.title, color = TextWhitePrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(8.dp))
            Text(state.message, color = TextMutedSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
            if (!state.userMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                CrystalGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = accent) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Message from the administrator", color = accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(state.userMessage, color = TextWhitePrimary, fontSize = 14.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (severe) "If you think this is a mistake, contact CloudMemo support."
                else "Your notes stay safe on this device. Access returns when the restriction is lifted.",
                color = TextTertiary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(28.dp))
            if (state.code != "ACCOUNT_BANNED" && state.code != "ACCOUNT_DELETED") {
                CrystalGlassButton(onClick = onCheckAgain, modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan) {
                    Text("Check again", color = NeonCyan, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
            CrystalGlassButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth(), accentColor = CrimsonAlert) {
                Text("Sign out", color = CrimsonAlert, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Used both for the mandatory password change (after an admin reset) and the voluntary one from Settings. */
@Composable
fun PasswordChangeScreen(
    isForced: Boolean,
    isBusy: Boolean,
    onSubmit: (current: String, new: String, confirm: String) -> Unit,
    onNavigateBack: (() -> Unit)?,
    onSignOut: (() -> Unit)?
) {
    var current by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(
            title = if (isForced) "Set a new password" else "Change password",
            onNavigateBack = if (isForced) null else onNavigateBack
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = if (isForced) {
                    "An administrator reset your password. Enter the temporary password you received by email, then choose a new one to continue."
                } else {
                    "Choose a strong password of at least 12 characters. Other devices will be signed out."
                },
                color = TextMutedSecondary,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(20.dp))
            AccessTextField(current, { current = it }, if (isForced) "Temporary / current password" else "Current password", isPassword = true)
            Spacer(modifier = Modifier.height(12.dp))
            AccessTextField(newPass, { newPass = it }, "New password (12+ characters)", isPassword = true)
            Spacer(modifier = Modifier.height(12.dp))
            AccessTextField(confirm, { confirm = it }, "Confirm new password", isPassword = true, imeAction = ImeAction.Done)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Avoid common passwords, simple sequences and your name or email.",
                color = TextTertiary,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(24.dp))
            CrystalGlassButton(
                onClick = { onSubmit(current, newPass, confirm) },
                modifier = Modifier.fillMaxWidth(),
                accentColor = NeonCyan,
                enabled = !isBusy
            ) {
                if (isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = NeonCyan, strokeWidth = 2.dp)
                } else {
                    Text("Save new password", color = NeonCyan, fontWeight = FontWeight.Bold)
                }
            }
            if (isForced && onSignOut != null) {
                Spacer(modifier = Modifier.height(12.dp))
                CrystalGlassButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth(), accentColor = CrimsonAlert) {
                    Text("Sign out", color = CrimsonAlert, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ForgotPasswordScreen(
    initialEmail: String,
    codeSent: Boolean,
    isBusy: Boolean,
    onRequestCode: (email: String) -> Unit,
    onSubmitReset: (email: String, code: String, newPassword: String, confirm: String) -> Unit,
    onBack: () -> Unit
) {
    var email by remember { mutableStateOf(initialEmail) }
    var code by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(title = "Forgot password", onNavigateBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = if (codeSent) "Enter the 25-digit code from the email and choose a new password."
                else "Enter your account email. We will send a 25-digit reset code.",
                color = TextMutedSecondary,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(20.dp))
            AccessTextField(email, { email = it }, "user@example.com", keyboardType = KeyboardType.Email)
            if (codeSent) {
                Spacer(modifier = Modifier.height(12.dp))
                AccessTextField(
                    code, { code = it.filter { c -> c.isDigit() }.take(25) }, "25-digit code",
                    keyboardType = KeyboardType.Number
                )
                Spacer(modifier = Modifier.height(12.dp))
                AccessTextField(newPass, { newPass = it }, "New password (12+ characters)", isPassword = true)
                Spacer(modifier = Modifier.height(12.dp))
                AccessTextField(confirm, { confirm = it }, "Confirm new password", isPassword = true, imeAction = ImeAction.Done)
            }
            Spacer(modifier = Modifier.height(24.dp))
            CrystalGlassButton(
                onClick = {
                    if (codeSent) onSubmitReset(email, code, newPass, confirm) else onRequestCode(email)
                },
                modifier = Modifier.fillMaxWidth(),
                accentColor = NeonCyan,
                enabled = !isBusy
            ) {
                if (isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = NeonCyan, strokeWidth = 2.dp)
                } else {
                    Text(if (codeSent) "Reset password" else "Send reset code", color = NeonCyan, fontWeight = FontWeight.Bold)
                }
            }
            if (codeSent) {
                Spacer(modifier = Modifier.height(12.dp))
                CrystalGlassButton(
                    onClick = { onRequestCode(email) },
                    modifier = Modifier.fillMaxWidth(),
                    accentColor = NeonCyanVariant,
                    enabled = !isBusy
                ) {
                    Text("Send a new code", color = NeonCyanVariant, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

private fun formatEpoch(seconds: Long): String =
    if (seconds <= 0) "" else SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(seconds * 1000L))

@Composable
fun NotificationsScreen(
    items: List<NotificationDto>,
    unreadCount: Int,
    onRefresh: () -> Unit,
    onMarkAllRead: () -> Unit,
    onNavigateBack: () -> Unit
) {
    LaunchedEffect(Unit) { onRefresh() }

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(
            title = if (unreadCount > 0) "Notifications ($unreadCount new)" else "Notifications",
            onNavigateBack = onNavigateBack,
            menuItems = listOf("Mark all as read" to onMarkAllRead, "Refresh" to onRefresh)
        )
        if (items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No announcements yet.", color = TextMutedSecondary, fontSize = 14.sp)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items.forEach { n ->
                    val accent: Color = when (n.severity) {
                        "critical" -> CrimsonAlert
                        "warning" -> AmberPending
                        else -> NeonCyanVariant
                    }
                    CrystalGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = accent) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (!n.read) {
                                    Box(modifier = Modifier.size(8.dp).background(accent, RoundedCornerShape(4.dp)))
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text(n.title, color = TextWhitePrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(n.message, color = TextMutedSecondary, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(formatEpoch(n.createdAt), color = TextTertiary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
