package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PublicShareDto
import com.example.ui.components.CloudMemoTopAppBar
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.components.CrystalGlassChip
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanVariant
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val expiryOptions: List<Pair<String, Int?>> = listOf(
    "1 hour" to 1,
    "24 hours" to 24,
    "7 days" to 168,
    "30 days" to 720,
    "No expiry" to null
)

private fun fmtEpoch(seconds: Long?): String =
    if (seconds == null || seconds <= 0L) "never"
    else SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(seconds * 1000L))

/**
 * Public share links. The note is re-encrypted with a one-off key that only exists inside the link (#fragment),
 * so the CloudMemo server cannot read what is shared.
 */
@Composable
fun ShareNoteScreen(
    noteTitle: String,
    shares: List<PublicShareDto>,
    createdLink: String?,
    isBusy: Boolean,
    linkFor: (PublicShareDto) -> String?,
    onCreate: (expiresInHours: Int?, maxViews: Int?) -> Unit,
    onRefreshShare: (PublicShareDto) -> Unit,
    onRevokeShare: (String) -> Unit,
    onDismissCreated: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var expiryIndex by remember { mutableStateOf(1) }
    var maxViewsText by remember { mutableStateOf("") }
    var revokeTarget by remember { mutableStateOf<String?>(null) }

    fun copy(link: String) = clipboard.setText(AnnotatedString(link))
    fun send(link: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, link)
        }
        context.startActivity(Intent.createChooser(intent, "Share link"))
    }

    Column(modifier = Modifier.fillMaxSize().background(ObsidianVoid)) {
        CloudMemoTopAppBar(title = "Share note", onNavigateBack = onNavigateBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = noteTitle.ifBlank { "Untitled note" },
                color = TextWhitePrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            CrystalGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = AmberPending) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Anyone with the link can read this note", color = AmberPending, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "The decryption key is inside the link, so CloudMemo cannot read the shared copy. " +
                            "Later edits are not added to the link automatically: use \"Update shared copy\". " +
                            "Moving the note to the trash closes its links.",
                        color = TextMutedSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            if (createdLink != null) {
                CrystalGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = NeonCyan) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Your public link", color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(createdLink, color = TextWhitePrimary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CrystalGlassButton(onClick = { copy(createdLink) }, accentColor = NeonCyan) {
                                Text("Copy", color = NeonCyan, fontWeight = FontWeight.Bold)
                            }
                            CrystalGlassButton(onClick = { send(createdLink) }, accentColor = NeonCyanVariant) {
                                Text("Share", color = NeonCyanVariant, fontWeight = FontWeight.Bold)
                            }
                            CrystalGlassButton(onClick = onDismissCreated, accentColor = TextTertiary) {
                                Text("Done", color = TextMutedSecondary)
                            }
                        }
                    }
                }
            }

            Text("Create a new link", color = TextWhitePrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("Link expires after", color = TextMutedSecondary, fontSize = 12.sp)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                expiryOptions.forEachIndexed { index, option ->
                    CrystalGlassChip(
                        text = option.first,
                        isSelected = expiryIndex == index,
                        onClick = { expiryIndex = index }
                    )
                }
            }
            AccessTextField(
                value = maxViewsText,
                onValueChange = { maxViewsText = it.filter { c -> c.isDigit() }.take(5) },
                placeholder = "Max views (optional)",
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            )
            CrystalGlassButton(
                onClick = {
                    val views = maxViewsText.toIntOrNull()?.takeIf { it in 1..100000 }
                    onCreate(expiryOptions[expiryIndex].second, views)
                },
                modifier = Modifier.fillMaxWidth(),
                accentColor = NeonCyan,
                enabled = !isBusy
            ) {
                if (isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = NeonCyan, strokeWidth = 2.dp)
                } else {
                    Text("Create public link", color = NeonCyan, fontWeight = FontWeight.Bold)
                }
            }

            if (shares.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Links for this note", color = TextWhitePrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                shares.forEach { share ->
                    val link = linkFor(share)
                    CrystalGlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Views: ${share.viewCount}" + (share.maxViews?.let { " / $it" } ?: ""),
                                color = TextWhitePrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text("Expires: ${fmtEpoch(share.expiresAt)}", color = TextMutedSecondary, fontSize = 12.sp)
                            if (!share.active) {
                                Text("Inactive (expired or view limit reached)", color = CrimsonAlert, fontSize = 12.sp)
                            }
                            if (link == null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "The key for this link is not on this device. Revoke it and create a new link.",
                                    color = AmberPending,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (link != null) {
                                    CrystalGlassButton(onClick = { copy(link) }, accentColor = NeonCyan) {
                                        Text("Copy", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    CrystalGlassButton(onClick = { onRefreshShare(share) }, accentColor = NeonCyanVariant, enabled = !isBusy) {
                                        Text("Update copy", color = NeonCyanVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                CrystalGlassButton(onClick = { revokeTarget = share.shareId }, accentColor = CrimsonAlert) {
                                    Text("Revoke", color = CrimsonAlert, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (revokeTarget == share.shareId) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Revoke this link? People who have it will no longer be able to open it.", color = TextMutedSecondary, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CrystalGlassButton(onClick = { onRevokeShare(share.shareId); revokeTarget = null }, accentColor = CrimsonAlert) {
                                        Text("Yes, revoke", color = CrimsonAlert, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    CrystalGlassButton(onClick = { revokeTarget = null }, accentColor = TextTertiary) {
                                        Text("Cancel", color = TextMutedSecondary, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
