package com.example.ui.model

enum class NoteDisplayLayout(val id: String, val title: String) {
    GRID_VIEW("GRID_VIEW", "Grid"),
    COMPACT_LIST("COMPACT_LIST", "Compact"),
    COMFORTABLE_LIST("COMFORTABLE_LIST", "Comfortable"),
    LARGE_CARDS("LARGE_CARDS", "Large");

    companion object {
        fun fromId(id: String): NoteDisplayLayout {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: GRID_VIEW
        }
    }
}
