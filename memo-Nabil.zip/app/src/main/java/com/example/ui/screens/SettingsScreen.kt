package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.SyncState
import com.example.ui.components.CloudMemoTopAppBar
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary

@Composable
fun SettingsScreen(
    userEmail: String?,
    isLoggedIn: Boolean,
    autoSyncEnabled: Boolean,
    onToggleAutoSync: (Boolean) -> Unit,
    syncState: SyncState,
    onTriggerSync: () -> Unit,
    onOpenDevices: () -> Unit,
    onOpenAccount: () -> Unit,
    onLogout: () -> Unit,
    deviceFingerprint: String,
    isVaultLockEnabled: Boolean,
    onOpenPinSetup: () -> Unit,
    onDisablePinLock: () -> Unit,
    onOpenTermsOfService: () -> Unit = {},
    onOpenPrivacyPolicy: () -> Unit = {},
    onNavigateBack: (() -> Unit)? = null,
    onOpenNotifications: () -> Unit = {},
    onOpenChangePassword: () -> Unit = {},
    onOpenVaultPassphrase: () -> Unit = {},
    secureScreenEnabled: Boolean = false,
    onToggleSecureScreen: (Boolean) -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            CloudMemoTopAppBar(
                title = "Settings",
                onNavigateBack = onNavigateBack,
                syncState = syncState,
                onTriggerSync = onTriggerSync
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 128.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Account Section
                item {
                    SettingsSectionHeader(title = "Account & Cloud")
                    Spacer(modifier = Modifier.height(6.dp))
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = NeonCyan
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = userEmail ?: "Authenticated Cloud User",
                                        color = TextWhitePrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Cloud synchronization & E2E encryption active",
                                        color = TextMutedSecondary,
                                        fontSize = 12.sp
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(EmeraldOnline.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "AUTHENTICATED",
                                        color = EmeraldOnline,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CrystalGlassButton(
                                    onClick = onTriggerSync,
                                    modifier = Modifier.weight(1f),
                                    accentColor = NeonCyan
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sync,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sync Now", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }

                                if (isLoggedIn) {
                                    CrystalGlassButton(
                                        onClick = onLogout,
                                        modifier = Modifier.weight(1f),
                                        accentColor = Color(0xFFEF4444)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Logout,
                                            contentDescription = null,
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Sign Out", color = Color(0xFFEF4444), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Security & Vault Lock Section
                item {
                    SettingsSectionHeader(title = "Security & Vault Lock")
                    Spacer(modifier = Modifier.height(6.dp))
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = EmeraldOnline
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // User Controlled PIN / Biometric Toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "App Vault Lock (PIN / Biometric)",
                                        color = TextWhitePrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (isVaultLockEnabled) "Vault locked with 4-digit PIN & Biometrics" else "Tap toggle to set PIN & Fingerprint/Face lock",
                                        color = TextMutedSecondary,
                                        fontSize = 12.sp
                                    )
                                }

                                Switch(
                                    checked = isVaultLockEnabled,
                                    onCheckedChange = { enabled ->
                                        if (enabled) {
                                            onOpenPinSetup()
                                        } else {
                                            onDisablePinLock()
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianVoid,
                                        checkedTrackColor = NeonCyan,
                                        uncheckedThumbColor = TextMutedSecondary,
                                        uncheckedTrackColor = ObsidianElevated
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            SettingRow(
                                icon = Icons.Default.Lock,
                                title = "Encryption Standard",
                                subtitle = "AES-256-GCM (Authenticated Encryption)",
                                iconTint = EmeraldOnline
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingRow(
                                icon = Icons.Default.Security,
                                title = "Hardware Keystore",
                                subtitle = "Android Keystore backed device identity",
                                iconTint = NeonCyan
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingRow(
                                icon = Icons.Default.CheckCircle,
                                title = "Device Fingerprint",
                                subtitle = deviceFingerprint,
                                iconTint = ElectricViolet
                            )
                        }
                    }
                }

                // Synchronization Preferences
                item {
                    SettingsSectionHeader(title = "Synchronization")
                    Spacer(modifier = Modifier.height(6.dp))
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = NeonCyan
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Automatic Cloud Sync",
                                        color = TextWhitePrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Sync notes in background when changes occur",
                                        color = TextMutedSecondary,
                                        fontSize = 12.sp
                                    )
                                }

                                Switch(
                                    checked = autoSyncEnabled,
                                    onCheckedChange = onToggleAutoSync,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianVoid,
                                        checkedTrackColor = NeonCyan,
                                        uncheckedThumbColor = TextMutedSecondary,
                                        uncheckedTrackColor = ObsidianElevated
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingActionRow(
                                icon = Icons.Default.Devices,
                                title = "Connected Devices",
                                subtitle = "Manage authenticated multi-device sessions",
                                onClick = onOpenDevices
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingActionRow(
                                icon = Icons.Default.Notifications,
                                title = "Notifications",
                                subtitle = "Announcements and account notices",
                                onClick = onOpenNotifications
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingActionRow(
                                icon = Icons.Default.Lock,
                                title = "Change password",
                                subtitle = "Other devices are signed out afterwards",
                                onClick = onOpenChangePassword
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingActionRow(
                                icon = Icons.Default.Lock,
                                title = "Vault passphrase",
                                subtitle = "Protects the key that opens your notes on every device",
                                onClick = onOpenVaultPassphrase
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Hide content in screenshots",
                                        color = TextWhitePrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Blocks screenshots and the recent-apps preview",
                                        color = TextMutedSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                                Switch(
                                    checked = secureScreenEnabled,
                                    onCheckedChange = onToggleSecureScreen,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianVoid,
                                        checkedTrackColor = NeonCyan,
                                        uncheckedThumbColor = TextMutedSecondary,
                                        uncheckedTrackColor = ObsidianElevated
                                    )
                                )
                            }
                        }
                    }
                }

                // Appearance & Design System
                item {
                    SettingsSectionHeader(title = "Appearance & Interface")
                    Spacer(modifier = Modifier.height(6.dp))
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = ElectricViolet
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            SettingRow(
                                icon = Icons.Default.Palette,
                                title = "Theme Preset",
                                subtitle = "Obsidian Crystal Glassmorphism (Default)",
                                iconTint = ElectricViolet
                            )
                        }
                    }
                }

                // About & Support
                item {
                    SettingsSectionHeader(title = "About & Help")
                    Spacer(modifier = Modifier.height(6.dp))
                    CrystalGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = GlassBorder
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            SettingRow(
                                icon = Icons.Default.Info,
                                title = "CloudMemo Version",
                                subtitle = "v9.0.0 (3D Obsidian Crystal Edition)",
                                iconTint = NeonCyan
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingRow(
                                icon = Icons.Default.HelpOutline,
                                title = "Client-Side Zero-Knowledge Privacy",
                                subtitle = "Notes encrypted with AES-256-GCM before transmission.",
                                iconTint = EmeraldOnline
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            SettingActionRow(
                                icon = Icons.Default.Security,
                                title = "Terms of Service",
                                subtitle = "Review accepted CloudMemo Terms (v1)",
                                onClick = onOpenTermsOfService
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            SettingActionRow(
                                icon = Icons.Default.Lock,
                                title = "Privacy Policy",
                                subtitle = "Zero-knowledge encryption & data policies",
                                onClick = onOpenPrivacyPolicy
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        color = NeonCyan,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 4.dp)
    )
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconTint: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                color = TextWhitePrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = TextMutedSecondary,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    color = TextWhitePrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = TextMutedSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Icon(
            imageVector = Icons.Default.ArrowForwardIos,
            contentDescription = null,
            tint = TextTertiary,
            modifier = Modifier.size(14.dp)
        )
    }
}
