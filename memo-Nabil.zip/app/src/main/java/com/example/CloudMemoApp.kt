package com.example

import android.app.Application
import com.example.push.NotificationChannels
import com.example.push.PushRegistrar

class CloudMemoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Firebase must exist before a push wakes the app in the background, so it is initialised here.
        PushRegistrar.ensureInitialized(this)
        NotificationChannels.create(this)
    }
}
