package com.example.data.repository

sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    data class Synced(val message: String = "Synced to Cloud", val timestamp: Long = System.currentTimeMillis()) : SyncState()
    data class Pending(val pendingCount: Int = 1, val message: String = "Saved Locally") : SyncState()
    data class Error(val errorMessage: String) : SyncState()
}
