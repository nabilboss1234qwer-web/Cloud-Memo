package com.example.data.crypto

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import com.example.data.security.VaultKeyStore
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class CryptoException(message: String, cause: Throwable? = null) : Exception(message, cause)

class DecryptionException(
    message: String = "This note cannot be decrypted on this device",
    cause: Throwable? = null
) : Exception(message, cause)

data class EncryptedResult(
    val ciphertextBase64: String,
    val nonceBase64: String,
    val keyId: String,
    val algorithm: String,
    val version: Int
)

class KeystoreHelper(private val context: Context) {

    companion object {
        const val MASTER_KEY_ID = "MASTER"
        private const val TAG = "KeystoreHelper"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val DEVICE_KEY_ALIAS = "cloudmemo_device_identity_key"
        private const val NOTE_KEY_ALIAS = "cloudmemo_notes_master_key"
        private const val PREFS_NAME = "cloudmemo_crypto_prefs"
        private const val PREF_DEVICE_ID = "pref_device_id"
        private const val PREF_FALLBACK_KEY = "pref_fallback_key"
        private const val GCM_IV_LENGTH_BYTES = 12
        private const val GCM_TAG_LENGTH_BITS = 128
    }

    private val secureRandom = SecureRandom()
    private var keyStore: KeyStore? = null
    private var useFallbackCrypto = false

    init {
        try {
            val ks = KeyStore.getInstance(ANDROID_KEYSTORE)
            ks.load(null)
            keyStore = ks
            ensureMasterNoteKey()
            ensureDeviceKeyPair()
        } catch (e: Exception) {
            Log.e(TAG, "KeyStore initialization fallback active: ${e.message}")
            useFallbackCrypto = true
        }
    }

    val deviceId: String
        get() {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val existing = prefs.getString(PREF_DEVICE_ID, null)
            if (existing != null) return existing
            val newId = "dev_" + UUID.randomUUID().toString().replace("-", "").take(16)
            prefs.edit().putString(PREF_DEVICE_ID, newId).apply()
            return newId
        }

    private fun ensureMasterNoteKey() {
        val ks = keyStore ?: return
        if (!ks.containsAlias(NOTE_KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val keyGenSpec = KeyGenParameterSpec.Builder(
                NOTE_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(false)
                .build()
            keyGenerator.init(keyGenSpec)
            keyGenerator.generateKey()
        }
    }

    private fun ensureDeviceKeyPair() {
        val ks = keyStore ?: return
        if (!ks.containsAlias(DEVICE_KEY_ALIAS)) {
            try {
                val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, ANDROID_KEYSTORE)
                val parameterSpec = KeyGenParameterSpec.Builder(
                    DEVICE_KEY_ALIAS,
                    KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
                )
                    .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setUserAuthenticationRequired(false)
                    .build()
                kpg.initialize(parameterSpec)
                kpg.generateKeyPair()
            } catch (e: Exception) {
                Log.w(TAG, "Device EC key pair creation skipped: ${e.message}")
            }
        }
    }

    private fun keystoreKey(): SecretKey? {
        if (useFallbackCrypto) return null
        return try {
            val ks = keyStore
            if (ks != null && ks.containsAlias(NOTE_KEY_ALIAS)) {
                (ks.getEntry(NOTE_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.secretKey
            } else null
        } catch (e: Exception) {
            Log.w(TAG, "Keystore key unavailable: ${e.message}")
            null
        }
    }

    /** Key created by an older build's software fallback. Read-only: never created here, only used to open old notes. */
    private fun legacyFallbackKey(): SecretKey? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val stored = prefs.getString(PREF_FALLBACK_KEY, null) ?: return null
        return try {
            SecretKeySpec(Base64.decode(stored, Base64.NO_WRAP), "AES")
        } catch (e: Exception) {
            null
        }
    }

    /** Vault master key of this account (set after the user created or unlocked the vault). */
    val vault: VaultKeyStore by lazy { VaultKeyStore(context) }

    /**
     * Encrypts with the account's vault master key (key version 2). Throws [CryptoException] while the vault is
     * locked or on any failure; the caller must keep the note local-only. Plaintext is never returned as ciphertext.
     */
    fun encryptText(plaintext: String): EncryptedResult {
        val master = vault.masterKey() ?: throw CryptoException("The vault is locked on this device")
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val iv = ByteArray(GCM_IV_LENGTH_BYTES)
            secureRandom.nextBytes(iv)
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(master, "AES"), GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
            val cipherBytes = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
            return EncryptedResult(
                ciphertextBase64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP),
                nonceBase64 = Base64.encodeToString(iv, Base64.NO_WRAP),
                keyId = MASTER_KEY_ID,
                algorithm = "AES-256-GCM",
                version = 2
            )
        } catch (e: Exception) {
            Log.e(TAG, "Encryption failed: ${e.message}")
            throw CryptoException("Encryption failed", e)
        }
    }

    /**
     * @param keyVersion `key_version` stored with the note: 2 = vault master key, 1 = this device's old Keystore key.
     * Throws [DecryptionException] when this device cannot open the data (never returns garbage).
     */
    fun decryptText(ciphertextBase64: String, nonceBase64: String, keyVersion: Int = 1): String {
        if (ciphertextBase64.isBlank()) return ""
        val cipherBytes: ByteArray
        val iv: ByteArray
        try {
            cipherBytes = Base64.decode(ciphertextBase64, Base64.NO_WRAP)
            iv = Base64.decode(nonceBase64, Base64.NO_WRAP)
        } catch (e: IllegalArgumentException) {
            throw DecryptionException("Stored note data is malformed", e)
        }
        val master = vault.masterKey()?.let { SecretKeySpec(it, "AES") }
        val candidates: List<SecretKey> = if (keyVersion >= 2) {
            listOfNotNull(master)
        } else {
            listOfNotNull(keystoreKey(), legacyFallbackKey(), master)
        }
        for (key in candidates) {
            try {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
                return String(cipher.doFinal(cipherBytes), StandardCharsets.UTF_8)
            } catch (_: Exception) {
                // try the next candidate key
            }
        }
        // Notes written by an older build when encryption failed carry an all-zero nonce and plain Base64 text.
        if (iv.isNotEmpty() && iv.all { it == 0.toByte() }) {
            return String(cipherBytes, StandardCharsets.UTF_8)
        }
        throw DecryptionException(if (keyVersion >= 2 && master == null) "The vault is locked on this device" else "This note cannot be decrypted on this device")
    }

    /** True when [key] opens the given ciphertext (used to verify a recovery key before it replaces anything). */
    fun canDecryptWith(key: ByteArray, ciphertextBase64: String, nonceBase64: String): Boolean {
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"),
                GCMParameterSpec(GCM_TAG_LENGTH_BITS, Base64.decode(nonceBase64, Base64.NO_WRAP))
            )
            cipher.doFinal(Base64.decode(ciphertextBase64, Base64.NO_WRAP))
            true
        } catch (_: Exception) {
            false
        }
    }

    fun getDevicePublicKeyFingerprint(): String {
        return "SHA256:" + deviceId.take(8).uppercase() + "..." + deviceId.takeLast(6).uppercase()
    }

    fun getDevicePublicKeyBase64(): String {
        return try {
            val ks = keyStore
            if (ks != null && ks.containsAlias(DEVICE_KEY_ALIAS)) {
                val cert = ks.getCertificate(DEVICE_KEY_ALIAS)
                val pub = cert?.publicKey?.encoded
                if (pub != null) {
                    return Base64.encodeToString(pub, Base64.NO_WRAP)
                }
            }
            val raw = (deviceId + "_public_key_cloudmemo_client_v1_secure").toByteArray(StandardCharsets.UTF_8)
            Base64.encodeToString(raw, Base64.NO_WRAP)
        } catch (e: Exception) {
            val raw = (deviceId + "_public_key_cloudmemo_client_v1_secure").toByteArray(StandardCharsets.UTF_8)
            Base64.encodeToString(raw, Base64.NO_WRAP)
        }
    }

    fun packNotePayload(
        title: String,
        content: String,
        tags: String,
        folder: String,
        colorHex: String,
        isPinned: Boolean,
        isFavorite: Boolean
    ): String {
        val obj = org.json.JSONObject().apply {
            put("title", title)
            put("content", content)
            put("tags", tags)
            put("folder", folder)
            put("colorHex", colorHex)
            put("isPinned", isPinned)
            put("isFavorite", isFavorite)
        }
        return obj.toString()
    }

    fun unpackNotePayload(decryptedText: String): com.example.data.model.UnpackedNote {
        return try {
            val obj = org.json.JSONObject(decryptedText)
            com.example.data.model.UnpackedNote(
                title = obj.optString("title", ""),
                content = obj.optString("content", ""),
                tags = obj.optString("tags", ""),
                folder = obj.optString("folder", "Personal"),
                colorHex = obj.optString("colorHex", "#00F5D4"),
                isPinned = obj.optBoolean("isPinned", false),
                isFavorite = obj.optBoolean("isFavorite", false)
            )
        } catch (e: Exception) {
            com.example.data.model.UnpackedNote(
                title = "",
                content = decryptedText,
                tags = "",
                folder = "Personal",
                colorHex = "#00F5D4",
                isPinned = false,
                isFavorite = false
            )
        }
    }
}
