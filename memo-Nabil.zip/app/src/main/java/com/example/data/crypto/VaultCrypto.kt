package com.example.data.crypto

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class WrongPassphraseException : Exception("Wrong vault passphrase")

/** The wrapped master key as stored by the server (`/v1/account/key-bundle`). The server never sees the passphrase. */
data class KeyBundle(
    val version: Int,
    val wrappedKey: String,
    val nonce: String,
    val salt: String,
    val iterations: Int
)

/**
 * Master-key handling for multi-device end-to-end encryption.
 * A random 256-bit master key encrypts all notes. It is wrapped (AES-256-GCM) with a key derived from the user's
 * vault passphrase (PBKDF2-HMAC-SHA256) and uploaded, so a new device can unlock the same notes.
 * Android-free (java.util.Base64) so it can be unit tested on the JVM.
 */
object VaultCrypto {
    private const val AAD = "cloudmemo-key-bundle-v1"
    const val ITERATIONS = 310_000
    const val MIN_ITERATIONS = 210_000
    const val MAX_ITERATIONS = 5_000_000
    const val MIN_PASSPHRASE_LENGTH = 12

    private fun b64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)
    private fun unb64(text: String): ByteArray = Base64.getDecoder().decode(text)
    private fun random(size: Int): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }

    fun newMasterKey(): ByteArray = random(32)

    private fun deriveKek(passphrase: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(passphrase, salt, iterations, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun wrap(master: ByteArray, passphrase: CharArray, version: Int): KeyBundle {
        require(master.size == 32) { "Master key must be 32 bytes" }
        val salt = random(16)
        val iv = random(12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(deriveKek(passphrase, salt, ITERATIONS), "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        return KeyBundle(version, b64(cipher.doFinal(master)), b64(iv), b64(salt), ITERATIONS)
    }

    /** @throws WrongPassphraseException when the passphrase does not open the bundle. */
    fun unwrap(bundle: KeyBundle, passphrase: CharArray): ByteArray {
        require(bundle.iterations in MIN_ITERATIONS..MAX_ITERATIONS) { "Unsafe key-derivation settings received from the server" }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(deriveKek(passphrase, unb64(bundle.salt), bundle.iterations), "AES"),
                GCMParameterSpec(128, unb64(bundle.nonce))
            )
            cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
            val master = cipher.doFinal(unb64(bundle.wrappedKey))
            if (master.size != 32) throw WrongPassphraseException()
            master
        } catch (e: AEADBadTagException) {
            throw WrongPassphraseException()
        }
    }

    /** Human-friendly backup of the master key: 64 hex characters in groups of 8 (no ambiguous separators). */
    fun toRecoveryKey(master: ByteArray): String =
        master.joinToString("") { "%02x".format(it) }.chunked(8).joinToString("-")

    /** @return the 32-byte key or null when the text is not a valid recovery key. */
    fun fromRecoveryKey(text: String): ByteArray? {
        val cleaned = text.filter { !it.isWhitespace() && it != '-' }.lowercase()
        if (cleaned.length != 64 || !cleaned.all { it in '0'..'9' || it in 'a'..'f' }) return null
        return ByteArray(32) { i -> cleaned.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }
}
