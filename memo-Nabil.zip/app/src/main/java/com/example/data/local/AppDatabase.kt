package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [NoteDbEntity::class, PendingSyncDbEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun roomNoteDao(): RoomNoteDao
    abstract fun roomPendingSyncDao(): RoomPendingSyncDao

    companion object {
        private const val DB_NAME = "cloudmemo_local.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    // Only the very first schema (v1) may be rebuilt. From v2 on, add a Migration for every bump so
                    // local notes and the unsynced queue are never wiped.
                    .fallbackToDestructiveMigrationFrom(1)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
