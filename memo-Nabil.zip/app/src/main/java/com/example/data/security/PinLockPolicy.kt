package com.example.data.security

/** Pure lockout schedule for wrong vault PIN attempts (kept Android-free so it can be unit tested). */
object PinLockPolicy {
    /** Seconds the PIN pad stays locked after the given number of consecutive wrong attempts. */
    fun lockSecondsAfterFailure(totalFailures: Int): Long = when {
        totalFailures < 5 -> 0L
        totalFailures == 5 -> 30L
        totalFailures == 6 -> 60L
        totalFailures == 7 -> 300L
        else -> 900L
    }
}
