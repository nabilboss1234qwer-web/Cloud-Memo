package com.example.data.repository

/** Pure sync-cursor logic (Android-free, unit tested). */
object SyncCursor {
    /**
     * @param since        cursor used for the request that just finished
     * @param maxUpdated   largest `updated_at` among the returned items (0 when none)
     * @param serverTime   `server_time` from the response
     * @param hasMore      `has_more` from the response
     * @return Pair(new cursor, whether another page must be fetched)
     */
    fun next(since: Long, maxUpdated: Long, serverTime: Long, hasMore: Boolean): Pair<Long, Boolean> =
        if (hasMore && maxUpdated > since) {
            maxUpdated to true
        } else {
            // A small margin protects against notes written in the same second as server_time.
            maxOf(since, maxUpdated, serverTime - 2L) to false
        }
}
