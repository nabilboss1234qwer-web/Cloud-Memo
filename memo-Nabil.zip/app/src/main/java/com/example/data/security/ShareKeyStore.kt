package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Keeps the per-share decryption key (link fragment) on this device only, so the link can be copied again later. */
class ShareKeyStore(private val context: Context) {

    companion object {
        private const val FILE = "cloudmemo_share_keys"
    }

    private val prefs: SharedPreferences = create()

    private fun create(): SharedPreferences {
        fun build(): SharedPreferences {
            val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            build()
        } catch (e: Exception) {
            context.deleteSharedPreferences(FILE)
            build()
        }
    }

    fun get(shareId: String): String? = prefs.getString(shareId, null)

    fun put(shareId: String, keyFragment: String) {
        prefs.edit().putString(shareId, keyFragment).apply()
    }

    fun remove(shareId: String) {
        prefs.edit().remove(shareId).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
