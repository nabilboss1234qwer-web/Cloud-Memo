package com.example.data.crypto

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Zero-knowledge public sharing: a note snapshot is encrypted with a random one-off key. The key is only ever put
 * in the link fragment (#key), so the server stores ciphertext it cannot read.
 */
object ShareCrypto {
    fun newKey(): ByteArray = ByteArray(32).also { SecureRandom().nextBytes(it) }

    /** @return Pair(ciphertext Base64, nonce Base64); ciphertext = AES-256-GCM output including the tag. */
    fun encrypt(key: ByteArray, plaintext: String): Pair<String, String> {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(ct, Base64.NO_WRAP) to Base64.encodeToString(iv, Base64.NO_WRAP)
    }

    fun keyToFragment(key: ByteArray): String =
        Base64.encodeToString(key, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    fun fragmentToKey(fragment: String): ByteArray =
        Base64.decode(fragment, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
}
