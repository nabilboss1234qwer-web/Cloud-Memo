package com.example.data.repository

import com.example.data.crypto.CryptoException
import com.example.data.crypto.DecryptionException
import com.example.data.crypto.KeystoreHelper
import com.example.data.crypto.ShareCrypto
import com.example.data.local.AppDatabase
import com.example.data.local.NoteDbEntity
import com.example.data.local.PendingSyncDbEntity
import com.example.data.model.ApiErrorDetail
import com.example.data.model.NoteEntity
import com.example.data.model.NoteServerItemDto
import com.example.data.model.PublicShareDto
import com.example.data.model.TrashServerItemDto
import com.example.data.network.CloudMemoApiService
import com.example.data.network.SessionManager
import com.example.data.security.ShareKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

class NoteRepository(
    private val database: AppDatabase,
    private val keystoreHelper: KeystoreHelper,
    private val apiService: CloudMemoApiService,
    private val sessionManager: SessionManager,
    private val shareKeyStore: ShareKeyStore
) {
    companion object {
        /** Backend rejects payloads above ~900 KB (Firestore documents are capped at 1 MiB). */
        const val MAX_SYNC_PAYLOAD_BYTES = 900_000
        const val MAX_RETRIES = 5

        const val STATUS_SYNCED = "SYNCED"
        const val STATUS_SAVED_LOCAL = "SAVED_LOCAL"
        const val STATUS_ENCRYPTION_ERROR = "ENCRYPTION_ERROR"
        const val STATUS_TOO_LARGE = "TOO_LARGE"
    }

    val noteDao = database.roomNoteDao()
    val pendingSyncDao = database.roomPendingSyncDao()

    val notes: Flow<List<NoteEntity>> = noteDao.getAllActiveNotesFlow().map { list -> list.map { it.toDomain() } }
    val trashedNotes: Flow<List<NoteEntity>> = noteDao.getTrashedNotesFlow().map { list -> list.map { it.toDomain() } }
    val pendingSyncCount: Flow<Int> = pendingSyncDao.getPendingCountFlow()

    private val _undecryptableNotes = MutableStateFlow(0)

    /** Number of notes from the last sync that this device could not decrypt (encrypted on another device). */
    val undecryptableNotes: StateFlow<Int> = _undecryptableNotes.asStateFlow()

    private fun utcFormat() = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private fun getCurrentIsoTime(): String = utcFormat().format(Date())

    private fun isoFromEpochSeconds(seconds: Long): String =
        if (seconds > 0) utcFormat().format(Date(seconds * 1000L)) else getCurrentIsoTime()

    suspend fun getNoteById(noteId: String): NoteEntity? = noteDao.getNoteById(noteId)?.toDomain()

    suspend fun pendingOperationCount(): Int = withContext(Dispatchers.IO) { pendingSyncDao.getAllPending().size }

    /** Removes every local note and the unsynced queue (logout / switching accounts). */
    suspend fun wipeLocalData() = withContext(Dispatchers.IO) {
        noteDao.clearAll()
        pendingSyncDao.clearQueue()
        sessionManager.lastSyncTimestamp = 0L
        sessionManager.dataOwnerId = null
        shareKeyStore.clear()
        keystoreHelper.vault.clear()
        _undecryptableNotes.value = 0
    }

    suspend fun saveNote(
        id: String?,
        title: String,
        content: String,
        tags: String,
        folder: String,
        colorHex: String,
        isPinned: Boolean,
        isFavorite: Boolean
    ): String = withContext(Dispatchers.IO) {
        val now = getCurrentIsoTime()
        // FastAPI backend schema requires note_id minLength: 8
        val noteId = id?.ifBlank { null } ?: ("note_" + UUID.randomUUID().toString().replace("-", "").take(12))

        val existing = noteDao.getNoteById(noteId)
        val revision = (existing?.revision ?: 0L) + 1L

        val packedPayload = keystoreHelper.packNotePayload(
            title = title,
            content = content,
            tags = tags,
            folder = folder.ifBlank { "Personal" },
            colorHex = colorHex.ifBlank { "#00F5D4" },
            isPinned = isPinned,
            isFavorite = isFavorite
        )

        // Never fall back to storing plaintext "ciphertext": on failure the note stays local-only.
        val enc = try {
            keystoreHelper.encryptText(packedPayload)
        } catch (_: CryptoException) {
            null
        }

        val tooLarge = enc != null && enc.ciphertextBase64.toByteArray().size > MAX_SYNC_PAYLOAD_BYTES
        if (enc == null || tooLarge) {
            noteDao.insertOrUpdate(
                NoteDbEntity(
                    id = noteId,
                    revision = revision,
                    serverVersion = existing?.serverVersion ?: 1L,
                    titleCiphertext = enc?.ciphertextBase64 ?: "",
                    contentCiphertext = enc?.ciphertextBase64 ?: "",
                    decryptedTitleCache = title,
                    decryptedContentCache = content,
                    tagsCiphertext = null,
                    decryptedTagsCache = tags,
                    encryptionNonce = enc?.nonceBase64 ?: "",
                    folder = folder.ifBlank { "Personal" },
                    colorHex = colorHex.ifBlank { "#00F5D4" },
                    isPinned = isPinned,
                    isFavorite = isFavorite,
                    isDeleted = false,
                    deletedAt = null,
                    createdAt = existing?.createdAt ?: now,
                    updatedAt = now,
                    syncStatus = if (enc == null) STATUS_ENCRYPTION_ERROR else STATUS_TOO_LARGE
                )
            )
            return@withContext noteId
        }

        val noteDbEntity = NoteDbEntity(
            id = noteId,
            revision = revision,
            serverVersion = existing?.serverVersion ?: 1L,
            titleCiphertext = enc.ciphertextBase64,
            contentCiphertext = enc.ciphertextBase64,
            decryptedTitleCache = title,
            decryptedContentCache = content,
            tagsCiphertext = null,
            decryptedTagsCache = tags,
            encryptionNonce = enc.nonceBase64,
            encryptionKeyId = enc.keyId,
            encryptionAlgorithm = enc.algorithm,
            encryptionVersion = enc.version,
            folder = folder.ifBlank { "Personal" },
            colorHex = colorHex.ifBlank { "#00F5D4" },
            isPinned = isPinned,
            isFavorite = isFavorite,
            isDeleted = false,
            deletedAt = null,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now,
            syncStatus = STATUS_SAVED_LOCAL
        )

        noteDao.insertOrUpdate(noteDbEntity)

        val op = PendingSyncDbEntity(
            operationId = "op_" + UUID.randomUUID().toString().take(8),
            noteId = noteId,
            type = if (existing == null) "CREATE" else "UPDATE",
            expectedRevision = revision,
            titleCiphertext = enc.ciphertextBase64,
            contentCiphertext = enc.ciphertextBase64,
            tagsCiphertext = null,
            nonce = enc.nonceBase64,
            keyId = enc.keyId,
            folder = folder,
            colorHex = colorHex
        )
        pendingSyncDao.enqueue(op)

        if (sessionManager.isLoggedIn) {
            try {
                val res = if (existing == null) {
                    apiService.createNote(
                        noteId = noteId,
                        encryptedPayload = enc.ciphertextBase64,
                        nonce = enc.nonceBase64,
                        keyVersion = enc.version,
                        clientVersion = revision
                    )
                } else {
                    apiService.updateNote(
                        noteId = noteId,
                        encryptedPayload = enc.ciphertextBase64,
                        nonce = enc.nonceBase64,
                        keyVersion = enc.version,
                        clientVersion = revision
                    )
                }
                res.onSuccess { serverItem ->
                    noteDao.insertOrUpdate(
                        noteDbEntity.copy(serverVersion = serverItem.serverVersion, syncStatus = STATUS_SYNCED)
                    )
                    // This push already carries the newest state; older queued steps for the note are obsolete.
                    pendingSyncDao.getAllPending()
                        .filter { it.noteId == noteId && it.type != "DELETE" && it.type != "PURGE" && it.type != "RESTORE" }
                        .forEach { pendingSyncDao.removeByOperationId(it.operationId) }
                }
            } catch (_: Exception) {
                // stays queued; syncNow() retries
            }
        }

        noteId
    }

    suspend fun softDeleteNote(noteId: String) = withContext(Dispatchers.IO) {
        val now = getCurrentIsoTime()
        noteDao.softDelete(noteId, now)
        val op = PendingSyncDbEntity(
            operationId = "op_del_" + UUID.randomUUID().toString().take(8),
            noteId = noteId,
            type = "DELETE",
            expectedRevision = 0L
        )
        pendingSyncDao.enqueue(op)

        if (sessionManager.isLoggedIn) {
            try {
                val res = apiService.trashNote(noteId)
                if (res.isSuccess || (res.exceptionOrNull() as? ApiErrorDetail)?.statusCode == 404) {
                    pendingSyncDao.removeByOperationId(op.operationId)
                }
            } catch (_: Exception) {
            }
        }
    }

    suspend fun restoreNote(noteId: String) = withContext(Dispatchers.IO) {
        noteDao.restoreNote(noteId)
        // A DELETE that never reached the server is simply cancelled.
        val pendingDelete = pendingSyncDao.getAllPending().filter { it.noteId == noteId && it.type == "DELETE" }
        if (pendingDelete.isNotEmpty()) {
            pendingDelete.forEach { pendingSyncDao.removeByOperationId(it.operationId) }
            return@withContext
        }
        val op = PendingSyncDbEntity(
            operationId = "op_res_" + UUID.randomUUID().toString().take(8),
            noteId = noteId,
            type = "RESTORE",
            expectedRevision = 0L
        )
        pendingSyncDao.enqueue(op)
        if (sessionManager.isLoggedIn) {
            try {
                val res = apiService.restoreTrashNote(noteId)
                if (res.isSuccess || (res.exceptionOrNull() as? ApiErrorDetail)?.statusCode == 404) {
                    pendingSyncDao.removeByOperationId(op.operationId)
                }
            } catch (_: Exception) {
            }
        }
    }

    suspend fun permanentDeleteNote(noteId: String) = withContext(Dispatchers.IO) {
        noteDao.deleteById(noteId)
        // Drop obsolete edits but keep a pending DELETE so the server trashes the note before purging it.
        pendingSyncDao.getAllPending()
            .filter { it.noteId == noteId && it.type != "DELETE" }
            .forEach { pendingSyncDao.removeByOperationId(it.operationId) }
        val op = PendingSyncDbEntity(
            operationId = "op_purge_" + UUID.randomUUID().toString().take(8),
            noteId = noteId,
            type = "PURGE",
            expectedRevision = 0L
        )
        pendingSyncDao.enqueue(op)
        if (sessionManager.isLoggedIn) {
            try {
                // Make sure the server copy is in the trash first (no-op if it already is).
                if (pendingSyncDao.getAllPending().any { it.noteId == noteId && it.type == "DELETE" }) return@withContext
                val res = apiService.permanentDeleteTrashNote(noteId)
                if (res.isSuccess || (res.exceptionOrNull() as? ApiErrorDetail)?.statusCode == 404) {
                    pendingSyncDao.removeByOperationId(op.operationId)
                }
            } catch (_: Exception) {
            }
        }
    }

    suspend fun listTrashFromServer(): Result<List<TrashServerItemDto>> = withContext(Dispatchers.IO) {
        if (!sessionManager.isLoggedIn) return@withContext Result.success(emptyList())
        apiService.listTrash()
    }

    suspend fun togglePin(noteId: String, isPinned: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setPinned(noteId, isPinned)
        val note = noteDao.getNoteById(noteId) ?: return@withContext
        saveNote(
            id = note.id,
            title = note.decryptedTitleCache,
            content = note.decryptedContentCache,
            tags = note.decryptedTagsCache,
            folder = note.folder,
            colorHex = note.colorHex,
            isPinned = isPinned,
            isFavorite = note.isFavorite
        )
    }

    suspend fun toggleFavorite(noteId: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setFavorite(noteId, isFavorite)
        val note = noteDao.getNoteById(noteId) ?: return@withContext
        saveNote(
            id = note.id,
            title = note.decryptedTitleCache,
            content = note.decryptedContentCache,
            tags = note.decryptedTagsCache,
            folder = note.folder,
            colorHex = note.colorHex,
            isPinned = note.isPinned,
            isFavorite = isFavorite
        )
    }

    suspend fun searchLocalNotes(query: String): List<NoteEntity> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        noteDao.searchLocalNotes(query).map { it.toDomain() }
    }

    // ------------------------------------------------------------------
    // Sync
    // ------------------------------------------------------------------

    private enum class PushOutcome { DONE, RETRY, CONFLICT_RESOLVED }

    private fun ApiErrorDetail.isAuthProblem(): Boolean = statusCode == 401 || statusCode == 403

    /** Re-encrypts notes that were saved while secure key storage was unavailable, so they can sync later. */
    private suspend fun retryEncryptionErrors() {
        val stuck = noteDao.getAllActiveNotes().filter { it.syncStatus == STATUS_ENCRYPTION_ERROR }
        for (note in stuck) {
            val packed = keystoreHelper.packNotePayload(
                title = note.decryptedTitleCache, content = note.decryptedContentCache, tags = note.decryptedTagsCache,
                folder = note.folder, colorHex = note.colorHex, isPinned = note.isPinned, isFavorite = note.isFavorite
            )
            val enc = try {
                keystoreHelper.encryptText(packed)
            } catch (_: CryptoException) {
                continue
            }
            if (enc.ciphertextBase64.toByteArray().size > MAX_SYNC_PAYLOAD_BYTES) continue
            noteDao.insertOrUpdate(
                note.copy(
                    titleCiphertext = enc.ciphertextBase64,
                    contentCiphertext = enc.ciphertextBase64,
                    encryptionNonce = enc.nonceBase64,
                    encryptionKeyId = enc.keyId,
                    encryptionAlgorithm = enc.algorithm,
                    encryptionVersion = enc.version,
                    syncStatus = STATUS_SAVED_LOCAL
                )
            )
            pendingSyncDao.enqueue(
                PendingSyncDbEntity(
                    operationId = "op_" + UUID.randomUUID().toString().take(8),
                    noteId = note.id,
                    type = "CREATE",
                    expectedRevision = note.revision,
                    titleCiphertext = enc.ciphertextBase64,
                    contentCiphertext = enc.ciphertextBase64,
                    nonce = enc.nonceBase64,
                    keyId = enc.keyId,
                    folder = note.folder,
                    colorHex = note.colorHex
                )
            )
        }
    }

    private suspend fun markSynced(noteId: String, serverVersion: Long?) {
        noteDao.getNoteById(noteId)?.let { current ->
            noteDao.insertOrUpdate(
                current.copy(
                    serverVersion = serverVersion ?: current.serverVersion,
                    syncStatus = STATUS_SYNCED
                )
            )
        }
    }

    /** Pushes a note version; on a version conflict the local edit is kept as a copy and the server version adopted. */
    private suspend fun pushNoteVersion(
        p: PendingSyncDbEntity,
        createFirst: Boolean,
        fallbackUsed: Boolean = false
    ): Pair<PushOutcome, ApiErrorDetail?> {
        val keyVersion = if (p.keyId == KeystoreHelper.MASTER_KEY_ID) 2 else 1
        val payload = p.contentCiphertext ?: ""
        val nonce = p.nonce ?: ""
        if (payload.isBlank() || nonce.isBlank()) {
            // Nothing valid to send; drop the empty operation so it cannot block the queue.
            pendingSyncDao.removeByOperationId(p.operationId)
            return PushOutcome.DONE to null
        }
        val res = if (createFirst) {
            apiService.createNote(p.noteId, payload, nonce, keyVersion = keyVersion, clientVersion = p.expectedRevision)
        } else {
            apiService.updateNote(p.noteId, payload, nonce, keyVersion = keyVersion, clientVersion = p.expectedRevision)
        }
        if (res.isSuccess) {
            markSynced(p.noteId, res.getOrNull()?.serverVersion)
            pendingSyncDao.removeByOperationId(p.operationId)
            return PushOutcome.DONE to null
        }
        val err = res.exceptionOrNull() as? ApiErrorDetail ?: return PushOutcome.RETRY to null
        return when {
            err.isAuthProblem() -> PushOutcome.RETRY to err
            // create hit "already exists": it is really an update
            createFirst && err.statusCode == 409 && !fallbackUsed -> pushNoteVersion(p, createFirst = false, fallbackUsed = true)
            // update of a note the server does not have yet: create it
            !createFirst && err.statusCode == 404 && !fallbackUsed -> pushNoteVersion(p, createFirst = true, fallbackUsed = true)
            !createFirst && err.statusCode == 409 -> {
                val serverNote = apiService.getNote(p.noteId).getOrNull()
                if (serverNote == null) {
                    PushOutcome.RETRY to null
                } else {
                    noteDao.getNoteById(p.noteId)?.let { createConflictCopy(it, "(conflict copy)") }
                    pendingSyncDao.getAllPending()
                        .filter { it.noteId == p.noteId }
                        .forEach { pendingSyncDao.removeByOperationId(it.operationId) }
                    applyRemoteItem(serverNote, emptySet(), force = true)
                    PushOutcome.CONFLICT_RESOLVED to null
                }
            }
            // validation / size problems never succeed on retry
            err.statusCode == 413 || err.statusCode == 422 -> {
                noteDao.getNoteById(p.noteId)?.let { noteDao.insertOrUpdate(it.copy(syncStatus = STATUS_TOO_LARGE)) }
                pendingSyncDao.removeByOperationId(p.operationId)
                PushOutcome.DONE to null
            }
            else -> PushOutcome.RETRY to null
        }
    }

    private suspend fun pushOperation(p: PendingSyncDbEntity): Pair<PushOutcome, ApiErrorDetail?> {
        return when (p.type) {
            "CREATE" -> pushNoteVersion(p, createFirst = true)
            "UPDATE" -> pushNoteVersion(p, createFirst = false)
            "DELETE", "RESTORE", "PURGE" -> {
                val res = when (p.type) {
                    "DELETE" -> apiService.trashNote(p.noteId)
                    "RESTORE" -> apiService.restoreTrashNote(p.noteId)
                    else -> apiService.permanentDeleteTrashNote(p.noteId)
                }
                val err = res.exceptionOrNull() as? ApiErrorDetail
                when {
                    res.isSuccess || err?.statusCode == 404 -> {
                        pendingSyncDao.removeByOperationId(p.operationId)
                        PushOutcome.DONE to null
                    }
                    err != null && err.isAuthProblem() -> PushOutcome.RETRY to err
                    else -> PushOutcome.RETRY to null
                }
            }
            else -> {
                pendingSyncDao.removeByOperationId(p.operationId)
                PushOutcome.DONE to null
            }
        }
    }

    private suspend fun createConflictCopy(local: NoteDbEntity, label: String) {
        saveNote(
            id = null,
            title = (local.decryptedTitleCache.ifBlank { "Untitled" }) + " " + label,
            content = local.decryptedContentCache,
            tags = local.decryptedTagsCache,
            folder = local.folder,
            colorHex = local.colorHex,
            isPinned = false,
            isFavorite = local.isFavorite
        )
    }

    private enum class ApplyOutcome { APPLIED, SKIPPED, UNDECRYPTABLE }

    /** Applies one server change locally without ever silently discarding unsynced local work. */
    private suspend fun applyRemoteItem(
        item: NoteServerItemDto,
        pendingNoteIds: Set<String>,
        force: Boolean = false
    ): ApplyOutcome {
        val local = noteDao.getNoteById(item.noteId)
        val hasPending = !force && local != null && pendingNoteIds.contains(item.noteId)
        if (hasPending && item.serverVersion <= local!!.serverVersion) return ApplyOutcome.SKIPPED
        val bothChanged = hasPending && item.serverVersion > local!!.serverVersion

        if (item.deleted) {
            if (local == null) return ApplyOutcome.SKIPPED
            if (bothChanged) {
                createConflictCopy(local, "(recovered)")
                pendingSyncDao.getAllPending()
                    .filter { it.noteId == item.noteId }
                    .forEach { pendingSyncDao.removeByOperationId(it.operationId) }
            }
            noteDao.softDelete(item.noteId, isoFromEpochSeconds(item.deletedAt ?: 0L))
            return ApplyOutcome.APPLIED
        }

        val decryptedJson = try {
            keystoreHelper.decryptText(item.encryptedPayload, item.nonce, item.keyVersion)
        } catch (_: DecryptionException) {
            return ApplyOutcome.UNDECRYPTABLE
        }
        val unpacked = keystoreHelper.unpackNotePayload(decryptedJson)

        if (bothChanged) {
            // Keep my edit as a copy and adopt the server version for the original note.
            createConflictCopy(local!!, "(conflict copy)")
            pendingSyncDao.getAllPending()
                .filter { it.noteId == item.noteId }
                .forEach { pendingSyncDao.removeByOperationId(it.operationId) }
        } else if (local != null && local.syncStatus == STATUS_SYNCED && item.serverVersion < local.serverVersion) {
            return ApplyOutcome.SKIPPED
        }

        noteDao.insertOrUpdate(
            NoteDbEntity(
                id = item.noteId,
                revision = maxOf(item.clientVersion, local?.revision ?: 1L),
                serverVersion = item.serverVersion,
                titleCiphertext = item.encryptedPayload,
                contentCiphertext = item.encryptedPayload,
                decryptedTitleCache = unpacked.title.ifBlank { "Encrypted Note" },
                decryptedContentCache = unpacked.content,
                tagsCiphertext = null,
                decryptedTagsCache = unpacked.tags,
                encryptionNonce = item.nonce,
                encryptionVersion = item.keyVersion,
                folder = unpacked.folder,
                colorHex = unpacked.colorHex,
                isPinned = unpacked.isPinned,
                isFavorite = unpacked.isFavorite,
                isDeleted = false,
                deletedAt = null,
                createdAt = if (item.createdAt > 0) isoFromEpochSeconds(item.createdAt) else (local?.createdAt ?: getCurrentIsoTime()),
                updatedAt = if (item.updatedAt > 0) isoFromEpochSeconds(item.updatedAt) else getCurrentIsoTime(),
                syncStatus = STATUS_SYNCED
            )
        )
        return ApplyOutcome.APPLIED
    }

    suspend fun syncNow(): Result<String> = withContext(Dispatchers.IO) {
        if (!sessionManager.isLoggedIn) {
            return@withContext Result.failure(Exception("Authentication required to synchronize notes."))
        }

        try {
            retryEncryptionErrors()

            // Step 1: push the local queue (oldest first)
            var failedOps = 0
            var conflicts = 0
            for (p in pendingSyncDao.getAllPending()) {
                if (p.retryCount >= MAX_RETRIES) {
                    failedOps++
                    continue
                }
                val (outcome, authErr) = try {
                    pushOperation(p)
                } catch (e: Exception) {
                    PushOutcome.RETRY to null
                }
                if (authErr != null) return@withContext Result.failure(authErr)   // locked / banned / expired: stop now
                when (outcome) {
                    PushOutcome.DONE -> Unit
                    PushOutcome.CONFLICT_RESOLVED -> conflicts++
                    PushOutcome.RETRY -> {
                        pendingSyncDao.incrementRetry(p.operationId)
                        if (p.retryCount + 1 >= MAX_RETRIES) failedOps++
                    }
                }
            }

            // Step 2: pull every change page by page
            val pendingNoteIds = pendingSyncDao.getAllPending().map { it.noteId }.toSet()
            var since = sessionManager.lastSyncTimestamp
            var undecryptable = 0
            var pulled = 0
            while (true) {
                val page = apiService.getSyncChanges(since = since, limit = 100)
                    .getOrElse { return@withContext Result.failure(it) }
                for (item in page.items) {
                    try {
                        when (applyRemoteItem(item, pendingNoteIds)) {
                            ApplyOutcome.APPLIED -> pulled++
                            ApplyOutcome.UNDECRYPTABLE -> undecryptable++
                            ApplyOutcome.SKIPPED -> Unit
                        }
                    } catch (_: Exception) {
                        // one bad item must not block the rest
                    }
                }
                val (newSince, more) = SyncCursor.next(
                    since = since,
                    maxUpdated = page.items.maxOfOrNull { it.updatedAt } ?: 0L,
                    serverTime = page.serverTime,
                    hasMore = page.hasMore
                )
                since = newSince
                sessionManager.lastSyncTimestamp = since
                if (!more) break
            }
            _undecryptableNotes.value = undecryptable

            val parts = mutableListOf("Synced with the CloudMemo server.")
            if (pulled > 0) parts.add("$pulled note(s) updated from the cloud.")
            if (conflicts > 0) parts.add("$conflicts conflict(s) saved as copies.")
            if (undecryptable > 0) parts.add("$undecryptable note(s) were encrypted on another device and cannot be opened here.")
            if (failedOps > 0) parts.add("$failedOps change(s) could not be uploaded.")
            Result.success(parts.joinToString(" "))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ------------------------------------------------------------------
    // Vault migration
    // ------------------------------------------------------------------

    /**
     * Re-encrypts notes that were protected only by this device's old Keystore key with the vault master key, so every
     * device of the account can open them. The plain text comes from the local cache; queued old payloads are replaced.
     * Trashed notes are left as they are (the server keeps them for a limited time only).
     * @return how many notes were migrated
     */
    suspend fun reencryptAllWithMasterKey(): Int = withContext(Dispatchers.IO) {
        if (!keystoreHelper.vault.hasMasterKey()) return@withContext 0
        var migrated = 0
        for (note in noteDao.getAllActiveNotes()) {
            if (note.encryptionVersion >= 2 && note.syncStatus != STATUS_ENCRYPTION_ERROR) continue
            val packed = keystoreHelper.packNotePayload(
                title = note.decryptedTitleCache, content = note.decryptedContentCache, tags = note.decryptedTagsCache,
                folder = note.folder, colorHex = note.colorHex, isPinned = note.isPinned, isFavorite = note.isFavorite
            )
            val enc = try {
                keystoreHelper.encryptText(packed)
            } catch (_: CryptoException) {
                continue
            }
            val revision = note.revision + 1
            val tooLarge = enc.ciphertextBase64.toByteArray().size > MAX_SYNC_PAYLOAD_BYTES
            noteDao.insertOrUpdate(
                note.copy(
                    revision = revision,
                    titleCiphertext = enc.ciphertextBase64,
                    contentCiphertext = enc.ciphertextBase64,
                    encryptionNonce = enc.nonceBase64,
                    encryptionKeyId = enc.keyId,
                    encryptionAlgorithm = enc.algorithm,
                    encryptionVersion = enc.version,
                    syncStatus = if (tooLarge) STATUS_TOO_LARGE else STATUS_SAVED_LOCAL
                )
            )
            pendingSyncDao.getAllPending()
                .filter { it.noteId == note.id && (it.type == "CREATE" || it.type == "UPDATE") }
                .forEach { pendingSyncDao.removeByOperationId(it.operationId) }
            if (!tooLarge) {
                // UPDATE also covers notes the server has never seen (a 404 falls back to create).
                pendingSyncDao.enqueue(
                    PendingSyncDbEntity(
                        operationId = "op_" + UUID.randomUUID().toString().take(8),
                        noteId = note.id,
                        type = "UPDATE",
                        expectedRevision = revision,
                        titleCiphertext = enc.ciphertextBase64,
                        contentCiphertext = enc.ciphertextBase64,
                        tagsCiphertext = null,
                        nonce = enc.nonceBase64,
                        keyId = enc.keyId,
                        folder = note.folder,
                        colorHex = note.colorHex
                    )
                )
            }
            migrated++
        }
        migrated
    }

    /**
     * Checks a candidate master key (e.g. from a recovery key) against one encrypted note stored on the server.
     * @return true = matches, false = does not match, null = nothing to compare against / server unreachable
     */
    suspend fun verifyMasterKeyAgainstServer(candidate: ByteArray): Boolean? = withContext(Dispatchers.IO) {
        val page = apiService.getSyncChanges(since = 0L, limit = 100).getOrNull() ?: return@withContext null
        val sample = page.items.firstOrNull { !it.deleted && it.keyVersion >= 2 } ?: return@withContext null
        keystoreHelper.canDecryptWith(candidate, sample.encryptedPayload, sample.nonce)
    }

    // ------------------------------------------------------------------
    // Public share links (end-to-end encrypted with a one-off key kept in the link fragment)
    // ------------------------------------------------------------------

    suspend fun createPublicShare(noteId: String, expiresInHours: Int?, maxViews: Int?): Result<String> =
        withContext(Dispatchers.IO) {
            if (!sessionManager.isLoggedIn) return@withContext Result.failure(Exception("Sign in to share notes."))
            var note = noteDao.getNoteById(noteId) ?: return@withContext Result.failure(Exception("Note not found."))
            if (note.syncStatus != STATUS_SYNCED) {
                syncNow()
                note = noteDao.getNoteById(noteId) ?: return@withContext Result.failure(Exception("Note not found."))
                if (note.syncStatus != STATUS_SYNCED) {
                    return@withContext Result.failure(Exception("Sync this note first (check your internet connection), then share it."))
                }
            }
            val key = ShareCrypto.newKey()
            val (payload, nonce) = ShareCrypto.encrypt(key, sharePlaintext(note))
            val created = apiService.createShare(noteId, payload, nonce, expiresInHours, maxViews)
            val share = created.getOrElse { return@withContext Result.failure(it) }
            val fragment = ShareCrypto.keyToFragment(key)
            shareKeyStore.put(share.shareId, fragment)
            Result.success(share.url + "#" + fragment)
        }

    private fun sharePlaintext(note: NoteDbEntity): String = JSONObject()
        .put("title", note.decryptedTitleCache)
        .put("content", note.decryptedContentCache)
        .put("tags", note.decryptedTagsCache)
        .toString()

    suspend fun listPublicShares(noteId: String): Result<List<PublicShareDto>> = withContext(Dispatchers.IO) {
        apiService.listShares(noteId)
    }

    /** Full link (with decryption key) or null when this device no longer holds the key. */
    fun shareLink(share: PublicShareDto): String? =
        shareKeyStore.get(share.shareId)?.let { share.url + "#" + it }

    suspend fun refreshPublicShare(noteId: String, share: PublicShareDto): Result<Boolean> = withContext(Dispatchers.IO) {
        val fragment = shareKeyStore.get(share.shareId)
            ?: return@withContext Result.failure(Exception("The key for this link is not on this device. Revoke it and create a new link."))
        val note = noteDao.getNoteById(noteId) ?: return@withContext Result.failure(Exception("Note not found."))
        val (payload, nonce) = ShareCrypto.encrypt(ShareCrypto.fragmentToKey(fragment), sharePlaintext(note))
        apiService.updateShare(share.shareId, payload, nonce)
    }

    suspend fun revokePublicShare(shareId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val res = apiService.deleteShare(shareId)
        if (res.isSuccess || (res.exceptionOrNull() as? ApiErrorDetail)?.statusCode == 404) {
            shareKeyStore.remove(shareId)
            Result.success(true)
        } else {
            res
        }
    }
}
