package com.example.data.network

import kotlinx.coroutines.flow.MutableSharedFlow

/** Server-driven account/session events emitted from the API layer and handled once by the UI. */
sealed interface AccessEvent {
    data class Blocked(val code: String, val message: String?, val userMessage: String?) : AccessEvent
    object PasswordChangeRequired : AccessEvent
    object EmailNotVerified : AccessEvent
    object SessionExpired : AccessEvent
}

object AccessEvents {
    val flow = MutableSharedFlow<AccessEvent>(extraBufferCapacity = 8)

    /** Emitted when a push (or app resume) asks the app to re-check GET /v1/account/status. */
    val statusCheck = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /** Emitted when the inbox should be reloaded (push arrived). */
    val inboxRefresh = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
}
