package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Holds the unwrapped vault master key on this device (encrypted with an Android Keystore backed key). */
class VaultKeyStore(private val context: Context) {

    companion object {
        private const val FILE = "cloudmemo_vault_keys"
        private const val KEY_MASTER = "master_key_b64"
    }

    private val prefs: SharedPreferences = create()

    private fun create(): SharedPreferences {
        fun build(): SharedPreferences {
            val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            build()
        } catch (e: Exception) {
            context.deleteSharedPreferences(FILE)
            build()
        }
    }

    fun hasMasterKey(): Boolean = prefs.contains(KEY_MASTER)

    fun masterKey(): ByteArray? {
        val stored = prefs.getString(KEY_MASTER, null) ?: return null
        return try {
            Base64.decode(stored, Base64.NO_WRAP).takeIf { it.size == 32 }
        } catch (_: IllegalArgumentException) {
            null
        }
    }

    fun set(master: ByteArray) {
        prefs.edit().putString(KEY_MASTER, Base64.encodeToString(master, Base64.NO_WRAP)).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
