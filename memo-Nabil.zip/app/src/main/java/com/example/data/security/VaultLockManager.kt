package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class VaultLockManager(private val context: Context) {

    companion object {
        private const val LEGACY_PREFS = "cloudmemo_security_prefs"
        private const val SECURE_PREFS = "cloudmemo_security_secure"
        private const val KEY_ENABLED = "is_vault_lock_enabled"
        private const val KEY_BIOMETRIC = "is_biometric_enabled"
        private const val KEY_LEGACY_HASH = "saved_pin_hash"
        private const val KEY_SALT = "pin_salt"
        private const val KEY_HASH = "pin_hash_pbkdf2"
        private const val KEY_FAILS = "pin_failures"
        private const val KEY_LOCK_UNTIL = "pin_lock_until_ms"
        private const val PBKDF2_ITERATIONS = 210_000
    }

    /** Legacy plain file: only read once to migrate flags and to upgrade an old unsalted PIN hash. */
    private val legacyPrefs = context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)

    private val prefs: SharedPreferences = createSecurePrefs()

    private fun createSecurePrefs(): SharedPreferences {
        fun build(): SharedPreferences {
            val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, SECURE_PREFS, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        val secure = try {
            build()
        } catch (e: Exception) {
            context.deleteSharedPreferences(SECURE_PREFS)
            build()
        }
        if (!secure.contains(KEY_ENABLED) && legacyPrefs.contains(KEY_ENABLED)) {
            secure.edit()
                .putBoolean(KEY_ENABLED, legacyPrefs.getBoolean(KEY_ENABLED, false))
                .putBoolean(KEY_BIOMETRIC, legacyPrefs.getBoolean(KEY_BIOMETRIC, false))
                .apply()
        }
        return secure
    }

    var isVaultLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var isBiometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC, false)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRIC, value).apply()

    private fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } finally {
            spec.clearPassword()
        }
    }

    private fun legacySha256(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun savePin(pin: String) {
        val salt = newSalt()
        prefs.edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, hashPin(pin, salt))
            .putInt(KEY_FAILS, 0)
            .putLong(KEY_LOCK_UNTIL, 0L)
            .apply()
        legacyPrefs.edit().remove(KEY_LEGACY_HASH).apply()
        isVaultLockEnabled = true
    }

    /** Seconds until the PIN pad accepts input again (0 when not locked). */
    fun lockRemainingSeconds(): Long {
        val remainingMs = prefs.getLong(KEY_LOCK_UNTIL, 0L) - System.currentTimeMillis()
        return if (remainingMs > 0) (remainingMs + 999L) / 1000L else 0L
    }

    fun verifyPin(pin: String): Boolean {
        if (lockRemainingSeconds() > 0) return false
        val saltB64 = prefs.getString(KEY_SALT, null)
        val storedHash = prefs.getString(KEY_HASH, null)
        val ok = when {
            saltB64 != null && storedHash != null ->
                MessageDigest.isEqual(
                    hashPin(pin, Base64.decode(saltB64, Base64.NO_WRAP)).toByteArray(),
                    storedHash.toByteArray()
                )
            else -> {
                // Older build: unsalted SHA-256. Accept once, then upgrade to the salted PBKDF2 hash.
                val legacy = legacyPrefs.getString(KEY_LEGACY_HASH, null)
                val match = legacy != null &&
                    MessageDigest.isEqual(legacy.toByteArray(), legacySha256(pin).toByteArray())
                if (match) savePin(pin)
                match
            }
        }
        if (ok) {
            prefs.edit().putInt(KEY_FAILS, 0).putLong(KEY_LOCK_UNTIL, 0L).apply()
        } else {
            val fails = prefs.getInt(KEY_FAILS, 0) + 1
            val lockSeconds = PinLockPolicy.lockSecondsAfterFailure(fails)
            prefs.edit()
                .putInt(KEY_FAILS, fails)
                .putLong(KEY_LOCK_UNTIL, if (lockSeconds > 0) System.currentTimeMillis() + lockSeconds * 1000L else 0L)
                .apply()
        }
        return ok
    }

    fun disableVaultLock() {
        prefs.edit()
            .remove(KEY_SALT).remove(KEY_HASH).remove(KEY_FAILS).remove(KEY_LOCK_UNTIL)
            .apply()
        legacyPrefs.edit().remove(KEY_LEGACY_HASH).apply()
        isVaultLockEnabled = false
        isBiometricEnabled = false
    }

    fun isBiometricAvailable(): Boolean {
        return try {
            val biometricManager = BiometricManager.from(context)
            biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
            ) == BiometricManager.BIOMETRIC_SUCCESS
        } catch (e: Exception) {
            false
        }
    }

    fun showBiometricPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val biometricPrompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        onError(errString.toString())
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        onError("Fingerprint/Face not recognized. Try again.")
                    }
                }
            )

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("CloudMemo Vault Unlock")
                .setSubtitle("Authenticate using Fingerprint or Face unlock")
                .setNegativeButtonText("Use PIN")
                .build()

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.message ?: "Biometric prompt unavailable")
        }
    }
}
