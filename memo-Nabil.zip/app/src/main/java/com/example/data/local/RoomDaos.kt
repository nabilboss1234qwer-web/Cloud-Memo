package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RoomNoteDao {
    @Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY isPinned DESC, updatedAt DESC")
    fun getAllActiveNotesFlow(): Flow<List<NoteDbEntity>>

    @Query("SELECT * FROM notes WHERE isDeleted = 1 ORDER BY deletedAt DESC, updatedAt DESC")
    fun getTrashedNotesFlow(): Flow<List<NoteDbEntity>>

    @Query("SELECT * FROM notes WHERE id = :noteId")
    fun getNoteByIdFlow(noteId: String): Flow<NoteDbEntity?>

    @Query("SELECT * FROM notes WHERE id = :noteId")
    suspend fun getNoteById(noteId: String): NoteDbEntity?

    @Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY isPinned DESC, updatedAt DESC")
    suspend fun getAllActiveNotes(): List<NoteDbEntity>

    @Query("SELECT * FROM notes WHERE isDeleted = 0 AND (decryptedTitleCache LIKE '%' || :query || '%' OR decryptedContentCache LIKE '%' || :query || '%' OR decryptedTagsCache LIKE '%' || :query || '%' OR folder LIKE '%' || :query || '%') ORDER BY isPinned DESC, updatedAt DESC")
    suspend fun searchLocalNotes(query: String): List<NoteDbEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(note: NoteDbEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<NoteDbEntity>)

    @Update
    suspend fun update(note: NoteDbEntity)

    @Delete
    suspend fun delete(note: NoteDbEntity)

    @Query("DELETE FROM notes WHERE id = :noteId")
    suspend fun deleteById(noteId: String)

    @Query("UPDATE notes SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :noteId")
    suspend fun softDelete(noteId: String, deletedAt: String)

    @Query("UPDATE notes SET isDeleted = 0, deletedAt = NULL WHERE id = :noteId")
    suspend fun restoreNote(noteId: String)

    @Query("UPDATE notes SET isPinned = :isPinned WHERE id = :noteId")
    suspend fun setPinned(noteId: String, isPinned: Boolean)

    @Query("UPDATE notes SET isFavorite = :isFavorite WHERE id = :noteId")
    suspend fun setFavorite(noteId: String, isFavorite: Boolean)

    @Query("DELETE FROM notes")
    suspend fun clearAll()
}

@Dao
interface RoomPendingSyncDao {
    @Query("SELECT * FROM pending_sync_queue ORDER BY createdAt ASC")
    fun getAllPendingFlow(): Flow<List<PendingSyncDbEntity>>

    @Query("SELECT COUNT(*) FROM pending_sync_queue")
    fun getPendingCountFlow(): Flow<Int>

    @Query("SELECT * FROM pending_sync_queue ORDER BY createdAt ASC")
    suspend fun getAllPending(): List<PendingSyncDbEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(operation: PendingSyncDbEntity)

    @Query("DELETE FROM pending_sync_queue WHERE operationId = :operationId")
    suspend fun removeByOperationId(operationId: String)

    @Query("DELETE FROM pending_sync_queue WHERE noteId = :noteId")
    suspend fun removeByNoteId(noteId: String)

    @Query("UPDATE pending_sync_queue SET retryCount = retryCount + 1 WHERE operationId = :operationId")
    suspend fun incrementRetry(operationId: String)

    @Query("DELETE FROM pending_sync_queue")
    suspend fun clearQueue()
}
