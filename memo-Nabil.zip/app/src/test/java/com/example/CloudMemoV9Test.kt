package com.example

import com.example.ui.model.NoteDisplayLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CloudMemoV9Test {

    @Test
    fun testNoteDisplayLayoutValues() {
        val layouts = NoteDisplayLayout.values()
        assertEquals(4, layouts.size)
        assertTrue(layouts.contains(NoteDisplayLayout.GRID_VIEW))
        assertTrue(layouts.contains(NoteDisplayLayout.COMPACT_LIST))
        assertTrue(layouts.contains(NoteDisplayLayout.COMFORTABLE_LIST))
        assertTrue(layouts.contains(NoteDisplayLayout.LARGE_CARDS))
    }

    @Test
    fun testNoteDisplayLayoutNames() {
        assertEquals("GRID_VIEW", NoteDisplayLayout.GRID_VIEW.name)
        assertEquals("COMPACT_LIST", NoteDisplayLayout.COMPACT_LIST.name)
        assertEquals("COMFORTABLE_LIST", NoteDisplayLayout.COMFORTABLE_LIST.name)
        assertEquals("LARGE_CARDS", NoteDisplayLayout.LARGE_CARDS.name)
    }

    @Test
    fun testVersionIdentification() {
        val expectedVersion = "9.0.0"
        val expectedVersionCode = 9
        assertNotNull(expectedVersion)
        assertEquals(9, expectedVersionCode)
    }
}
