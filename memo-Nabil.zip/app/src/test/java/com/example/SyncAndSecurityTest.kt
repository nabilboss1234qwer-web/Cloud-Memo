package com.example

import com.example.data.repository.SyncCursor
import com.example.data.security.PinLockPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncAndSecurityTest {

    @Test
    fun cursorAdvancesPageByPageWhileServerHasMore() {
        val (since, more) = SyncCursor.next(since = 100L, maxUpdated = 180L, serverTime = 500L, hasMore = true)
        assertEquals(180L, since)
        assertTrue(more)
    }

    @Test
    fun cursorUsesServerTimeWithMarginWhenFinished() {
        val (since, more) = SyncCursor.next(since = 100L, maxUpdated = 180L, serverTime = 500L, hasMore = false)
        assertEquals(498L, since)
        assertFalse(more)
    }

    @Test
    fun cursorNeverGoesBackwards() {
        val (since, _) = SyncCursor.next(since = 900L, maxUpdated = 0L, serverTime = 500L, hasMore = false)
        assertEquals(900L, since)
    }

    @Test
    fun cursorStopsIfServerClaimsMoreButNothingAdvanced() {
        // Protects against an endless loop when has_more is true but updated_at did not move.
        val (since, more) = SyncCursor.next(since = 100L, maxUpdated = 100L, serverTime = 300L, hasMore = true)
        assertFalse(more)
        assertEquals(298L, since)
    }

    @Test
    fun pinLockoutEscalates() {
        assertEquals(0L, PinLockPolicy.lockSecondsAfterFailure(1))
        assertEquals(0L, PinLockPolicy.lockSecondsAfterFailure(4))
        assertEquals(30L, PinLockPolicy.lockSecondsAfterFailure(5))
        assertEquals(60L, PinLockPolicy.lockSecondsAfterFailure(6))
        assertEquals(300L, PinLockPolicy.lockSecondsAfterFailure(7))
        assertEquals(900L, PinLockPolicy.lockSecondsAfterFailure(8))
        assertEquals(900L, PinLockPolicy.lockSecondsAfterFailure(50))
    }
}
