package com.example

import com.example.data.crypto.KeyBundle
import com.example.data.crypto.VaultCrypto
import com.example.data.crypto.WrongPassphraseException
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class VaultCryptoTest {

    @Test
    fun wrapAndUnwrapRoundTrip() {
        val master = VaultCrypto.newMasterKey()
        val bundle = VaultCrypto.wrap(master, "correct horse battery staple".toCharArray(), 1)
        assertEquals(1, bundle.version)
        assertEquals(VaultCrypto.ITERATIONS, bundle.iterations)
        val opened = VaultCrypto.unwrap(bundle, "correct horse battery staple".toCharArray())
        assertArrayEquals(master, opened)
    }

    @Test
    fun wrongPassphraseIsRejected() {
        val bundle = VaultCrypto.wrap(VaultCrypto.newMasterKey(), "first passphrase 123".toCharArray(), 1)
        try {
            VaultCrypto.unwrap(bundle, "another passphrase 456".toCharArray())
            fail("expected WrongPassphraseException")
        } catch (_: WrongPassphraseException) {
        }
    }

    @Test
    fun weakKdfSettingsFromServerAreRefused() {
        val good = VaultCrypto.wrap(VaultCrypto.newMasterKey(), "passphrase number one".toCharArray(), 1)
        val weak = KeyBundle(good.version, good.wrappedKey, good.nonce, good.salt, 1000)
        try {
            VaultCrypto.unwrap(weak, "passphrase number one".toCharArray())
            fail("expected IllegalArgumentException")
        } catch (_: IllegalArgumentException) {
        }
    }

    @Test
    fun bundleFitsServerFormatRules() {
        val b = VaultCrypto.wrap(VaultCrypto.newMasterKey(), "some long passphrase!".toCharArray(), 3)
        val base64 = Regex("^[A-Za-z0-9+/_-]+={0,2}$")
        assertTrue(b.wrappedKey.length >= 40 && base64.matches(b.wrappedKey))
        assertTrue(b.nonce.length >= 8 && base64.matches(b.nonce))
        assertTrue(b.salt.length >= 16 && base64.matches(b.salt))
        assertTrue(b.iterations >= 210_000)
    }

    @Test
    fun recoveryKeyRoundTrip() {
        val master = VaultCrypto.newMasterKey()
        val text = VaultCrypto.toRecoveryKey(master)
        assertArrayEquals(master, VaultCrypto.fromRecoveryKey(text))
        assertArrayEquals(master, VaultCrypto.fromRecoveryKey("  " + text.replace("-", " ").uppercase() + "\n"))
        assertNull(VaultCrypto.fromRecoveryKey("not-a-key"))
        assertNull(VaultCrypto.fromRecoveryKey(text.dropLast(2)))
        assertEquals(8, text.split("-").size)
        assertNotNull(text)
    }
}
