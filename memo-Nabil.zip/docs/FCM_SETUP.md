# Push notifications (FCM) setup

The app contains all FCM code. It initialises Firebase from a config file you add, so no Gradle plugin is needed.

1. Firebase Console -> project `cloud-47610` -> Project settings -> General -> Your apps -> Add app -> Android.
   Package name: `com.nabil.cloudmemo`. Download `google-services.json`.
2. Put the file here (create the `assets` folder if it does not exist):

       app/src/main/assets/google-services.json

   (inside the project: `app/src/main/assets/`, next to `res/` and `java/`).
3. Build and run. After sign-in the app subscribes to topic `all` and uploads its token with
   `POST /v1/devices/push-token`. Send a test from the admin app (the push status should be `sent`).

Debug builds with a different package (for example an `.debug` suffix) need their own Android app entry in Firebase;
the file may contain several apps, the one matching the installed package is used.
If you prefer the official Gradle plugin instead, apply it as usual: the app then skips its own initialisation.
Never commit `google-services.json` (it is already in `.gitignore`).
