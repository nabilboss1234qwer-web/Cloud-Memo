# Release signing

Create your own upload keystore once (keep the file and the passwords safe, losing them means you cannot update the app):

```
keytool -genkeypair -v -keystore release.jks -alias cloudmemo -keyalg RSA -keysize 4096 -validity 10000
```

Put `release.jks` in the project root (next to `settings.gradle.kts`), copy `keystore.properties.example` to
`keystore.properties` and fill in the passwords. The file and `*.jks` are git-ignored.
Alternatively set the environment variables `CLOUDMEMO_KEYSTORE_FILE`, `CLOUDMEMO_KEYSTORE_PASSWORD`,
`CLOUDMEMO_KEY_ALIAS`, `CLOUDMEMO_KEY_PASSWORD`.

Build: `./gradlew assembleRelease` (APK) or `./gradlew bundleRelease` (Play bundle).
Release builds use R8 (minify + resource shrinking): install the release APK once and check sign-in, notes, sync,
sharing, PIN lock and push before publishing. Rules live in `app/proguard-rules.pro`.

Without `keystore.properties` the release build falls back to the debug key (for local testing only).
